// import { useState } from "react";
// import style from "./seccion_1.module.css";



const Seccion_1 = () => {

  return (
    <div>
     
    </div>
  );
};

export default Seccion_1;