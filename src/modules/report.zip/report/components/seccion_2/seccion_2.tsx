// import { useEffect, useRef, useState } from "react";
import style from "./seccion_2.module.css";
// import Modal from "./shared/modal";

const Seccion_2 = () => {

  return (
    <div className={style.seccion}>
      
    </div>
  );
};

export default Seccion_2;