import "@supabase/functions-js/edge-runtime.d.ts";
import "./src/index.ts";