import "@supabase/functions-js/edge-runtime.d.ts";
import app from "./src/index.ts";

export default app;