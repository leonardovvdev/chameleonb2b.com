import { handleRequest } from "./routes/index.ts";

Deno.serve(handleRequest);