import { handleRequest } from "./routes/index.ts";

const app = {
  fetch: handleRequest,
};

export default app;