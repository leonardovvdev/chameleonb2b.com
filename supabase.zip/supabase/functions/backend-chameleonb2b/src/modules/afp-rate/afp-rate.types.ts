export interface AfpRate {
  afp_rt_id: number;
  afp_id: number;

  afp_rt_concept: string;
  afp_rt_percentage: number;

  afp_rt_start: string;
  afp_rt_end: string | null;
}

export interface AfpRateInsert {
  afp_id: number;

  afp_rt_concept: string;
  afp_rt_percentage: number;

  afp_rt_start: string;
  afp_rt_end?: string | null;
}

export interface AfpRateUpdate {
  afp_id?: number;

  afp_rt_concept?: string;
  afp_rt_percentage?: number;

  afp_rt_start?: string;
  afp_rt_end?: string | null;
}