export interface Afp {
  afp_id: number;
  afp_name: string;
}

export interface AfpInsert {
  afp_name: string;
}

export interface AfpUpdate {
  afp_name?: string;
}