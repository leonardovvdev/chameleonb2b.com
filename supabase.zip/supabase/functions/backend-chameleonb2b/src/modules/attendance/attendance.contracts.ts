// supabase/functions/backend-chameleonb2b/src/modules/attendance/attendance.contracts.ts
import { AppError } from "../../shared/http.ts";
import { supabaseAdmin } from "../../shared/supabase.ts";

export interface ContractRow {
  stff_cntrt_id: number;
  stff_id: number;
  cntrt_start_date: string | null;
  cntrt_end_date: string | null;
  cntrt_discount_absence: boolean;
  cntrt_discount_delay: boolean;
  cntrt_discount_refreshment_delay: boolean;
}

export interface EligibleContract extends ContractRow {
  /** true = contrato sin inicio ni fin: su inicio se fijará con la fecha del primer registro. */
  needsStartDate: boolean;
}

/** Contratos de varios personales, agrupados por stff_id (del más nuevo al más antiguo). */
export async function loadContractsByStaff(staffIds: number[]): Promise<Map<number, ContractRow[]>> {
  const map = new Map<number, ContractRow[]>();
  if (staffIds.length === 0) return map;

  const { data, error } = await supabaseAdmin
    .from("staff_contracts")
    .select(
      `stff_cntrt_id, stff_id, cntrt_start_date, cntrt_end_date,
       cntrt_discount_absence, cntrt_discount_delay, cntrt_discount_refreshment_delay`,
    )
    .in("stff_id", staffIds)
    .order("stff_cntrt_id", { ascending: false });
  if (error) {
    console.error("attendance: no se pudieron consultar los contratos", error);
    throw new AppError(500, "No se pudo consultar los contratos del personal.");
  }

  for (const c of (data ?? []) as ContractRow[]) {
    const lista = map.get(c.stff_id) ?? [];
    lista.push({
      ...c,
      cntrt_start_date: c.cntrt_start_date ? String(c.cntrt_start_date).slice(0, 10) : null,
      cntrt_end_date: c.cntrt_end_date ? String(c.cntrt_end_date).slice(0, 10) : null,
    });
    map.set(c.stff_id, lista);
  }
  return map;
}

/**
 * Contrato que permite registrar asistencia en `date` (YYYY-MM-DD), o null si no hay.
 *  - inicio <= fecha y (sin fin o fin >= fecha)          → vigente.
 *  - sin inicio y sin fin                                 → pendiente de iniciar: empezará en `date`.
 *  - sin inicio y con fin                                 → vigente si fecha <= fin.
 * Si varios cubren la fecha, gana el que ya tiene inicio y, entre iguales, el más nuevo.
 *
 * `soloConInicio = true`: ignora todo contrato con cntrt_start_date null (se usa para crear
 * automáticamente las filas vacías del resto del personal).
 */
export function eligibleContractForDate(
  contracts: ContractRow[],
  date: string,
  soloConInicio = false,
): EligibleContract | null {
  let pendiente: EligibleContract | null = null;

  for (const c of contracts) { // ya vienen del más nuevo al más antiguo
    const start = c.cntrt_start_date;
    const end = c.cntrt_end_date;
    if (soloConInicio && !start) continue;

    if (!start && !end) {
      pendiente ??= { ...c, needsStartDate: true };
      continue;
    }
    if ((!start || start <= date) && (!end || end >= date)) {
      return { ...c, needsStartDate: false };
    }
  }
  return pendiente;
}