// supabase/functions/backend-chameleonb2b/src/modules/attendance/attendance.controller.ts
import { AppError, json } from "../../shared/http.ts";
import { getAccessContext } from "../auth/auth.services.ts";
import {
  createAdvancement,
  createAttendance,
  createIncident,
  deleteAttendance,
  getAttendanceDetail,
  getAttendanceReport,
  listAdvancements,
  listAttendance,
  listEligibleStaff,
  listIncidents,
  parseDate,
  parseId,
  updateAdvancement,
  updateAttendanceJustification,
  updateAttendanceObservation,
  updateAttendanceTimes,
  getAttendanceReportRow,
  canDeleteRecords,
  deleteAdvancement,
  deleteIncident,
} from "./attendance.services.ts";

/** GET /attendance?date=YYYY-MM-DD → { items } */
export async function listAttendanceHandler(req: Request): Promise<Response> {
  const ctx = await getAccessContext(req);
  const date = parseDate(new URL(req.url).searchParams.get("date"));
  return json({ items: await listAttendance(ctx, date) });
}

/** GET /attendance/eligible-staff?date=YYYY-MM-DD → { items } (activos con contrato en esa fecha) */
export async function listEligibleStaffHandler(req: Request): Promise<Response> {
  const ctx = await getAccessContext(req);
  const date = parseDate(new URL(req.url).searchParams.get("date"));
  return json(await listEligibleStaff(ctx, date));
}

/** POST /attendance { staffId, date, type, description? } → registro creado */
export async function createAttendanceHandler(req: Request): Promise<Response> {
  const ctx = await getAccessContext(req);
  const body = await req.json().catch(() => null);
  if (body === null) throw new AppError(400, "El cuerpo de la petición no es válido.", "INVALID_BODY");
  return json(await createAttendance(ctx, body), 201);
}

/** DELETE /attendance?id= → { id } */
export async function deleteAttendanceHandler(req: Request): Promise<Response> {
  const ctx = await getAccessContext(req);
  const raw = new URL(req.url).searchParams.get("id");
  const id = Number(raw);
  if (!raw || !Number.isSafeInteger(id) || id <= 0) {
    throw new AppError(400, "El id del registro no es válido.", "INVALID_ID");
  }
  return json(await deleteAttendance(ctx, id));
}

/* ═════════ Modal del registro (seccion_4) ═════════ */

async function readBody(req: Request): Promise<unknown> {
  const body = await req.json().catch(() => null);
  if (body === null) throw new AppError(400, "El cuerpo de la petición no es válido.", "INVALID_BODY");
  return body;
}

/** GET /attendance/detail?id= */
export async function getAttendanceDetailHandler(req: Request): Promise<Response> {
  const ctx = await getAccessContext(req);
  const id = parseId(new URL(req.url).searchParams.get("id"), "El registro");
  return json(await getAttendanceDetail(ctx, id));
}

/** PATCH /attendance/times */
export async function updateAttendanceTimesHandler(req: Request): Promise<Response> {
  const ctx = await getAccessContext(req);
  return json(await updateAttendanceTimes(ctx, await readBody(req)));
}

/** PATCH /attendance/observation */
export async function updateAttendanceObservationHandler(req: Request): Promise<Response> {
  const ctx = await getAccessContext(req);
  return json(await updateAttendanceObservation(ctx, await readBody(req)));
}

/** PATCH /attendance/justification */
export async function updateAttendanceJustificationHandler(req: Request): Promise<Response> {
  const ctx = await getAccessContext(req);
  return json(await updateAttendanceJustification(ctx, await readBody(req)));
}

/** GET /attendance/incidents?attId= */
export async function listIncidentsHandler(req: Request): Promise<Response> {
  const ctx = await getAccessContext(req);
  const attId = parseId(new URL(req.url).searchParams.get("attId"), "El registro");
  return json(await listIncidents(ctx, attId));
}

/** POST /attendance/incidents */
export async function createIncidentHandler(req: Request): Promise<Response> {
  const ctx = await getAccessContext(req);
  return json(await createIncident(ctx, await readBody(req)), 201);
}

/** GET /attendance/advancements?stffId=&page=&pageSize= */
export async function listAdvancementsHandler(req: Request): Promise<Response> {
  const ctx = await getAccessContext(req);
  return json(await listAdvancements(ctx, new URL(req.url).searchParams));
}

/** POST /attendance/advancements */
export async function createAdvancementHandler(req: Request): Promise<Response> {
  const ctx = await getAccessContext(req);
  return json(await createAdvancement(ctx, await readBody(req)), 201);
}

/** PATCH /attendance/advancements */
export async function updateAdvancementHandler(req: Request): Promise<Response> {
  const ctx = await getAccessContext(req);
  return json(await updateAdvancement(ctx, await readBody(req)));
}
/** GET /attendance/report?stffId=&contractId= */
export async function getAttendanceReportHandler(req: Request): Promise<Response> {
  const ctx = await getAccessContext(req);
  const q = new URL(req.url).searchParams;
  return json(
    await getAttendanceReport(ctx, parseId(q.get("stffId"), "El personal"), parseId(q.get("contractId"), "El contrato")),
  );
}
/** GET /attendance/report/row?stffId=&contractId=&date= */
export async function getAttendanceReportRowHandler(req: Request): Promise<Response> {
  const ctx = await getAccessContext(req);
  const q = new URL(req.url).searchParams;
  return json(
    await getAttendanceReportRow(
      ctx,
      parseId(q.get("stffId"), "El personal"),
      parseId(q.get("contractId"), "El contrato"),
      parseDate(q.get("date")),
    ),
  );
}
/** GET /attendance/can-delete */
export async function canDeleteHandler(req: Request): Promise<Response> {
  return json(await canDeleteRecords(req));
}

/** DELETE /attendance/incidents?id= */
export async function deleteIncidentHandler(req: Request): Promise<Response> {
  const id = parseId(new URL(req.url).searchParams.get("id"), "La incidencia");
  return json(await deleteIncident(req, id));
}

/** DELETE /attendance/advancements?id= */
export async function deleteAdvancementHandler(req: Request): Promise<Response> {
  const id = parseId(new URL(req.url).searchParams.get("id"), "El adelanto");
  return json(await deleteAdvancement(req, id));
}