import { AppError, json } from "../../shared/http.ts";
import { getAccessContext } from "../staffs/staff.services.ts";
import {
  deleteAttendance,
  getAttendanceDetail,
  listAttendanceByDate,
  listPendingAbsence,
  listPendingCheckIn,
  registerAbsence,
  registerCheckIn,
  updateAttendanceJustification,
  updateAttendanceObservation,
  updateAttendanceTimes,
} from "./attendance.services.ts";
import type { AttendanceJustificationType } from "./attendance.types.ts";

const DATE_REGEX = /^\d{4}-\d{2}-\d{2}$/;
const MAX_SEARCH_LENGTH = 100;
const MAX_ABSENCE_LENGTH = 200; // VARCHAR(200) de att_justification_absence

const invalid = (message: string, code = "INVALID_BODY") => new AppError(400, message, code);

/** GET /attendance?date=YYYY-MM-DD → { items, total_staff } */
export async function listAttendance(req: Request): Promise<Response> {
  const { custId, bucketName } = await getAccessContext(req);

  const date = new URL(req.url).searchParams.get("date") ?? "";
  if (!DATE_REGEX.test(date) || Number.isNaN(Date.parse(date))) {
    throw new AppError(400, "La fecha no es válida.", "INVALID_DATE");
  }

  return json(await listAttendanceByDate(custId, bucketName, date));
}

/** POST /attendance  body { stffId } → registra el ingreso (att_schedule_start) de hoy */
export async function checkIn(req: Request): Promise<Response> {
  const { custId } = await getAccessContext(req);

  const body = (await req.json().catch(() => null)) as { stffId?: unknown } | null;
  const stffId = Number(body?.stffId);
  if (!body || !Number.isSafeInteger(stffId) || stffId <= 0) {
    throw invalid("El id del personal no es válido.", "INVALID_ID");
  }

  return json(await registerCheckIn(custId, stffId), 201);
}

/** Lee search / cargoId / rolId del query string. */
function readPendingFilters(req: Request) {
  const params = new URL(req.url).searchParams;

  const optionalId = (key: string): number | null => {
    const raw = params.get(key);
    if (!raw) return null;
    const n = Number(raw);
    if (!Number.isSafeInteger(n) || n <= 0) throw invalid("Los filtros no son válidos.", "INVALID_FILTER");
    return n;
  };

  return {
    search: (params.get("search") ?? "").trim().slice(0, MAX_SEARCH_LENGTH),
    cargoId: optionalId("cargoId"),
    rolId: optionalId("rolId"),
  };
}

/** GET /attendance/pending?search=&cargoId=&rolId= → { items } (activos sin ingreso hoy) */
export async function listPending(req: Request): Promise<Response> {
  const { custId, bucketName } = await getAccessContext(req);
  return json({ items: await listPendingCheckIn(custId, bucketName, readPendingFilters(req)) });
}

/** GET /attendance/pending-absence?search=&cargoId=&rolId= → { items } (activos sin ingreso ni ausencia hoy) */
export async function listPendingForAbsence(req: Request): Promise<Response> {
  const { custId, bucketName } = await getAccessContext(req);
  return json({ items: await listPendingAbsence(custId, bucketName, readPendingFilters(req)) });
}

/** POST /attendance/absence  body { stffId, description } → registra la ausencia de hoy */
export async function absence(req: Request): Promise<Response> {
  const { custId } = await getAccessContext(req);

  const body = (await req.json().catch(() => null)) as
    | { stffId?: unknown; description?: unknown }
    | null;

  const stffId = Number(body?.stffId);
  if (!body || !Number.isSafeInteger(stffId) || stffId <= 0) {
    throw invalid("El id del personal no es válido.", "INVALID_ID");
  }

  const description = typeof body.description === "string" ? body.description.trim() : "";
  if (description === "") {
    throw invalid("La descripción de la ausencia es obligatoria.", "INVALID_DESCRIPTION");
  }
  if (description.length > MAX_ABSENCE_LENGTH) {
    throw invalid(`La descripción no puede superar ${MAX_ABSENCE_LENGTH} caracteres.`, "INVALID_DESCRIPTION");
  }

  return json(await registerAbsence(custId, stffId, description), 201);
}

/* ───────────────────────── Detalle y edición de un registro ───────────────────────── */

const MAX_OBSERVATION_LENGTH = 500; // ajusta al tamaño real de att_observation
const MAX_JUSTIFICATION_LENGTH = 200; // = VARCHAR(200) de att_justification_absence

const JUSTIFICATION_TYPES: AttendanceJustificationType[] = ["delay", "refreshment_delay", "absence"];

/** Lee ?id= (id del registro de asistencia). */
function readAttendanceId(req: Request): number {
  const id = Number(new URL(req.url).searchParams.get("id"));
  if (!Number.isSafeInteger(id) || id <= 0) throw invalid("El id del registro no es válido.", "INVALID_ID");
  return id;
}

/** Texto opcional: vacío o null → null; si no, recortado y con tope de longitud. */
function readOptionalText(raw: unknown, max: number, label: string): string | null {
  if (raw === null || raw === undefined) return null;
  if (typeof raw !== "string") throw invalid(`${label} no es válida.`, "INVALID_TEXT");
  const text = raw.trim();
  if (text === "") return null;
  if (text.length > max) throw invalid(`${label} no puede superar ${max} caracteres.`, "INVALID_TEXT");
  return text;
}

/** Hora opcional: vacío o null → null; si no, ISO 8601 normalizado a UTC. */
function readTimestamp(raw: unknown, label: string): string | null {
  if (raw === null || raw === undefined || raw === "") return null;
  if (typeof raw !== "string" || Number.isNaN(Date.parse(raw))) {
    throw invalid(`La hora de ${label} no es válida.`, "INVALID_TIME");
  }
  return new Date(raw).toISOString();
}

/** GET /attendance/detail?id= → { att_id, att_observation, role_name, total_records } */
export async function getDetail(req: Request): Promise<Response> {
  const { custId } = await getAccessContext(req);
  return json(await getAttendanceDetail(custId, readAttendanceId(req)));
}

/**
 * PATCH /attendance/times?id=
 * body { inicioJornada, inicioReceso, finReceso, finJornada } (ISO 8601 o null)
 */
export async function updateTimes(req: Request): Promise<Response> {
  const { custId } = await getAccessContext(req);
  const attId = readAttendanceId(req);

  const body = (await req.json().catch(() => null)) as Record<string, unknown> | null;
  if (!body) throw invalid("Los datos no son válidos.");

  const times = {
    att_inicio_jornada: readTimestamp(body.inicioJornada, "inicio de jornada"),
    att_inicio_receso: readTimestamp(body.inicioReceso, "inicio de receso"),
    att_fin_receso: readTimestamp(body.finReceso, "fin de receso"),
    att_fin_jornada: readTimestamp(body.finJornada, "fin de jornada"),
  };

  if (times.att_fin_receso && !times.att_inicio_receso) {
    throw invalid("Indica el inicio del receso antes de su fin.", "INVALID_TIME");
  }

  // Las horas presentes deben ir en orden: inicio jornada ≤ inicio receso ≤ fin receso ≤ fin jornada.
  const ordered = [
    times.att_inicio_jornada,
    times.att_inicio_receso,
    times.att_fin_receso,
    times.att_fin_jornada,
  ]
    .filter((value): value is string => value !== null)
    .map((value) => Date.parse(value));
  if (ordered.some((value, i) => i > 0 && value < ordered[i - 1])) {
    throw invalid("Las horas deben ir en orden: ingreso, inicio de receso, fin de receso y salida.", "INVALID_TIME");
  }

  return json(await updateAttendanceTimes(custId, attId, times));
}

/** PATCH /attendance/observation?id=  body { observation } (vacío / null = borrar) */
export async function updateObservation(req: Request): Promise<Response> {
  const { custId } = await getAccessContext(req);
  const attId = readAttendanceId(req);

  const body = (await req.json().catch(() => null)) as { observation?: unknown } | null;
  if (!body) throw invalid("Los datos no son válidos.");

  const observation = readOptionalText(body.observation, MAX_OBSERVATION_LENGTH, "La observación");
  return json(await updateAttendanceObservation(custId, attId, observation));
}

/** PATCH /attendance/justification?id=  body { type: "delay" | "refreshment_delay" | "absence", text } */
export async function updateJustification(req: Request): Promise<Response> {
  const { custId } = await getAccessContext(req);
  const attId = readAttendanceId(req);

  const body = (await req.json().catch(() => null)) as { type?: unknown; text?: unknown } | null;
  if (!body) throw invalid("Los datos no son válidos.");

  const type = JUSTIFICATION_TYPES.find((t) => t === body.type);
  if (!type) throw invalid("El tipo de justificación no es válido.", "INVALID_TYPE");

  const text = readOptionalText(body.text, MAX_JUSTIFICATION_LENGTH, "La justificación");
  return json(await updateAttendanceJustification(custId, attId, type, text));
}

/** DELETE /attendance?id= → elimina el registro */
export async function removeAttendance(req: Request): Promise<Response> {
  const { custId } = await getAccessContext(req);
  await deleteAttendance(custId, readAttendanceId(req));
  return json({ ok: true });
}