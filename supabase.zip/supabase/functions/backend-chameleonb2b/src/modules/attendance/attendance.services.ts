// supabase/functions/backend-chameleonb2b/src/modules/attendance/attendance.services.ts
import { AppError } from "../../shared/http.ts";
import { supabaseAdmin } from "../../shared/supabase.ts";
import { createSignedUrls } from "../buckets/buckets.services.ts";
import { requireUser, type AccessContext } from "../auth/auth.services.ts";
import { findByAuthId } from "../customers/customers.services.ts";
import { assertStaffOfCustomer } from "../staff-contracts/staff-contracts.services.ts";
import { eligibleContractForDate, loadContractsByStaff } from "./attendance.contracts.ts";

/** Nombre de la tabla de asistencias (cámbialo si en tu BD se llama distinto). */
const TABLE = "attendance";
/** Mismo folder que usa staffs.services.ts para las fotos del personal. */
const STAFF_IMG_FOLDER = "gestion_empresarial/staffs_img";

const ATT_COLUMNS = `att_id, stff_id, att_date, att_schedule_start, att_refreshment_start, att_refreshment_end,
  att_schedule_end, att_justification_absence, att_justification_delay, att_justification_refreshment_delay,
  att_discount_absence, att_discount_delay, att_discount_refreshment_delay, att_observation`;

const SELECT_WITH_STAFF = `${ATT_COLUMNS},
  staffs!inner(cust_id, stff_name, stff_lastname, stff_dni, stff_link_img,
    customer_job_positions(cust_jb_pstn_name)),
  staff_discount_incidents(count)`;

const bad = (message: string, code = "INVALID_DATA") => new AppError(400, message, code);

function fail(message: string, error: unknown): never {
  console.error(`attendance: ${message}`, error);
  throw new AppError(500, message);
}

const one = <T>(v: T | T[] | null | undefined): T | null => (Array.isArray(v) ? (v[0] ?? null) : (v ?? null));

/* ───────────────────────── Validaciones ───────────────────────── */

/** YYYY-MM-DD válido. */
export function parseDate(value: unknown): string {
  const d = typeof value === "string" ? value.trim().slice(0, 10) : "";
  if (!/^\d{4}-\d{2}-\d{2}$/.test(d) || Number.isNaN(new Date(`${d}T00:00:00Z`).getTime())) {
    throw bad("La fecha no es válida.");
  }
  return d;
}

/** La fecha de un registro nuevo no puede estar lejos de "hoy" (cubre la diferencia de zona horaria). */
/** Se puede registrar hoy o fechas pasadas; no futuras (1 día de margen por zona horaria). */
function assertNotFuture(date: string) {
  if (new Date(`${date}T00:00:00Z`).getTime() > Date.now() + 86_400_000) {
    throw bad("No se puede registrar una jornada de una fecha futura.", "INVALID_DATE");
  }
}

/** Hora de ingreso opcional (ISO). null = usar la hora del servidor. */
function parseStartAt(value: unknown): string | null {
  if (value === undefined || value === null || value === "") return null;
  const t = typeof value === "string" ? new Date(value).getTime() : NaN;
  if (Number.isNaN(t)) throw bad("La hora de ingreso no es válida.");
  if (t > Date.now() + 60_000) throw bad("La hora de ingreso no puede estar en el futuro.", "INVALID_TIME");
  return new Date(t).toISOString();
}

/* ───────────────────────── Forma que consume el frontend ───────────────────────── */

// deno-lint-ignore no-explicit-any
type Row = Record<string, any>;

function toItem(r: Row, urls: Map<string, string>) {
  const s = one<Row>(r.staffs) ?? {};
  const img = s.stff_link_img ? `${STAFF_IMG_FOLDER}/${s.stff_link_img}` : null;
  return {
    att_id: r.att_id,
    stff_id: r.stff_id,
    stff_name: s.stff_name ?? "",
    stff_lastname: s.stff_lastname ?? "",
    stff_dni: s.stff_dni ?? "",
    img_url: img ? (urls.get(img) ?? null) : null,
    job_position_name: one<Row>(s.customer_job_positions)?.cust_jb_pstn_name ?? null,
    att_date: r.att_date,
    att_schedule_start: r.att_schedule_start,
    att_refreshment_start: r.att_refreshment_start,
    att_refreshment_end: r.att_refreshment_end,
    att_schedule_end: r.att_schedule_end,
    att_justification_absence: r.att_justification_absence,
    att_justification_delay: r.att_justification_delay,
    att_justification_refreshment_delay: r.att_justification_refreshment_delay,
    att_discount_absence: r.att_discount_absence,
    att_discount_delay: r.att_discount_delay,
    att_discount_refreshment_delay: r.att_discount_refreshment_delay,
    att_observation: r.att_observation,
    // Total de filas de staff_discount_incidents con este att_id.
    incidents_count: Number(one<Row>(r.staff_discount_incidents)?.count ?? 0),
  };
}

async function withUrls(ctx: AccessContext, rows: Row[]) {
  const paths = rows
    .map((r) => one<Row>(r.staffs)?.stff_link_img)
    .filter((l): l is string => !!l)
    .map((l) => `${STAFF_IMG_FOLDER}/${l}`);
  const urls = await createSignedUrls(ctx.bucketName, paths);
  return rows.map((r) => toItem(r, urls));
}

/* ───────────────────────── Listar por fecha ───────────────────────── */

/** GET /attendance?date=YYYY-MM-DD → registros de ese día del customer. */
export async function listAttendance(ctx: AccessContext, date: string) {
  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .select(SELECT_WITH_STAFF)
    .eq("att_date", date)
    .eq("staffs.cust_id", ctx.custId)
    .order("att_id");
  if (error) fail("No se pudieron cargar los registros de asistencia.", error);
  return withUrls(ctx, (data ?? []) as Row[]);
}

/* ───────────────────────── Crear (ingreso o ausencia) ───────────────────────── */

interface CreateInput {
  staffId: number;
  date: string;
  startAt: string | null;
}

function parseCreate(raw: unknown): CreateInput {
  if (typeof raw !== "object" || raw === null || Array.isArray(raw)) throw bad("Los datos no son válidos.");
  const b = raw as Row;

  const staffId = Number(b.staffId);
  if (!Number.isSafeInteger(staffId) || staffId <= 0) throw bad("El personal no es válido.");

  const date = parseDate(b.date);
  assertNotFuture(date);
  return { staffId, date, startAt: parseStartAt(b.startAt) };
}

/**
 * Crea, para la fecha, una fila vacía (sin horas) por cada personal ACTIVO que aún no tiene registro
 * y cuyo contrato ya tiene cntrt_start_date (con inicio null NO se registra) y cubre la fecha.
 */
async function registrarPendientes(ctx: AccessContext, date: string) {
  const { data: activos, error: actErr } = await supabaseAdmin
    .from("staffs")
    .select("stff_id")
    .eq("cust_id", ctx.custId)
    .eq("stff_active", true);
  if (actErr) fail("No se pudo consultar al personal activo.", actErr);

  const todos = (activos ?? []).map((s) => s.stff_id as number);
  if (todos.length === 0) return;

  // Solo quien tiene un contrato que cubre la fecha (el más reciente de cada personal).
  const contratos = await loadContractsByStaff(todos);
  const filas = todos.flatMap((id) => {
    const c = eligibleContractForDate(contratos.get(id) ?? [], date, true);
    if (!c) return [];
    return [{
      stff_id: id,
      att_date: date,
      att_discount_absence: c.cntrt_discount_absence,
      att_discount_delay: c.cntrt_discount_delay,
      att_discount_refreshment_delay: c.cntrt_discount_refreshment_delay,
    }];
  });
  if (filas.length === 0) return;

  // ON CONFLICT DO NOTHING: no toca a quien ya tiene registro ese día.
  const { error } = await supabaseAdmin
    .from(TABLE)
    .upsert(filas, { onConflict: "stff_id,att_date", ignoreDuplicates: true });
  if (error) fail("No se pudo registrar al resto del personal.", error);
}

/** POST /attendance { staffId, date, type: "ingreso" | "ausencia", description? } → registro creado */
export async function createAttendance(ctx: AccessContext, raw: unknown) {
  const input = parseCreate(raw);

  // 1) El personal debe ser de este customer y estar activo.
  const staff = await assertStaffOfCustomer(ctx, input.staffId, "stff_id, stff_active");
  if (!staff.stff_active) {
    throw new AppError(409, "Este colaborador está inactivo.", "STAFF_INACTIVE");
  }

  // 2) Debe tener un contrato que cubra la fecha elegida.
  const contratos = await loadContractsByStaff([input.staffId]);
  const contrato = eligibleContractForDate(contratos.get(input.staffId) ?? [], input.date);
  if (!contrato) {
    throw new AppError(
      409,
      "Este colaborador no tiene un contrato vigente en esa fecha.",
      "NO_ACTIVE_CONTRACT",
    );
  }

  // 3) Contrato sin fecha de inicio ni de fin: empieza en la fecha del registro.
  let inicioFijadoAhora = false;
  if (contrato.needsStartDate) {
    const { data: fijado, error: startErr } = await supabaseAdmin
      .from("staff_contracts")
      .update({ cntrt_start_date: input.date })
      .eq("stff_cntrt_id", contrato.stff_cntrt_id)
      .is("cntrt_start_date", null) // por si otra petición ya lo fijó
      .is("cntrt_end_date", null)
      .select("stff_cntrt_id");
    if (startErr) fail("No se pudo fijar el inicio del contrato.", startErr);
    inicioFijadoAhora = (fijado ?? []).length > 0;
  }

  let creado;
  try {
    creado = await guardarAsistencia(ctx, input, contrato);
  } catch (e) {
    // Si el registro falló, el contrato vuelve a quedar sin fecha de inicio.
    if (inicioFijadoAhora) {
      await supabaseAdmin
        .from("staff_contracts")
        .update({ cntrt_start_date: null })
        .eq("stff_cntrt_id", contrato.stff_cntrt_id)
        .eq("cntrt_start_date", input.date);
    }
    throw e;
  }

  // Resto del personal (con contrato ya iniciado): fila vacía con att_schedule_start nulo.
  // El registro principal ya quedó guardado, por eso un fallo aquí solo se anota en el log.
  try {
    await registrarPendientes(ctx, input.date);
  } catch (e) {
    console.error("attendance: no se pudieron crear las filas pendientes", e);
  }

  return creado;
}

async function guardarAsistencia(
  ctx: AccessContext,
  input: CreateInput,
  contrato: { cntrt_discount_absence: boolean; cntrt_discount_delay: boolean; cntrt_discount_refreshment_delay: boolean },
) {
  const { data: existing, error: existErr } = await supabaseAdmin
    .from(TABLE)
    .select("att_id, att_schedule_start, att_justification_absence")
    .eq("stff_id", input.staffId)
    .eq("att_date", input.date)
    .maybeSingle();
  if (existErr) fail("No se pudo validar el registro.", existErr);

  // Fila vacía (sin ingreso ni ausencia) = pendiente creado automáticamente: se completa.
  const esPendiente =
    !!existing && !existing.att_schedule_start && existing.att_justification_absence === null;
  if (existing && !esPendiente) {
    throw new AppError(409, "Este colaborador ya tiene un registro en esa fecha.", "ALREADY_REGISTERED");
  }

  const datos = {
    // Hoy: la hora la pone el servidor. Fecha pasada: la hora indicada en el modal.
    att_schedule_start: input.startAt ?? new Date().toISOString(),
  };

  let created: { att_id: number };
  if (existing) {
    const { data, error } = await supabaseAdmin
      .from(TABLE)
      .update(datos)
      .eq("att_id", existing.att_id)
      .select("att_id")
      .single();
    if (error || !data) fail("No se pudo guardar el registro.", error);
    created = data!;
  } else {
    const flags = {
      att_discount_absence: contrato.cntrt_discount_absence,
      att_discount_delay: contrato.cntrt_discount_delay,
      att_discount_refreshment_delay: contrato.cntrt_discount_refreshment_delay,
    };
    const { data, error } = await supabaseAdmin
      .from(TABLE)
      .insert({ stff_id: input.staffId, att_date: input.date, ...datos, ...flags })
      .select("att_id")
      .single();
    if (error?.code === "23505") {
      throw new AppError(409, "Este colaborador ya tiene un registro en esa fecha.", "ALREADY_REGISTERED");
    }
    if (error || !data) fail("No se pudo guardar el registro.", error);
    created = data!;
  }

  const { data: row, error: readErr } = await supabaseAdmin
    .from(TABLE)
    .select(SELECT_WITH_STAFF)
    .eq("att_id", created!.att_id)
    .single();
  if (readErr || !row) fail("El registro se guardó pero no se pudo leer.", readErr);

  return (await withUrls(ctx, [row as Row]))[0];
}

/* ───────────────────── Personal elegible para registrar jornada ───────────────────── */

/** GET /attendance/eligible-staff?date= → personal ACTIVO con contrato que cubre esa fecha. */
export async function listEligibleStaff(ctx: AccessContext, date: string) {
  const { data, error } = await supabaseAdmin
    .from("staffs")
    .select(
      `stff_id, stff_name, stff_lastname, stff_dni, stff_link_img, cust_jb_pstn_id, cust_role_id,
       customer_job_positions(cust_jb_pstn_name), customer_roles(cust_role_name)`,
    )
    .eq("cust_id", ctx.custId)
    .eq("stff_active", true)
    .order("stff_lastname")
    .order("stff_name")
    .order("stff_id");
  if (error) fail("No se pudo consultar al personal activo.", error);

  const activos = (data ?? []) as Row[];
  const contratos = await loadContractsByStaff(activos.map((s) => s.stff_id as number));
  const elegibles = activos.filter((s) => eligibleContractForDate(contratos.get(s.stff_id) ?? [], date) !== null);

  const paths = elegibles
    .map((s) => (s.stff_link_img ? `${STAFF_IMG_FOLDER}/${s.stff_link_img}` : null))
    .filter((p): p is string => p !== null);
  const urls = await createSignedUrls(ctx.bucketName, paths);

  return {
    items: elegibles.map((s) => ({
      stff_id: s.stff_id,
      stff_name: s.stff_name,
      stff_lastname: s.stff_lastname,
      stff_dni: s.stff_dni,
      img_url: s.stff_link_img ? (urls.get(`${STAFF_IMG_FOLDER}/${s.stff_link_img}`) ?? null) : null,
      cust_jb_pstn_id: s.cust_jb_pstn_id,
      job_position_name: one<Row>(s.customer_job_positions)?.cust_jb_pstn_name ?? null,
      cust_role_id: s.cust_role_id,
      role_name: one<Row>(s.customer_roles)?.cust_role_name ?? null,
    })),
  };
}

/* ───────────────────────── Eliminar ───────────────────────── */

/** DELETE /attendance?id= → { id }. Solo registros de personal de este customer. */
export async function deleteAttendance(ctx: AccessContext, attId: number) {
  const { data: row, error: readErr } = await supabaseAdmin
    .from(TABLE)
    .select("att_id, staffs!inner(cust_id)")
    .eq("att_id", attId)
    .eq("staffs.cust_id", ctx.custId)
    .maybeSingle();
  if (readErr) fail("No se pudo validar el registro.", readErr);
  if (!row) throw new AppError(404, "El registro no existe.", "NOT_FOUND");

  const { error } = await supabaseAdmin.from(TABLE).delete().eq("att_id", attId);
  if (error) fail("No se pudo eliminar el registro.", error);

  return { id: attId };
}

/* ═════════════════════════════════════════════════════════════════════════════

/* ═════════════════════════════════════════════════════════════════════════════
 * MODAL DEL REGISTRO (seccion_4): detalle, horas, observación, justificaciones,
 * incidencias y adelantos. Todo pasa por getOwnedAttendance() para que un
 * customer nunca toque registros de otro customer.
 * ═════════════════════════════════════════════════════════════════════════════ */

/** Tablas (si en tu BD se llaman distinto, cámbialas aquí). */
const INCIDENTS_TABLE = "staff_discount_incidents";
const ADVANCEMENTS_TABLE = "staff_advancements";

const MAX_OBSERVATION = 500;
const MAX_JUSTIFICATION = 200; // = VARCHAR(200) de las justificaciones
const MAX_INCIDENT_DESCRIPTION = 200;
const MAX_ADVANCEMENT_DESCRIPTION = 500;
const MAX_AMOUNT = 9_999_999.99;

/* ───────── Validaciones ───────── */

export function parseId(value: unknown, label: string): number {
  const id = Number(value);
  if (!Number.isSafeInteger(id) || id <= 0) throw bad(`${label} no es válido.`);
  return id;
}

function parseBody(raw: unknown): Row {
  if (typeof raw !== "object" || raw === null || Array.isArray(raw)) throw bad("Los datos no son válidos.");
  return raw as Row;
}

/** Texto opcional: recorta, "" → null y valida el largo. */
function parseText(value: unknown, max: number, label: string): string | null {
  if (value === null || value === undefined) return null;
  if (typeof value !== "string") throw bad(`${label} no es válido.`);
  const text = value.trim();
  if (text === "") return null;
  if (text.length > max) throw bad(`${label} no puede superar ${max} caracteres.`);
  return text;
}

function parseAmount(value: unknown): number {
  const amount = Math.round(Number(value) * 100) / 100;
  if (!Number.isFinite(amount) || amount <= 0) throw bad("El monto debe ser mayor a 0.");
  if (amount > MAX_AMOUNT) throw bad("El monto es demasiado grande.");
  return amount;
}

/** Timestamp ISO opcional ("" o null → null). */
function parseTimestamp(value: unknown, label: string): string | null {
  if (value === null || value === undefined || value === "") return null;
  if (typeof value !== "string") throw bad(`${label} no es válido.`);
  const time = new Date(value).getTime();
  if (Number.isNaN(time)) throw bad(`${label} no es válido.`);
  return new Date(time).toISOString();
}

/* ───────── Apoyo ───────── */

/** Registro de asistencia (con nombre del personal) SOLO si pertenece al customer. */
async function getOwnedAttendance(ctx: AccessContext, attId: number) {
  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .select("att_id, stff_id, att_date, staffs!inner(cust_id, stff_name, stff_lastname)")
    .eq("att_id", attId)
    .eq("staffs.cust_id", ctx.custId)
    .maybeSingle();
  if (error) fail("No se pudo validar el registro.", error);
  if (!data) throw new AppError(404, "El registro no existe.", "NOT_FOUND");
  return data as Row;
}

/** id → "Nombre Apellido" de los staff indicados (solo de este customer). */
async function staffNames(ctx: AccessContext, ids: number[]): Promise<Map<number, string>> {
  const unique = [...new Set(ids)];
  if (unique.length === 0) return new Map();
  const { data, error } = await supabaseAdmin
    .from("staffs")
    .select("stff_id, stff_name, stff_lastname")
    .eq("cust_id", ctx.custId)
    .in("stff_id", unique);
  if (error) fail("No se pudieron consultar los nombres del personal.", error);
  return new Map(
    ((data ?? []) as Row[]).map((s) => [s.stff_id as number, `${s.stff_name} ${s.stff_lastname}`.trim()]),
  );
}

/* ───────── Detalle (pestañas Información y Observación) ───────── */

/** GET /attendance/detail?id= → { att_id, role_name, total_records, att_observation } */
export async function getAttendanceDetail(ctx: AccessContext, attId: number) {
  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .select("att_id, stff_id, att_observation, staffs!inner(cust_id, customer_roles(cust_role_name))")
    .eq("att_id", attId)
    .eq("staffs.cust_id", ctx.custId)
    .maybeSingle();
  if (error) fail("No se pudo cargar el detalle del registro.", error);
  if (!data) throw new AppError(404, "El registro no existe.", "NOT_FOUND");

  const row = data as Row;
  const { count, error: countErr } = await supabaseAdmin
    .from(TABLE)
    .select("att_id", { count: "exact", head: true })
    .eq("stff_id", row.stff_id);
  if (countErr) fail("No se pudo contar los registros del personal.", countErr);

  return {
    att_id: row.att_id,
    role_name: one<Row>(one<Row>(row.staffs)?.customer_roles)?.cust_role_name ?? null,
    total_records: count ?? 0,
    att_observation: row.att_observation,
  };
}

/* ───────── Editar horas (pestaña Editar) ───────── */

/** PATCH /attendance/times { id, inicioJornada, inicioReceso, finReceso, finJornada } (ISO o null) */
export async function updateAttendanceTimes(ctx: AccessContext, raw: unknown) {
  const b = parseBody(raw);
  const attId = parseId(b.id, "El registro");
  await getOwnedAttendance(ctx, attId);

  const start = parseTimestamp(b.inicioJornada, "El inicio de jornada");
  const refStart = parseTimestamp(b.inicioReceso, "El inicio de receso");
  const refEnd = parseTimestamp(b.finReceso, "El fin de receso");
  const end = parseTimestamp(b.finJornada, "El fin de jornada");

  // Mismas reglas que el modal: sin ingreso no hay demás horas, y todo en orden.
  if (!start && (refStart || refEnd || end)) throw bad("Indica el inicio de jornada antes de las demás horas.");
  if (refEnd && !refStart) throw bad("Indica el inicio del receso antes de su fin.");
  const filled = [start, refStart, refEnd, end].filter((v): v is string => v !== null).map((v) => new Date(v).getTime());
  if (filled.some((v, i) => i > 0 && v < filled[i - 1])) {
    throw bad("Las horas deben ir en orden: ingreso, inicio de receso, fin de receso y salida.");
  }

  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .update({
      att_schedule_start: start,
      att_refreshment_start: refStart,
      att_refreshment_end: refEnd,
      att_schedule_end: end,
    })
    .eq("att_id", attId)
    .select("att_schedule_start, att_refreshment_start, att_refreshment_end, att_schedule_end")
    .single();
  if (error || !data) fail("No se pudieron guardar las horas.", error);
  return data;
}

/* ───────── Observación (pestaña Observación) ───────── */

/** PATCH /attendance/observation { id, text } (text vacío o null = borrar) → { att_observation } */
export async function updateAttendanceObservation(ctx: AccessContext, raw: unknown) {
  const b = parseBody(raw);
  const attId = parseId(b.id, "El registro");
  const text = parseText(b.text, MAX_OBSERVATION, "La observación");
  await getOwnedAttendance(ctx, attId);

  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .update({ att_observation: text })
    .eq("att_id", attId)
    .select("att_observation")
    .single();
  if (error || !data) fail("No se pudo guardar la observación.", error);
  return { att_observation: data!.att_observation as string | null };
}

/* ───────── Justificaciones (pestaña Justificación) ───────── */

const JUSTIFICATION_COLUMNS = {
  delay: "att_justification_delay",
  refreshment_delay: "att_justification_refreshment_delay",
  absence: "att_justification_absence",
} as const;

/** PATCH /attendance/justification { id, type: "delay" | "refreshment_delay" | "absence", text } → { text } */
export async function updateAttendanceJustification(ctx: AccessContext, raw: unknown) {
  const b = parseBody(raw);
  const attId = parseId(b.id, "El registro");
  if (typeof b.type !== "string" || !Object.hasOwn(JUSTIFICATION_COLUMNS, b.type)) {
    throw bad("El tipo de justificación no es válido.");
  }
  const column = JUSTIFICATION_COLUMNS[b.type as keyof typeof JUSTIFICATION_COLUMNS];
  const text = parseText(b.text, MAX_JUSTIFICATION, "La justificación");
  await getOwnedAttendance(ctx, attId);

  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .update({ [column]: text })
    .eq("att_id", attId)
    .select(column)
    .single();
  if (error || !data) fail("No se pudo guardar la justificación.", error);
  return { text: (data as Row)[column] as string | null };
}

/* ───────── Incidencias (pestaña Incidencias) ───────── */

const INCIDENT_COLUMNS = "stff_dscount_ncdnt_id, att_id, stff_id, stff_dscount_description, stff_dscount_amount";

function toIncident(r: Row, names: Map<number, string>) {
  return {
    id: r.stff_dscount_ncdnt_id,
    amount: Number(r.stff_dscount_amount),
    description: r.stff_dscount_description,
    created_by_staff_id: r.stff_id ?? null,
    created_by_name: r.stff_id ? (names.get(r.stff_id) ?? null) : null,
    created_at: null, // la tabla no tiene fecha de creación
  };
}

/** GET /attendance/incidents?attId= → { items } (más recientes primero) */
export async function listIncidents(ctx: AccessContext, attId: number) {
  await getOwnedAttendance(ctx, attId);
  const { data, error } = await supabaseAdmin
    .from(INCIDENTS_TABLE)
    .select(INCIDENT_COLUMNS)
    .eq("att_id", attId)
    .order("stff_dscount_ncdnt_id", { ascending: false });
  if (error) fail("No se pudieron cargar las incidencias.", error);

  const rows = (data ?? []) as Row[];
  const names = await staffNames(ctx, rows.map((r) => r.stff_id).filter((id): id is number => !!id));
  return { items: rows.map((r) => toIncident(r, names)) };
}

/** POST /attendance/incidents { attId, description, amount } → incidencia creada */
export async function createIncident(ctx: AccessContext, raw: unknown) {
  const b = parseBody(raw);
  const attId = parseId(b.attId, "El registro");
  const description = parseText(b.description, MAX_INCIDENT_DESCRIPTION, "La descripción");
  if (description === null) throw bad("La descripción es obligatoria.");
  const amount = parseAmount(b.amount);
  await getOwnedAttendance(ctx, attId);

  // Quien entra al sistema es el titular de la cuenta (customer), por eso stff_id va null.
  const { data, error } = await supabaseAdmin
    .from(INCIDENTS_TABLE)
    .insert({
      att_id: attId,
      stff_id: null,
      stff_dscount_description: description,
      stff_dscount_amount: amount,
    })
    .select(INCIDENT_COLUMNS)
    .single();
  if (error || !data) fail("No se pudo crear la incidencia.", error);
  return toIncident(data as Row, new Map());
}

/* ───────── Adelantos (pestaña Adelantos) ───────── */

const ADVANCEMENT_COLUMNS =
  "stff_dvncmnt_id, att_id, stff_id_advancement_by, stff_dvncmnt_amount, stff_dvncmnt_description";

function toAdvancement(r: Row, person: Row, date: string, names: Map<number, string>) {
  return {
    id: r.stff_dvncmnt_id,
    stff_id: person.stff_id,
    stff_name: person.stff_name ?? "",
    stff_lastname: person.stff_lastname ?? "",
    delivered_by_staff_id: r.stff_id_advancement_by ?? null,
    delivered_by_name: r.stff_id_advancement_by ? (names.get(r.stff_id_advancement_by) ?? null) : null,
    amount: Number(r.stff_dvncmnt_amount),
    description: r.stff_dvncmnt_description ?? null,
    date, // fecha del registro de asistencia al que pertenece
  };
}

/** GET /attendance/advancements?stffId=&page=&pageSize= → { items, count } (más recientes primero) */
export async function listAdvancements(ctx: AccessContext, q: URLSearchParams) {
  const stffId = parseId(q.get("stffId"), "El personal");
  const page = Math.max(1, Math.floor(Number(q.get("page")) || 1));
  const pageSize = Math.min(50, Math.max(1, Math.floor(Number(q.get("pageSize")) || 10)));

  const { data: person, error: personErr } = await supabaseAdmin
    .from("staffs")
    .select("stff_id, stff_name, stff_lastname")
    .eq("stff_id", stffId)
    .eq("cust_id", ctx.custId)
    .maybeSingle();
  if (personErr) fail("No se pudo validar al personal.", personErr);
  if (!person) throw new AppError(404, "El personal no existe.", "NOT_FOUND");

  const { data, error } = await supabaseAdmin
    .from(ADVANCEMENTS_TABLE)
    .select(`${ADVANCEMENT_COLUMNS}, attendance!inner(att_date, stff_id)`)
    .eq("attendance.stff_id", stffId);
  if (error) fail("No se pudieron cargar los adelantos.", error);

  // Se ordena aquí (fecha del registro y luego id, de mayor a menor) y se pagina en memoria.
  const rows = ((data ?? []) as Row[]).sort((a, b) => {
    const da = one<Row>(a.attendance)?.att_date ?? "";
    const db = one<Row>(b.attendance)?.att_date ?? "";
    return da === db ? b.stff_dvncmnt_id - a.stff_dvncmnt_id : da < db ? 1 : -1;
  });
  const pageRows = rows.slice((page - 1) * pageSize, page * pageSize);
  const names = await staffNames(ctx, pageRows.map((r) => r.stff_id_advancement_by).filter((id): id is number => !!id));

  return {
    count: rows.length,
    items: pageRows.map((r) => toAdvancement(r, person as Row, one<Row>(r.attendance)?.att_date ?? "", names)),
  };
}

/** POST /attendance/advancements { attId, amount, description? } → adelanto creado */
export async function createAdvancement(ctx: AccessContext, raw: unknown) {
  const b = parseBody(raw);
  const attId = parseId(b.attId, "El registro");
  const amount = parseAmount(b.amount);
  const description = parseText(b.description, MAX_ADVANCEMENT_DESCRIPTION, "La descripción");
  const att = await getOwnedAttendance(ctx, attId);
  const person = one<Row>(att.staffs) ?? {};

  // Quien entrega es el titular de la cuenta (customer): stff_id_advancement_by = null → "Super admin".
  const { data, error } = await supabaseAdmin
    .from(ADVANCEMENTS_TABLE)
    .insert({
      att_id: attId,
      stff_id_advancement_by: null,
      stff_dvncmnt_amount: amount,
      stff_dvncmnt_description: description,
    })
    .select(ADVANCEMENT_COLUMNS)
    .single();
  if (error || !data) fail("No se pudo crear el adelanto.", error);
  return toAdvancement(data as Row, { ...person, stff_id: att.stff_id }, att.att_date, new Map());
}

/** PATCH /attendance/advancements { id, amount, description? } → adelanto actualizado */
export async function updateAdvancement(ctx: AccessContext, raw: unknown) {
  const b = parseBody(raw);
  const id = parseId(b.id, "El adelanto");
  const amount = parseAmount(b.amount);
  const description = parseText(b.description, MAX_ADVANCEMENT_DESCRIPTION, "La descripción");

  const { data: current, error: readErr } = await supabaseAdmin
    .from(ADVANCEMENTS_TABLE)
    .select("att_id")
    .eq("stff_dvncmnt_id", id)
    .maybeSingle();
  if (readErr) fail("No se pudo validar el adelanto.", readErr);
  if (!current) throw new AppError(404, "El adelanto no existe.", "NOT_FOUND");

  // Verifica que el adelanto pertenezca a un registro de este customer.
  const att = await getOwnedAttendance(ctx, current.att_id as number);
  const person = one<Row>(att.staffs) ?? {};

  const { data, error } = await supabaseAdmin
    .from(ADVANCEMENTS_TABLE)
    .update({ stff_dvncmnt_amount: amount, stff_dvncmnt_description: description })
    .eq("stff_dvncmnt_id", id)
    .select(ADVANCEMENT_COLUMNS)
    .single();
  if (error || !data) fail("No se pudo guardar el adelanto.", error);

  const row = data as Row;
  const names = await staffNames(ctx, row.stff_id_advancement_by ? [row.stff_id_advancement_by] : []);
  return toAdvancement(row, { ...person, stff_id: att.stff_id }, att.att_date, names);
}

/* ───────────────────────── Reporte por contrato (pantalla /reports) ───────────────────────── */

const fechaLima = new Intl.DateTimeFormat("en-CA", {
  timeZone: "America/Lima",
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
});
const horaLima = new Intl.DateTimeFormat("en-GB", {
  timeZone: "America/Lima",
  hour: "2-digit",
  minute: "2-digit",
  hourCycle: "h23",
});

/** Timestamp ISO → minutos desde medianoche (hora de Lima). */
function minutosLima(iso: string | null): number | null {
  if (!iso) return null;
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return null;
  const [h, m] = horaLima.format(d).split(":").map(Number);
  return h * 60 + m;
}

/** "HH:MM[:SS]" → minutos. */
function hhmmAMin(v: string | null): number | null {
  if (!v) return null;
  const [h, m] = v.split(":").map(Number);
  return Number.isFinite(h) && Number.isFinite(m) ? h * 60 + m : null;
}

const hhmmTexto = (v: string | null) => (v ? v.slice(0, 5) : null);

function minutosEntre(desde: string | null, hasta: string | null): number | null {
  if (!desde || !hasta) return null;
  const min = Math.round((new Date(hasta).getTime() - new Date(desde).getTime()) / 60000);
  return min >= 0 ? min : null;
}

function sumarDias(fecha: string, dias: number): string {
  const d = new Date(`${fecha}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + dias);
  return d.toISOString().slice(0, 10);
}

/** Horario de un tramo del historial, con su refrigerio y días no laborables. */
type Schedule = {
  type: "fixed" | "flexible" | "free";
  start: string | null;
  end: string | null;
  tolerance: number;
  requiredMinutes: number | null;
  refreshment: {
    type: "fixed" | "flexible" | "free";
    start: string | null;
    end: string | null;
    minutes: number | null;
  } | null;
  nonWorkingDays: { type: "fixed"; days: boolean[] } | { type: "flexible"; numberDays: number } | null;
};

/** Un tramo del historial: este horario rigió desde `start` hasta `end` (null = sigue vigente). Fechas YYYY-MM-DD. */
type SchedulePeriod = { start: string; end: string | null; schedule: Schedule };

function armarHorario(sch: Row, r: Row | null, n: Row | null): Schedule {
  return {
    type: sch.stff_schdl_type as Schedule["type"],
    start: hhmmTexto(sch.stff_schdl_start),
    end: hhmmTexto(sch.stff_schdl_end),
    tolerance: Number(sch.stff_schdl_start_tolerance ?? 0),
    requiredMinutes: (sch.stff_schdl_required_minutes as number | null) ?? null,
    refreshment: r
      ? {
          type: r.stff_rfrshmnth_type as "fixed" | "flexible" | "free",
          start: hhmmTexto(r.stff_rfrshmnth_start),
          end: hhmmTexto(r.stff_rfrshmnth_end),
          minutes: (r.stff_rfrshmnth_minutes as number | null) ?? null,
        }
      : null,
    nonWorkingDays: !n
      ? null
      : n.stff_nn_wrkng_day_type === "fixed"
        ? {
            type: "fixed" as const,
            days: [
              n.stff_nn_wrkng_day_monday, n.stff_nn_wrkng_day_tuesday, n.stff_nn_wrkng_day_wednesday,
              n.stff_nn_wrkng_day_thursday, n.stff_nn_wrkng_day_friday, n.stff_nn_wrkng_day_saturday,
              n.stff_nn_wrkng_day_sunday,
            ].map((d) => d === true),
          }
        : { type: "flexible" as const, numberDays: Number(n.stff_nn_wrkng_day_number_days ?? 0) },
  };
}

/** Lee varias filas por id en una sola consulta (devuelve un Map id → fila). */
async function cargarPorIds(table: string, idColumn: string, ids: number[]): Promise<Map<number, Row>> {
  if (ids.length === 0) return new Map();
  const { data, error } = await supabaseAdmin.from(table).select("*").in(idColumn, ids);
  if (error) fail("No se pudo cargar el horario.", error);
  return new Map(((data ?? []) as Row[]).map((r) => [r[idColumn] as number, r]));
}

/**
 * Historial de horarios del contrato, del más antiguo al más reciente.
 * Cada tramo dice desde qué día rigió un horario (schdl_hstry_start) y hasta cuál (schdl_hstry_end, null = vigente).
 */
async function loadReportSchedules(contractId: number): Promise<SchedulePeriod[]> {
  const { data: hist, error: hErr } = await supabaseAdmin
    .from("staff_schedule_history")
    .select("stff_schdl_hstry_id, stff_schdl_id, schdl_hstry_start, schdl_hstry_end")
    .eq("stff_cntrt_id", contractId)
    .order("schdl_hstry_start", { ascending: true })
    .order("stff_schdl_hstry_id", { ascending: true });
  if (hErr) fail("No se pudo cargar el horario del contrato.", hErr);
  const tramos = (hist ?? []) as Row[];
  if (tramos.length === 0) return [];

  const ids = (values: unknown[]) => [...new Set(values.filter((v): v is number => typeof v === "number"))];

  const schedules = await cargarPorIds("staff_schedules", "stff_schdl_id", ids(tramos.map((t) => t.stff_schdl_id)));
  const [refreshments, nonWorking] = await Promise.all([
    cargarPorIds("staff_refreshments", "stff_rfrshmnth_id", ids([...schedules.values()].map((x) => x.stff_rfrshmnth_id))),
    cargarPorIds("staff_non_working_days", "stff_nn_wrkng_day_id", ids([...schedules.values()].map((x) => x.stff_nn_wrkng_day_id))),
  ]);

  const periods: SchedulePeriod[] = [];
  for (const t of tramos) {
    const sch = schedules.get(t.stff_schdl_id as number);
    if (!sch) continue;
    periods.push({
      start: String(t.schdl_hstry_start).slice(0, 10),
      end: t.schdl_hstry_end ? String(t.schdl_hstry_end).slice(0, 10) : null,
      schedule: armarHorario(
        sch,
        sch.stff_rfrshmnth_id ? (refreshments.get(sch.stff_rfrshmnth_id as number) ?? null) : null,
        sch.stff_nn_wrkng_day_id ? (nonWorking.get(sch.stff_nn_wrkng_day_id as number) ?? null) : null,
      ),
    });
  }
  return periods;
}

/**
 * Índice del tramo que rige en `fecha`: el último que empezó en o antes de ese día.
 * Si la fecha es anterior a todos los tramos, se usa el primero. (Ordenar por inicio ya lo garantiza `loadReportSchedules`.)
 */
function tramoDeFecha(periods: SchedulePeriod[], fecha: string): number {
  let idx = 0;
  for (let i = 0; i < periods.length; i++) {
    if (periods[i].start <= fecha) idx = i;
  }
  return idx;
}

/** Valores derivados de un horario que se usan al calcular una fila. */
function reglasDeHorario(schedule: Schedule | null) {
  const ref = schedule?.refreshment ?? null;
  const refInicio = ref ? hhmmAMin(ref.start) : null;
  const refFin = ref ? hhmmAMin(ref.end) : null;
  return {
    schedule,
    tolerancia: schedule?.tolerance ?? 0,
    inicioMin: schedule?.type === "fixed" ? hhmmAMin(schedule.start) : null,
    ref,
    refFin,
    refPermitido: ref?.minutes ?? (refInicio !== null && refFin !== null ? refFin - refInicio : null),
    noLaborable: (fecha: string) => {
      const nwd = schedule?.nonWorkingDays;
      if (nwd?.type !== "fixed") return false;
      const dia = (new Date(`${fecha}T00:00:00Z`).getUTCDay() + 6) % 7; // 0 = lunes
      return nwd.days[dia] === true;
    },
  };
}

/**
 * Calcula UNA fila del reporte. La usan el reporte completo y la fila suelta.
 * Cada día se evalúa con el horario que regía ESE día (según el historial), no con el actual.
 */
function crearConstructorDeFilas(periods: SchedulePeriod[], hoy: string) {
  const sinHorario = reglasDeHorario(null);
  const reglas = periods.map((p) => reglasDeHorario(p.schedule));

  return (
    fecha: string,
    a: Row | null,
    adelanto: number | null,
    incidencias: { amount: number; description: string }[],
  ) => {
    const scheduleIndex = periods.length > 0 ? tramoDeFecha(periods, fecha) : null;
    const { schedule, tolerancia, inicioMin, ref, refFin, refPermitido, noLaborable } =
      scheduleIndex !== null ? reglas[scheduleIndex] : sinHorario;

    const llegada = minutosLima(a?.att_schedule_start ?? null);
    const receso = minutosEntre(a?.att_refreshment_start ?? null, a?.att_refreshment_end ?? null);
    const retornoRefrigerio = minutosLima(a?.att_refreshment_end ?? null);
    const trabajados = minutosEntre(a?.att_schedule_start ?? null, a?.att_schedule_end ?? null);

    let retrasoIngreso: number | null = null;
    if (schedule?.type === "fixed") {
      if (inicioMin !== null && llegada !== null && llegada > inicioMin + tolerancia) {
        retrasoIngreso = llegada - inicioMin;
      }
    } else if (schedule?.type === "flexible" && schedule.requiredMinutes && trabajados !== null) {
      const faltan = schedule.requiredMinutes - Math.max(0, trabajados - (receso ?? 0));
      if (faltan > tolerancia) retrasoIngreso = faltan;
    }

    let demoraRefrigerio: number | null = null;
    if (ref?.type === "fixed") {
      if (refFin !== null && retornoRefrigerio !== null && retornoRefrigerio > refFin) {
        demoraRefrigerio = retornoRefrigerio - refFin;
      }
    } else if (ref?.type === "flexible") {
      if (receso !== null && refPermitido !== null && refPermitido > 0 && receso > refPermitido) {
        demoraRefrigerio = receso - refPermitido;
      }
    }

    return {
      att_id: (a?.att_id as number | undefined) ?? null,
      date: fecha,
      /** Posición, dentro de `schedules` del reporte, del horario que rigió este día (null = sin horario). */
      schedule_index: scheduleIndex,
      arrival: a?.att_schedule_start ?? null,
      refreshment_start: a?.att_refreshment_start ?? null,
      refreshment_end: a?.att_refreshment_end ?? null,
      departure: a?.att_schedule_end ?? null,
      is_worked: !!a?.att_schedule_start,
      is_absence: !a?.att_schedule_start && fecha < hoy && !noLaborable(fecha),
      delay_minutes: retrasoIngreso,
      refreshment_delay_minutes: demoraRefrigerio,
      advancement: adelanto,
      incidents: incidencias,
      observation: a?.att_observation ?? null,
      justification_absence: a?.att_justification_absence ?? null,
      justification_delay: a?.att_justification_delay ?? null,
      justification_refreshment_delay: a?.att_justification_refreshment_delay ?? null,
    };
  };
}
/** GET /attendance/report?stffId=&contractId= → una fila por cada día del contrato (hasta hoy). */
export async function getAttendanceReport(ctx: AccessContext, stffId: number, contractId: number) {
  const staff = await assertStaffOfCustomer(
    ctx,
    stffId,
    "stff_id, stff_name, stff_lastname, stff_dni, stff_link_img",
  );

  const { data: contracts, error: cErr } = await supabaseAdmin
    .from("staff_contracts")
    .select(
      `stff_cntrt_id, cntrt_start_date, cntrt_end_date, cntrt_salary_amount, cntrt_afp_discount,
       cntrt_insurance_premium, cntrt_discount_absence, cntrt_discount_delay, cntrt_discount_refreshment_delay`,
    )
    .eq("stff_id", stffId)
    .order("stff_cntrt_id", { ascending: true });
  if (cErr) fail("No se pudieron cargar los contratos.", cErr);

  const index = (contracts ?? []).findIndex((c) => c.stff_cntrt_id === contractId);
  if (index < 0) throw new AppError(404, "El contrato no existe.", "NOT_FOUND");
  const contract = contracts![index];

  const hoy = fechaLima.format(new Date());
  const startDate = contract.cntrt_start_date ? String(contract.cntrt_start_date).slice(0, 10) : null;
  const endDate = contract.cntrt_end_date ? String(contract.cntrt_end_date).slice(0, 10) : null;

  const periods = await loadReportSchedules(contractId);

  // Asistencias del personal dentro del contrato.
  let attQuery = supabaseAdmin.from(TABLE).select(ATT_COLUMNS).eq("stff_id", stffId).order("att_date");
  if (startDate) attQuery = attQuery.gte("att_date", startDate);
  if (endDate) attQuery = attQuery.lte("att_date", endDate);
  const { data: attData, error: attErr } = await attQuery;
  if (attErr) fail("No se pudo cargar la asistencia.", attErr);
  const atts = (attData ?? []) as unknown as Row[];
  const attByDate = new Map<string, Row>(atts.map((a) => [String(a.att_date).slice(0, 10), a]));

  // Adelantos e incidencias de esas asistencias.
  const ids = atts.map((a) => a.att_id as number);
  const [adv, inc] = ids.length
    ? await Promise.all([
        supabaseAdmin.from(ADVANCEMENTS_TABLE).select("att_id, stff_dvncmnt_amount").in("att_id", ids),
        supabaseAdmin
          .from(INCIDENTS_TABLE)
          .select("att_id, stff_dscount_amount, stff_dscount_description")
          .in("att_id", ids),
      ])
    : [{ data: [], error: null }, { data: [], error: null }];
  if (adv.error || inc.error) fail("No se pudieron cargar los adelantos o incidencias.", adv.error ?? inc.error);

  const advByAtt = new Map<number, number>();
  for (const r of (adv.data ?? []) as Row[]) {
    advByAtt.set(r.att_id, (advByAtt.get(r.att_id) ?? 0) + Number(r.stff_dvncmnt_amount));
  }
  const incByAtt = new Map<number, { amount: number; description: string }[]>();
  for (const r of (inc.data ?? []) as Row[]) {
    const lista = incByAtt.get(r.att_id) ?? [];
    lista.push({ amount: Number(r.stff_dscount_amount), description: String(r.stff_dscount_description ?? "") });
    incByAtt.set(r.att_id, lista);
  }

  // Rango del reporte: desde el inicio del contrato hasta su fin (o hoy).
  const rangeStart = startDate ?? (atts[0] ? String(atts[0].att_date).slice(0, 10) : null);
  const rangeEnd = rangeStart ? (endDate && endDate < hoy ? endDate : hoy) : null;

  const construirFila = crearConstructorDeFilas(periods, hoy);
  const rows = [];
  if (rangeStart && rangeEnd && rangeStart <= rangeEnd) {
    let fecha = rangeStart;
    for (let n = 0; fecha <= rangeEnd && n < 3700; n++, fecha = sumarDias(fecha, 1)) {
      const a = attByDate.get(fecha) ?? null;
      rows.push(
        construirFila(fecha, a, a ? (advByAtt.get(a.att_id) ?? null) : null, a ? (incByAtt.get(a.att_id) ?? []) : []),
      );
    }
  }

  const imgPath = staff.stff_link_img ? `${STAFF_IMG_FOLDER}/${staff.stff_link_img}` : null;
  const urls = await createSignedUrls(ctx.bucketName, imgPath ? [imgPath] : []);

  return {
    staff: {
      id: staff.stff_id as number,
      name: staff.stff_name as string,
      lastname: staff.stff_lastname as string,
      dni: staff.stff_dni as string,
      img_url: imgPath ? (urls.get(imgPath) ?? null) : null,
    },
    contract: {
      id: contract.stff_cntrt_id as number,
      number: index + 1,
      start_date: startDate,
      end_date: endDate,
      range_start: rangeStart,
      range_end: rangeEnd,
      // Datos de pago del contrato (para el cuadro de resumen del Excel).
      salary_amount: Number(contract.cntrt_salary_amount ?? 0),
      afp_discount: Number(contract.cntrt_afp_discount ?? 0),
      insurance_premium: Number(contract.cntrt_insurance_premium ?? 0),
      discount_absence: contract.cntrt_discount_absence === true,
      discount_delay: contract.cntrt_discount_delay === true,
      discount_refreshment_delay: contract.cntrt_discount_refreshment_delay === true,
    },
    /** Horario vigente hoy (el último del historial). Se mantiene por compatibilidad. */
    schedule: periods.length > 0 ? periods[periods.length - 1].schedule : null,
    /** Historial completo de horarios del contrato, del más antiguo al más reciente. */
    schedules: periods,
    rows,
  };
}
/** GET /attendance/report/row?stffId=&contractId=&date= → { row } (null si el día ya no está en el rango) */
export async function getAttendanceReportRow(ctx: AccessContext, stffId: number, contractId: number, date: string) {
  await assertStaffOfCustomer(ctx, stffId, "stff_id");

  const { data: contract, error: cErr } = await supabaseAdmin
    .from("staff_contracts")
    .select("stff_cntrt_id, cntrt_start_date, cntrt_end_date")
    .eq("stff_cntrt_id", contractId)
    .eq("stff_id", stffId)
    .maybeSingle();
  if (cErr) fail("No se pudo cargar el contrato.", cErr);
  if (!contract) throw new AppError(404, "El contrato no existe.", "NOT_FOUND");

  const hoy = fechaLima.format(new Date());
  const startDate = contract.cntrt_start_date ? String(contract.cntrt_start_date).slice(0, 10) : null;
  const endDate = contract.cntrt_end_date ? String(contract.cntrt_end_date).slice(0, 10) : null;
  const rangeEnd = endDate && endDate < hoy ? endDate : hoy;
  if ((startDate && date < startDate) || date > rangeEnd) return { row: null };

  const [periods, attRes] = await Promise.all([
    loadReportSchedules(contractId),
    supabaseAdmin.from(TABLE).select(ATT_COLUMNS).eq("stff_id", stffId).eq("att_date", date).maybeSingle(),
  ]);
  if (attRes.error) fail("No se pudo cargar la asistencia.", attRes.error);
  const a = (attRes.data ?? null) as unknown as Row | null;

  let adelanto: number | null = null;
  let incidencias: { amount: number; description: string }[] = [];
  if (a) {
    const [adv, inc] = await Promise.all([
      supabaseAdmin.from(ADVANCEMENTS_TABLE).select("stff_dvncmnt_amount").eq("att_id", a.att_id),
      supabaseAdmin.from(INCIDENTS_TABLE).select("stff_dscount_amount, stff_dscount_description").eq("att_id", a.att_id),
    ]);
    if (adv.error || inc.error) fail("No se pudieron cargar los adelantos o incidencias.", adv.error ?? inc.error);
    const advRows = (adv.data ?? []) as Row[];
    adelanto = advRows.length ? advRows.reduce((s, r) => s + Number(r.stff_dvncmnt_amount), 0) : null;
    incidencias = ((inc.data ?? []) as Row[]).map((r) => ({
      amount: Number(r.stff_dscount_amount),
      description: String(r.stff_dscount_description ?? ""),
    }));
  }

  return { row: crearConstructorDeFilas(periods, hoy)(date, a, adelanto, incidencias) };
}
/* ───────── Eliminar incidencias y adelantos (solo customer o staff Administrador) ───────── */

const ADMIN_ROLE = "Administrador";

/**
 * Devuelve el customer dueño si la sesión es:
 *  - el customer, o
 *  - un staff con stff_active = true, stff_access_system = true y rol "Administrador".
 * En cualquier otro caso devuelve null.
 */
async function resolveDeleteAccess(req: Request): Promise<{ custId: number } | null> {
  const user = await requireUser(req);

  const customer = await findByAuthId(user.id);
  if (customer) {
    if (!customer.cust_is_active) throw new AppError(403, "Tu cuenta está desactivada. Contacta a soporte.");
    return { custId: customer.cust_id };
  }

  const { data, error } = await supabaseAdmin
    .from("staffs")
    .select("cust_id, stff_active, stff_access_system, customer_roles(cust_role_name), customers!inner(cust_is_active)")
    .eq("stff_auth_id", user.id)
    .maybeSingle();
  if (error) fail("No se pudo validar tu permiso.", error);
  if (!data) return null;

  const role = one<Row>(data.customer_roles)?.cust_role_name;
  const customerActive = one<Row>(data.customers)?.cust_is_active === true;
  const allowed =
    data.stff_active === true && data.stff_access_system === true && role === ADMIN_ROLE && customerActive;

  return allowed ? { custId: data.cust_id as number } : null;
}

async function requireDeleteAccess(req: Request): Promise<{ custId: number }> {
  const access = await resolveDeleteAccess(req);
  if (!access) {
    throw new AppError(403, "Solo el titular de la cuenta o un administrador puede eliminar esto.", "FORBIDDEN");
  }
  return access;
}

/** El registro (asistencia) debe pertenecer al customer de la sesión. */
async function assertAttendanceOfCustomer(custId: number, attId: number) {
  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .select("att_id, staffs!inner(cust_id)")
    .eq("att_id", attId)
    .eq("staffs.cust_id", custId)
    .maybeSingle();
  if (error) fail("No se pudo validar el registro.", error);
  if (!data) throw new AppError(404, "El registro no existe.", "NOT_FOUND");
}

/** GET /attendance/can-delete → { allowed } (solo sirve para mostrar u ocultar el tacho) */
export async function canDeleteRecords(req: Request) {
  return { allowed: (await resolveDeleteAccess(req)) !== null };
}

/** DELETE /attendance/incidents?id= → { id, total } (total = incidencias que quedan en ese registro) */
export async function deleteIncident(req: Request, id: number) {
  const { custId } = await requireDeleteAccess(req);

  const { data: row, error: readErr } = await supabaseAdmin
    .from(INCIDENTS_TABLE)
    .select("att_id")
    .eq("stff_dscount_ncdnt_id", id)
    .maybeSingle();
  if (readErr) fail("No se pudo validar la incidencia.", readErr);
  if (!row) throw new AppError(404, "La incidencia no existe.", "NOT_FOUND");
  await assertAttendanceOfCustomer(custId, row.att_id as number);

  const { error } = await supabaseAdmin.from(INCIDENTS_TABLE).delete().eq("stff_dscount_ncdnt_id", id);
  if (error) fail("No se pudo eliminar la incidencia.", error);

  const { count, error: countErr } = await supabaseAdmin
    .from(INCIDENTS_TABLE)
    .select("stff_dscount_ncdnt_id", { count: "exact", head: true })
    .eq("att_id", row.att_id);
  if (countErr) fail("No se pudo contar las incidencias.", countErr);

  return { id, total: count ?? 0 };
}

/** DELETE /attendance/advancements?id= → { id } */
export async function deleteAdvancement(req: Request, id: number) {
  const { custId } = await requireDeleteAccess(req);

  const { data: row, error: readErr } = await supabaseAdmin
    .from(ADVANCEMENTS_TABLE)
    .select("att_id")
    .eq("stff_dvncmnt_id", id)
    .maybeSingle();
  if (readErr) fail("No se pudo validar el adelanto.", readErr);
  if (!row) throw new AppError(404, "El adelanto no existe.", "NOT_FOUND");
  await assertAttendanceOfCustomer(custId, row.att_id as number);

  const { error } = await supabaseAdmin.from(ADVANCEMENTS_TABLE).delete().eq("stff_dvncmnt_id", id);
  if (error) fail("No se pudo eliminar el adelanto.", error);

  return { id };
}