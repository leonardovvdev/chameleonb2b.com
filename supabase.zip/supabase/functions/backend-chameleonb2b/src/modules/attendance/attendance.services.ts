import { AppError } from "../../shared/http.ts";
import { supabaseAdmin } from "../../shared/supabase.ts";
import { sanitizeSearchWord, setStaffActive, signedImageUrls } from "../staffs/staff.services.ts";
import {
  type ContractRow,
  getLatestContract,
  setContractStartDate,
} from "../staff-contracts/staff-contracts.services.ts";
import type {
  AbsenceResult,
  AttendanceDetail,
  AttendanceItem,
  AttendanceJustificationResult,
  AttendanceJustificationType,
  AttendanceObservationResult,
  AttendanceResult,
  AttendanceRow,
  AttendanceTimes,
  AttendanceTimesResult,
  CheckInResult,
  PendingAttendanceRow,
  PendingFilters,
  PendingStaffItem,
  PendingStaffRow,
} from "./attendance.types.ts";

const COLUMNS = `
  att_id, att_date, att_schedule_start, att_refreshment_start, att_refreshment_end, att_schedule_end,
  att_justification_absence, att_justification_delay, att_justification_refreshment_delay, stff_id,
  staffs!inner(
    stff_name, stff_lastname, stff_dni, stff_link_img, cust_id,
    job_position:customer_job_positions(name:cust_jb_pstn_name),
    schedule:staff_schedules(type:stff_schdl_type, start:stff_schdl_start, tolerance:stff_schdl_start_tolerance)
  )
`;

/** Relación muchos-a-uno: llega como objeto (se acepta arreglo por seguridad). */
function one<T>(value: T | T[] | null | undefined): T | null {
  return (Array.isArray(value) ? value[0] : value) ?? null;
}

/** Fecha de HOY en Lima (YYYY-MM-DD): la misma zona que usa el DEFAULT de attendance.att_date. */
function todayInLima(): string {
  return new Intl.DateTimeFormat("en-CA", { timeZone: "America/Lima" }).format(new Date());
}

/** Asistencias (att_date) de la fecha, solo del personal del customer. */
async function fetchRows(custId: number, date: string): Promise<AttendanceRow[]> {
  const { data, error } = await supabaseAdmin
    .from("attendance")
    .select(COLUMNS)
    .eq("att_date", date)
    .eq("staffs.cust_id", custId)
    .order("att_id", { ascending: true });

  if (error) {
    console.error("attendance.fetchRows:", error);
    throw new AppError(500, "No se pudo obtener la asistencia.");
  }
  return (data ?? []) as unknown as AttendanceRow[];
}

/** Personal activo del customer. */
async function countActiveStaff(custId: number): Promise<number> {
  const { count, error } = await supabaseAdmin
    .from("staffs")
    .select("stff_id", { count: "exact", head: true })
    .eq("cust_id", custId)
    .eq("stff_active", true);

  if (error) {
    console.error("attendance.countActiveStaff:", error);
    throw new AppError(500, "No se pudo contar el personal.");
  }
  return count ?? 0;
}

/** READ: asistencias de una fecha del customer + cantidad de personal activo. */
export async function listAttendanceByDate(
  custId: number,
  bucketName: string,
  date: string,
): Promise<AttendanceResult> {
  const [rows, totalStaff] = await Promise.all([fetchRows(custId, date), countActiveStaff(custId)]);

  const pairs = rows
    .map((row) => ({ row, staff: one(row.staffs) }))
    .filter((p): p is { row: AttendanceRow; staff: NonNullable<typeof p.staff> } => !!p.staff);

  // URLs firmadas de todas las fotos en una sola llamada.
  const urls = await signedImageUrls(bucketName, pairs.map((p) => p.staff.stff_link_img));

  const items: AttendanceItem[] = pairs.map(({ row, staff }) => {
    const schedule = one(staff.schedule);
    return {
      att_id: row.att_id,
      att_fecha: row.att_date,
      att_inicio_jornada: row.att_schedule_start,
      att_inicio_receso: row.att_refreshment_start,
      att_fin_receso: row.att_refreshment_end,
      att_fin_jornada: row.att_schedule_end,

      att_justification_absence: row.att_justification_absence,
      att_justification_delay: row.att_justification_delay,
      att_justification_refreshment_delay: row.att_justification_refreshment_delay,

      stff_id: row.stff_id,
      stff_name: staff.stff_name,
      stff_lastname: staff.stff_lastname,
      stff_dni: staff.stff_dni,
      job_position_name: one(staff.job_position)?.name ?? null,

      schedule_type: schedule?.type ?? null,
      schedule_start: schedule?.start ?? null,
      schedule_tolerance: schedule?.tolerance ?? null,

      img_url: staff.stff_link_img ? urls.get(staff.stff_link_img) ?? null : null,
    };
  });

  return { items, total_staff: totalStaff };
}

/* ───────────────────────── Nuevo registro (ingreso) ───────────────────────── */

const PENDING_COLUMNS = `
  stff_id, stff_name, stff_lastname, stff_dni, stff_link_img,
  job_position:customer_job_positions(name:cust_jb_pstn_name),
  role:customer_roles(name:cust_role_name),
  attendance(att_id, att_schedule_start, att_justification_absence)
`;

const hasText = (value: string | null | undefined): boolean => !!value && value.trim() !== "";

/**
 * Personal ACTIVO del customer cuya fila de hoy (si existe) NO cumple `isDone`.
 * `attendance(...)` se filtra con att_date = hoy, así que solo trae la fila de hoy.
 */
async function listPendingStaff(
  custId: number,
  bucketName: string,
  filters: PendingFilters,
  isDone: (att: PendingAttendanceRow) => boolean,
): Promise<PendingStaffItem[]> {
  let query = supabaseAdmin
    .from("staffs")
    .select(PENDING_COLUMNS)
    .eq("cust_id", custId)
    .eq("stff_active", true)
    .eq("attendance.att_date", todayInLima());

  // Cada palabra debe aparecer en el nombre, el apellido o el DNI.
  const words = filters.search.split(/\s+/).map(sanitizeSearchWord).filter(Boolean);
  for (const word of words) {
    query = query.or(
      `stff_name.ilike.%${word}%,stff_lastname.ilike.%${word}%,stff_dni.ilike.%${word}%`,
    );
  }

  if (filters.cargoId !== null) query = query.eq("cust_jb_pstn_id", filters.cargoId);
  if (filters.rolId !== null) query = query.eq("cust_role_id", filters.rolId);

  const { data, error } = await query
    .order("stff_name", { ascending: true })
    .order("stff_lastname", { ascending: true })
    .order("stff_id", { ascending: true });

  if (error) {
    console.error("attendance.listPendingStaff:", error);
    throw new AppError(500, "No se pudo obtener la lista de personal.");
  }

  const rows = ((data ?? []) as unknown as PendingStaffRow[]).filter(
    (row) => !(row.attendance ?? []).some(isDone),
  );

  const urls = await signedImageUrls(bucketName, rows.map((r) => r.stff_link_img));

  return rows.map((row) => ({
    stff_id: row.stff_id,
    stff_name: row.stff_name,
    stff_lastname: row.stff_lastname,
    stff_dni: row.stff_dni,
    job_position_name: one(row.job_position)?.name ?? null,
    role_name: one(row.role)?.name ?? null,
    img_url: row.stff_link_img ? urls.get(row.stff_link_img) ?? null : null,
  }));
}

/** READ: personal activo que todavía NO tiene att_schedule_start hoy. */
export const listPendingCheckIn = (custId: number, bucketName: string, filters: PendingFilters) =>
  listPendingStaff(custId, bucketName, filters, (att) => att.att_schedule_start !== null);

/** READ: personal activo sin ingreso y sin ausencia registrada hoy. */
export const listPendingAbsence = (custId: number, bucketName: string, filters: PendingFilters) =>
  listPendingStaff(
    custId,
    bucketName,
    filters,
    (att) => att.att_schedule_start !== null || hasText(att.att_justification_absence),
  );

/** El staff debe ser de este customer y estar activo. */
async function assertActiveStaff(custId: number, stffId: number): Promise<void> {
  const { data: staff, error } = await supabaseAdmin
    .from("staffs")
    .select("stff_id, stff_active")
    .eq("stff_id", stffId)
    .eq("cust_id", custId)
    .maybeSingle();

  if (error) {
    console.error("attendance.assertActiveStaff:", error);
    throw new AppError(500, "No se pudo consultar al personal.");
  }
  if (!staff) throw new AppError(404, "El personal no existe.", "NOT_FOUND");
  if (!(staff as { stff_active: boolean }).stff_active) {
    throw new AppError(400, "El personal está desactivado.", "STAFF_INACTIVE");
  }
}

/** "2026-10-28" → "28/10/2026" (para mostrar en mensajes). */
const formatDate = (isoDate: string) => isoDate.split("-").reverse().join("/");

/**
 * Antes de registrar una jornada se revisa el contrato más reciente del personal:
 *   - Si hoy es posterior a `cntrt_end_date` el contrato ya terminó: se desactiva al personal
 *     y no se registra la jornada (400, CONTRACT_ENDED).
 *   - Devuelve el contrato para que, una vez registrada la jornada, se complete su inicio.
 * Un contrato sigue vigente durante todo el día de `cntrt_end_date`.
 */
async function assertContractNotEnded(custId: number, stffId: number, today: string): Promise<ContractRow | null> {
  const contract = await getLatestContract(stffId);

  if (contract?.cntrt_end_date && today > contract.cntrt_end_date) {
    await setStaffActive(stffId, custId, false);
    throw new AppError(
      400,
      `El contrato de este personal terminó el ${formatDate(contract.cntrt_end_date)}. Se desactivó al personal.`,
      "CONTRACT_ENDED",
    );
  }
  return contract;
}

/**
 * CREATE/UPDATE: registra el ingreso (att_schedule_start = ahora) del staff en la fecha de hoy.
 *   - Verifica el contrato: si ya terminó (hoy > cntrt_end_date) desactiva al personal y no registra.
 *   - Si su contrato no tiene `cntrt_start_date`, la primera jornada la fija en la fecha de hoy.
 */
export async function registerCheckIn(custId: number, stffId: number): Promise<CheckInResult> {
  // 1) El staff debe ser de este customer y estar activo.
  await assertActiveStaff(custId, stffId);

  const today = todayInLima();

  // 2) Su contrato no debe haber terminado.
  const contract = await assertContractNotEnded(custId, stffId, today);

  // 3) Se registra el ingreso.
  const result = await saveCheckIn(stffId, today);

  // 4) Primera jornada: el contrato empieza hoy (solo si aún no tenía fecha de inicio).
  if (contract && !contract.cntrt_start_date) {
    await setContractStartDate(contract.stff_cntrt_id, today);
  }
  return result;
}

/**
 * Guarda el ingreso en `attendance`:
 *   - No existe fila de hoy                  → la crea.
 *   - Existe, pero sin att_schedule_start    → completa esa columna.
 *   - Existe y ya tiene att_schedule_start   → 409 (ya registró su ingreso).
 */
async function saveCheckIn(stffId: number, today: string): Promise<CheckInResult> {
  const alreadyRegistered = () =>
    new AppError(409, "Este personal ya registró su ingreso hoy.", "ALREADY_REGISTERED");

  const now = new Date().toISOString();

  // 2) ¿Ya hay una fila de hoy?
  const { data: existing, error: readError } = await supabaseAdmin
    .from("attendance")
    .select("att_id, att_schedule_start")
    .eq("stff_id", stffId)
    .eq("att_date", today)
    .maybeSingle();

  if (readError) {
    console.error("attendance.registerCheckIn(read):", readError);
    throw new AppError(500, "No se pudo consultar la asistencia.");
  }

  // 3a) Fila existente sin ingreso: se completa (el .is(...null) evita pisar un ingreso simultáneo).
  if (existing) {
    const row = existing as { att_id: number; att_schedule_start: string | null };
    if (row.att_schedule_start) throw alreadyRegistered();

    const { data, error } = await supabaseAdmin
      .from("attendance")
      .update({ att_schedule_start: now })
      .eq("att_id", row.att_id)
      .is("att_schedule_start", null)
      .select("att_id")
      .maybeSingle();

    if (error) {
      console.error("attendance.registerCheckIn(update):", error);
      throw new AppError(500, "No se pudo registrar la asistencia.");
    }
    if (!data) throw alreadyRegistered();
    return { att_id: (data as { att_id: number }).att_id, att_schedule_start: now };
  }

  // 3b) Sin fila: se crea. Si otro registro simultáneo la creó antes, la restricción UNIQUE avisa.
  const { data, error } = await supabaseAdmin
    .from("attendance")
    .insert({ stff_id: stffId, att_date: today, att_schedule_start: now })
    .select("att_id")
    .single();

  if (error || !data) {
    if (error?.code === "23505") throw alreadyRegistered();
    console.error("attendance.registerCheckIn(insert):", error);
    throw new AppError(500, "No se pudo registrar la asistencia.");
  }
  return { att_id: (data as { att_id: number }).att_id, att_schedule_start: now };
}

/**
 * CREATE/UPDATE: registra la ausencia de hoy (att_justification_absence) del staff.
 *   - No existe fila de hoy                       → la crea (sin att_schedule_start).
 *   - Existe, sin ingreso ni ausencia             → completa la justificación.
 *   - Existe con ingreso o con ausencia           → 409.
 */
export async function registerAbsence(
  custId: number,
  stffId: number,
  description: string,
): Promise<AbsenceResult> {
  const alreadyCheckedIn = () =>
    new AppError(409, "Este personal ya registró su ingreso hoy.", "ALREADY_REGISTERED");
  const alreadyAbsent = () =>
    new AppError(409, "Este personal ya tiene una ausencia registrada hoy.", "ABSENCE_ALREADY_REGISTERED");

  await assertActiveStaff(custId, stffId);

  const today = todayInLima();

  const { data: existing, error: readError } = await supabaseAdmin
    .from("attendance")
    .select("att_id, att_schedule_start, att_justification_absence")
    .eq("stff_id", stffId)
    .eq("att_date", today)
    .maybeSingle();

  if (readError) {
    console.error("attendance.registerAbsence(read):", readError);
    throw new AppError(500, "No se pudo consultar la asistencia.");
  }

  if (existing) {
    const row = existing as {
      att_id: number;
      att_schedule_start: string | null;
      att_justification_absence: string | null;
    };
    if (row.att_schedule_start) throw alreadyCheckedIn();
    if (hasText(row.att_justification_absence)) throw alreadyAbsent();

    // .is(...null) evita pisar un ingreso que se registre al mismo tiempo.
    const { data, error } = await supabaseAdmin
      .from("attendance")
      .update({ att_justification_absence: description })
      .eq("att_id", row.att_id)
      .is("att_schedule_start", null)
      .select("att_id")
      .maybeSingle();

    if (error) {
      console.error("attendance.registerAbsence(update):", error);
      throw new AppError(500, "No se pudo registrar la ausencia.");
    }
    if (!data) throw alreadyCheckedIn();
    return { att_id: (data as { att_id: number }).att_id, att_justification_absence: description };
  }

  const { data, error } = await supabaseAdmin
    .from("attendance")
    .insert({ stff_id: stffId, att_date: today, att_justification_absence: description })
    .select("att_id")
    .single();

  if (error || !data) {
    if (error?.code === "23505") throw alreadyAbsent();
    console.error("attendance.registerAbsence(insert):", error);
    throw new AppError(500, "No se pudo registrar la ausencia.");
  }
  return { att_id: (data as { att_id: number }).att_id, att_justification_absence: description };
}

/* ───────────────────────── Detalle y edición de un registro ───────────────────────── */

/** El registro debe existir y ser de personal de este customer. Devuelve el stff_id. */
export async function assertAttendanceOfCustomer(custId: number, attId: number): Promise<number> {
  const { data, error } = await supabaseAdmin
    .from("attendance")
    .select("att_id, stff_id, staffs!inner(cust_id)")
    .eq("att_id", attId)
    .eq("staffs.cust_id", custId)
    .maybeSingle();

  if (error) {
    console.error("attendance.assertAttendanceOfCustomer:", error);
    throw new AppError(500, "No se pudo consultar el registro.");
  }
  if (!data) throw new AppError(404, "El registro de asistencia no existe.", "NOT_FOUND");
  return (data as { stff_id: number }).stff_id;
}

/** READ: observación, rol y total de registros del personal de una asistencia. */
export async function getAttendanceDetail(custId: number, attId: number): Promise<AttendanceDetail> {
  const { data, error } = await supabaseAdmin
    .from("attendance")
    .select("att_id, stff_id, att_observation, staffs!inner(cust_id, role:customer_roles(name:cust_role_name))")
    .eq("att_id", attId)
    .eq("staffs.cust_id", custId)
    .maybeSingle();

  if (error) {
    console.error("attendance.getAttendanceDetail:", error);
    throw new AppError(500, "No se pudo obtener el detalle del registro.");
  }
  if (!data) throw new AppError(404, "El registro de asistencia no existe.", "NOT_FOUND");

  const row = data as unknown as {
    att_id: number;
    stff_id: number;
    att_observation: string | null;
    staffs:
      | { role: { name: string | null } | { name: string | null }[] | null }
      | { role: { name: string | null } | { name: string | null }[] | null }[]
      | null;
  };

  const { count, error: countError } = await supabaseAdmin
    .from("attendance")
    .select("att_id", { count: "exact", head: true })
    .eq("stff_id", row.stff_id);

  if (countError) {
    console.error("attendance.getAttendanceDetail(count):", countError);
    throw new AppError(500, "No se pudo contar los registros del personal.");
  }

  return {
    att_id: row.att_id,
    att_observation: row.att_observation,
    role_name: one(one(row.staffs)?.role)?.name ?? null,
    total_records: count ?? 0,
  };
}

/** UPDATE: reemplaza las 4 horas del registro. */
export async function updateAttendanceTimes(
  custId: number,
  attId: number,
  times: AttendanceTimes,
): Promise<AttendanceTimesResult> {
  await assertAttendanceOfCustomer(custId, attId);

  const { data, error } = await supabaseAdmin
    .from("attendance")
    .update({
      att_schedule_start: times.att_inicio_jornada,
      att_refreshment_start: times.att_inicio_receso,
      att_refreshment_end: times.att_fin_receso,
      att_schedule_end: times.att_fin_jornada,
    })
    .eq("att_id", attId)
    .select("att_id, att_schedule_start, att_refreshment_start, att_refreshment_end, att_schedule_end")
    .single();

  if (error || !data) {
    console.error("attendance.updateAttendanceTimes:", error);
    throw new AppError(500, "No se pudieron guardar las horas.");
  }

  const row = data as {
    att_id: number;
    att_schedule_start: string | null;
    att_refreshment_start: string | null;
    att_refreshment_end: string | null;
    att_schedule_end: string | null;
  };
  return {
    att_id: row.att_id,
    att_inicio_jornada: row.att_schedule_start,
    att_inicio_receso: row.att_refreshment_start,
    att_fin_receso: row.att_refreshment_end,
    att_fin_jornada: row.att_schedule_end,
  };
}

/** UPDATE: guarda (o borra, con null) la observación del registro. */
export async function updateAttendanceObservation(
  custId: number,
  attId: number,
  observation: string | null,
): Promise<AttendanceObservationResult> {
  await assertAttendanceOfCustomer(custId, attId);

  const { error } = await supabaseAdmin
    .from("attendance")
    .update({ att_observation: observation })
    .eq("att_id", attId);

  if (error) {
    console.error("attendance.updateAttendanceObservation:", error);
    throw new AppError(500, "No se pudo guardar la observación.");
  }
  return { att_id: attId, att_observation: observation };
}

const JUSTIFICATION_COLUMN: Record<AttendanceJustificationType, string> = {
  delay: "att_justification_delay",
  refreshment_delay: "att_justification_refreshment_delay",
  absence: "att_justification_absence",
};

/** UPDATE: guarda (o borra, con null) una de las 3 justificaciones del registro. */
export async function updateAttendanceJustification(
  custId: number,
  attId: number,
  type: AttendanceJustificationType,
  text: string | null,
): Promise<AttendanceJustificationResult> {
  await assertAttendanceOfCustomer(custId, attId);

  const { error } = await supabaseAdmin
    .from("attendance")
    .update({ [JUSTIFICATION_COLUMN[type]]: text })
    .eq("att_id", attId);

  if (error) {
    console.error("attendance.updateAttendanceJustification:", error);
    throw new AppError(500, "No se pudo guardar la justificación.");
  }
  return { att_id: attId, type, text };
}

/** DELETE: elimina el registro (y sus incidencias, por si la FK no tiene ON DELETE CASCADE). */
export async function deleteAttendance(custId: number, attId: number): Promise<void> {
  await assertAttendanceOfCustomer(custId, attId);

  const { error: incidentsError } = await supabaseAdmin
    .from("staff_discount_incidents")
    .delete()
    .eq("att_id", attId);

  if (incidentsError) {
    console.error("attendance.deleteAttendance(incidents):", incidentsError);
    throw new AppError(500, "No se pudo eliminar el registro.");
  }

  const { error } = await supabaseAdmin.from("attendance").delete().eq("att_id", attId);

  if (error) {
    console.error("attendance.deleteAttendance:", error);
    throw new AppError(500, "No se pudo eliminar el registro.");
  }
}