import { AppError } from "../../shared/http.ts";
import { supabaseAdmin } from "../../shared/supabase.ts";
import { sanitizeSearchWord, setStaffActive, signedImageUrls } from "../staffs/staff.services.ts";
import {
  type ContractRow,
  getLatestContract,
  setContractStartDate,
} from "../staff-contracts/staff-contracts.services.ts";
import type {
  AbsenceResult,
  AttendanceDetail,
  AttendanceItem,
  AttendanceJustificationResult,
  AttendanceJustificationType,
  AttendanceObservationResult,
  AttendanceResult,
  AttendanceReport,
  AttendanceRow,
  AttendanceTimes,
  AttendanceTimesResult,
  CheckInResult,
  PendingAttendanceRow,
  PendingFilters,
  PendingStaffItem,
  PendingStaffRow,
  ReportIncident,
  ReportRow,
  ReportSchedule,
} from "./attendance.types.ts";

const COLUMNS = `
  att_id, att_date, att_schedule_start, att_refreshment_start, att_refreshment_end, att_schedule_end,
  att_justification_absence, att_justification_delay, att_justification_refreshment_delay, stff_id,
  staffs!inner(
    stff_name, stff_lastname, stff_dni, stff_link_img, cust_id,
    job_position:customer_job_positions(name:cust_jb_pstn_name),
    contracts:staff_contracts(
      stff_cntrt_id, cntrt_start_date, cntrt_end_date,
      schedule:staff_schedules(type:stff_schdl_type, start:stff_schdl_start, tolerance:stff_schdl_start_tolerance)
    )
  )
`;

/** Relación muchos-a-uno: llega como objeto (se acepta arreglo por seguridad). */
function one<T>(value: T | T[] | null | undefined): T | null {
  return (Array.isArray(value) ? value[0] : value) ?? null;
}

/** Fecha de HOY en Lima (YYYY-MM-DD): la misma zona que usa el DEFAULT de attendance.att_date. */
function todayInLima(): string {
  return new Intl.DateTimeFormat("en-CA", { timeZone: "America/Lima" }).format(new Date());
}

/** Asistencias (att_date) de la fecha, solo del personal del customer. */
async function fetchRows(custId: number, date: string): Promise<AttendanceRow[]> {
  const { data, error } = await supabaseAdmin
    .from("attendance")
    .select(COLUMNS)
    .eq("att_date", date)
    .eq("staffs.cust_id", custId)
    .order("att_id", { ascending: true });

  if (error) {
    console.error("attendance.fetchRows:", error);
    throw new AppError(500, "No se pudo obtener la asistencia.");
  }
  return (data ?? []) as unknown as AttendanceRow[];
}

/** Personal activo del customer. */
async function countActiveStaff(custId: number): Promise<number> {
  const { count, error } = await supabaseAdmin
    .from("staffs")
    .select("stff_id", { count: "exact", head: true })
    .eq("cust_id", custId)
    .eq("stff_active", true);

  if (error) {
    console.error("attendance.countActiveStaff:", error);
    throw new AppError(500, "No se pudo contar el personal.");
  }
  return count ?? 0;
}

/** READ: asistencias de una fecha del customer + cantidad de personal activo. */
export async function listAttendanceByDate(
  custId: number,
  bucketName: string,
  date: string,
): Promise<AttendanceResult> {
  const [rows, totalStaff] = await Promise.all([fetchRows(custId, date), countActiveStaff(custId)]);

  const pairs = rows
    .map((row) => ({ row, staff: one(row.staffs) }))
    .filter((p): p is { row: AttendanceRow; staff: NonNullable<typeof p.staff> } => !!p.staff);

  // URLs firmadas de todas las fotos en una sola llamada.
  const urls = await signedImageUrls(bucketName, pairs.map((p) => p.staff.stff_link_img));

  const items: AttendanceItem[] = pairs.map(({ row, staff }) => {
    // Horario del contrato vigente en la fecha (si ninguno la cubre, el más reciente).
    const contracts = [...(staff.contracts ?? [])].sort((a, b) => b.stff_cntrt_id - a.stff_cntrt_id);
    const contract =
      contracts.find(
        (c) =>
          (!c.cntrt_start_date || c.cntrt_start_date <= row.att_date) &&
          (!c.cntrt_end_date || c.cntrt_end_date >= row.att_date),
      ) ?? contracts[0];
    const schedule = one(contract?.schedule);
    return {
      att_id: row.att_id,
      att_fecha: row.att_date,
      att_inicio_jornada: row.att_schedule_start,
      att_inicio_receso: row.att_refreshment_start,
      att_fin_receso: row.att_refreshment_end,
      att_fin_jornada: row.att_schedule_end,

      att_justification_absence: row.att_justification_absence,
      att_justification_delay: row.att_justification_delay,
      att_justification_refreshment_delay: row.att_justification_refreshment_delay,

      stff_id: row.stff_id,
      stff_name: staff.stff_name,
      stff_lastname: staff.stff_lastname,
      stff_dni: staff.stff_dni,
      job_position_name: one(staff.job_position)?.name ?? null,

      schedule_type: schedule?.type ?? null,
      schedule_start: schedule?.start ?? null,
      schedule_tolerance: schedule?.tolerance ?? null,

      img_url: staff.stff_link_img ? urls.get(staff.stff_link_img) ?? null : null,
    };
  });

  return { items, total_staff: totalStaff };
}

/* ───────────────────────── Nuevo registro (ingreso) ───────────────────────── */

const PENDING_COLUMNS = `
  stff_id, stff_name, stff_lastname, stff_dni, stff_link_img,
  job_position:customer_job_positions(name:cust_jb_pstn_name),
  role:customer_roles(name:cust_role_name),
  attendance(att_id, att_schedule_start, att_justification_absence)
`;

const hasText = (value: string | null | undefined): boolean => !!value && value.trim() !== "";

/**
 * Personal ACTIVO del customer cuya fila de hoy (si existe) NO cumple `isDone`.
 * `attendance(...)` se filtra con att_date = hoy, así que solo trae la fila de hoy.
 */
async function listPendingStaff(
  custId: number,
  bucketName: string,
  filters: PendingFilters,
  isDone: (att: PendingAttendanceRow) => boolean,
): Promise<PendingStaffItem[]> {
  let query = supabaseAdmin
    .from("staffs")
    .select(PENDING_COLUMNS)
    .eq("cust_id", custId)
    .eq("stff_active", true)
    .eq("attendance.att_date", todayInLima());

  // Cada palabra debe aparecer en el nombre, el apellido o el DNI.
  const words = filters.search.split(/\s+/).map(sanitizeSearchWord).filter(Boolean);
  for (const word of words) {
    query = query.or(
      `stff_name.ilike.%${word}%,stff_lastname.ilike.%${word}%,stff_dni.ilike.%${word}%`,
    );
  }

  if (filters.cargoId !== null) query = query.eq("cust_jb_pstn_id", filters.cargoId);
  if (filters.rolId !== null) query = query.eq("cust_role_id", filters.rolId);

  const { data, error } = await query
    .order("stff_name", { ascending: true })
    .order("stff_lastname", { ascending: true })
    .order("stff_id", { ascending: true });

  if (error) {
    console.error("attendance.listPendingStaff:", error);
    throw new AppError(500, "No se pudo obtener la lista de personal.");
  }

  const rows = ((data ?? []) as unknown as PendingStaffRow[]).filter(
    (row) => !(row.attendance ?? []).some(isDone),
  );

  const urls = await signedImageUrls(bucketName, rows.map((r) => r.stff_link_img));

  return rows.map((row) => ({
    stff_id: row.stff_id,
    stff_name: row.stff_name,
    stff_lastname: row.stff_lastname,
    stff_dni: row.stff_dni,
    job_position_name: one(row.job_position)?.name ?? null,
    role_name: one(row.role)?.name ?? null,
    img_url: row.stff_link_img ? urls.get(row.stff_link_img) ?? null : null,
  }));
}

/** READ: personal activo que todavía NO tiene att_schedule_start hoy. */
export const listPendingCheckIn = (custId: number, bucketName: string, filters: PendingFilters) =>
  listPendingStaff(custId, bucketName, filters, (att) => att.att_schedule_start !== null);

/** READ: personal activo sin ingreso y sin ausencia registrada hoy. */
export const listPendingAbsence = (custId: number, bucketName: string, filters: PendingFilters) =>
  listPendingStaff(
    custId,
    bucketName,
    filters,
    (att) => att.att_schedule_start !== null || hasText(att.att_justification_absence),
  );

/** El staff debe ser de este customer y estar activo. */
async function assertActiveStaff(custId: number, stffId: number): Promise<void> {
  const { data: staff, error } = await supabaseAdmin
    .from("staffs")
    .select("stff_id, stff_active")
    .eq("stff_id", stffId)
    .eq("cust_id", custId)
    .maybeSingle();

  if (error) {
    console.error("attendance.assertActiveStaff:", error);
    throw new AppError(500, "No se pudo consultar al personal.");
  }
  if (!staff) throw new AppError(404, "El personal no existe.", "NOT_FOUND");
  if (!(staff as { stff_active: boolean }).stff_active) {
    throw new AppError(400, "El personal está desactivado.", "STAFF_INACTIVE");
  }
}

/** "2026-10-28" → "28/10/2026" (para mostrar en mensajes). */
const formatDate = (isoDate: string) => isoDate.split("-").reverse().join("/");

/**
 * Antes de registrar una jornada se revisa el contrato más reciente del personal:
 *   - Si hoy es posterior a `cntrt_end_date` el contrato ya terminó: se desactiva al personal
 *     y no se registra la jornada (400, CONTRACT_ENDED).
 *   - Devuelve el contrato para que, una vez registrada la jornada, se complete su inicio.
 * Un contrato sigue vigente durante todo el día de `cntrt_end_date`.
 */
async function assertContractNotEnded(custId: number, stffId: number, today: string): Promise<ContractRow | null> {
  const contract = await getLatestContract(stffId);

  if (contract?.cntrt_end_date && today > contract.cntrt_end_date) {
    await setStaffActive(stffId, custId, false);
    throw new AppError(
      400,
      `El contrato de este personal terminó el ${formatDate(contract.cntrt_end_date)}. Se desactivó al personal.`,
      "CONTRACT_ENDED",
    );
  }
  return contract;
}

/**
 * CREATE/UPDATE: registra el ingreso (att_schedule_start = ahora) del staff en la fecha de hoy.
 *   - Verifica el contrato: si ya terminó (hoy > cntrt_end_date) desactiva al personal y no registra.
 *   - Si su contrato no tiene `cntrt_start_date`, la primera jornada la fija en la fecha de hoy.
 */
export async function registerCheckIn(custId: number, stffId: number): Promise<CheckInResult> {
  // 1) El staff debe ser de este customer y estar activo.
  await assertActiveStaff(custId, stffId);

  const today = todayInLima();

  // 2) Su contrato no debe haber terminado.
  const contract = await assertContractNotEnded(custId, stffId, today);

  // 3) Se registra el ingreso.
  const result = await saveCheckIn(stffId, today);

  // 4) Primera jornada: el contrato empieza hoy (solo si aún no tenía fecha de inicio).
  if (contract && !contract.cntrt_start_date) {
    await setContractStartDate(contract.stff_cntrt_id, today);
  }
  return result;
}

/**
 * Guarda el ingreso en `attendance`:
 *   - No existe fila de hoy                  → la crea.
 *   - Existe, pero sin att_schedule_start    → completa esa columna.
 *   - Existe y ya tiene att_schedule_start   → 409 (ya registró su ingreso).
 */
async function saveCheckIn(stffId: number, today: string): Promise<CheckInResult> {
  const alreadyRegistered = () =>
    new AppError(409, "Este personal ya registró su ingreso hoy.", "ALREADY_REGISTERED");

  const now = new Date().toISOString();

  // 2) ¿Ya hay una fila de hoy?
  const { data: existing, error: readError } = await supabaseAdmin
    .from("attendance")
    .select("att_id, att_schedule_start")
    .eq("stff_id", stffId)
    .eq("att_date", today)
    .maybeSingle();

  if (readError) {
    console.error("attendance.registerCheckIn(read):", readError);
    throw new AppError(500, "No se pudo consultar la asistencia.");
  }

  // 3a) Fila existente sin ingreso: se completa (el .is(...null) evita pisar un ingreso simultáneo).
  if (existing) {
    const row = existing as { att_id: number; att_schedule_start: string | null };
    if (row.att_schedule_start) throw alreadyRegistered();

    const { data, error } = await supabaseAdmin
      .from("attendance")
      .update({ att_schedule_start: now })
      .eq("att_id", row.att_id)
      .is("att_schedule_start", null)
      .select("att_id")
      .maybeSingle();

    if (error) {
      console.error("attendance.registerCheckIn(update):", error);
      throw new AppError(500, "No se pudo registrar la asistencia.");
    }
    if (!data) throw alreadyRegistered();
    return { att_id: (data as { att_id: number }).att_id, att_schedule_start: now };
  }

  // 3b) Sin fila: se crea. Si otro registro simultáneo la creó antes, la restricción UNIQUE avisa.
  const { data, error } = await supabaseAdmin
    .from("attendance")
    .insert({ stff_id: stffId, att_date: today, att_schedule_start: now })
    .select("att_id")
    .single();

  if (error || !data) {
    if (error?.code === "23505") throw alreadyRegistered();
    console.error("attendance.registerCheckIn(insert):", error);
    throw new AppError(500, "No se pudo registrar la asistencia.");
  }
  return { att_id: (data as { att_id: number }).att_id, att_schedule_start: now };
}

/**
 * CREATE/UPDATE: registra la ausencia de hoy (att_justification_absence) del staff.
 *   - No existe fila de hoy                       → la crea (sin att_schedule_start).
 *   - Existe, sin ingreso ni ausencia             → completa la justificación.
 *   - Existe con ingreso o con ausencia           → 409.
 */
export async function registerAbsence(
  custId: number,
  stffId: number,
  description: string,
): Promise<AbsenceResult> {
  const alreadyCheckedIn = () =>
    new AppError(409, "Este personal ya registró su ingreso hoy.", "ALREADY_REGISTERED");
  const alreadyAbsent = () =>
    new AppError(409, "Este personal ya tiene una ausencia registrada hoy.", "ABSENCE_ALREADY_REGISTERED");

  await assertActiveStaff(custId, stffId);

  const today = todayInLima();

  const { data: existing, error: readError } = await supabaseAdmin
    .from("attendance")
    .select("att_id, att_schedule_start, att_justification_absence")
    .eq("stff_id", stffId)
    .eq("att_date", today)
    .maybeSingle();

  if (readError) {
    console.error("attendance.registerAbsence(read):", readError);
    throw new AppError(500, "No se pudo consultar la asistencia.");
  }

  if (existing) {
    const row = existing as {
      att_id: number;
      att_schedule_start: string | null;
      att_justification_absence: string | null;
    };
    if (row.att_schedule_start) throw alreadyCheckedIn();
    if (hasText(row.att_justification_absence)) throw alreadyAbsent();

    // .is(...null) evita pisar un ingreso que se registre al mismo tiempo.
    const { data, error } = await supabaseAdmin
      .from("attendance")
      .update({ att_justification_absence: description })
      .eq("att_id", row.att_id)
      .is("att_schedule_start", null)
      .select("att_id")
      .maybeSingle();

    if (error) {
      console.error("attendance.registerAbsence(update):", error);
      throw new AppError(500, "No se pudo registrar la ausencia.");
    }
    if (!data) throw alreadyCheckedIn();
    return { att_id: (data as { att_id: number }).att_id, att_justification_absence: description };
  }

  const { data, error } = await supabaseAdmin
    .from("attendance")
    .insert({ stff_id: stffId, att_date: today, att_justification_absence: description })
    .select("att_id")
    .single();

  if (error || !data) {
    if (error?.code === "23505") throw alreadyAbsent();
    console.error("attendance.registerAbsence(insert):", error);
    throw new AppError(500, "No se pudo registrar la ausencia.");
  }
  return { att_id: (data as { att_id: number }).att_id, att_justification_absence: description };
}

/* ───────────────────────── Detalle y edición de un registro ───────────────────────── */

/** El registro debe existir y ser de personal de este customer. Devuelve el stff_id. */
export async function assertAttendanceOfCustomer(custId: number, attId: number): Promise<number> {
  const { data, error } = await supabaseAdmin
    .from("attendance")
    .select("att_id, stff_id, staffs!inner(cust_id)")
    .eq("att_id", attId)
    .eq("staffs.cust_id", custId)
    .maybeSingle();

  if (error) {
    console.error("attendance.assertAttendanceOfCustomer:", error);
    throw new AppError(500, "No se pudo consultar el registro.");
  }
  if (!data) throw new AppError(404, "El registro de asistencia no existe.", "NOT_FOUND");
  return (data as { stff_id: number }).stff_id;
}

/** READ: observación, rol y total de registros del personal de una asistencia. */
export async function getAttendanceDetail(custId: number, attId: number): Promise<AttendanceDetail> {
  const { data, error } = await supabaseAdmin
    .from("attendance")
    .select("att_id, stff_id, att_observation, staffs!inner(cust_id, role:customer_roles(name:cust_role_name))")
    .eq("att_id", attId)
    .eq("staffs.cust_id", custId)
    .maybeSingle();

  if (error) {
    console.error("attendance.getAttendanceDetail:", error);
    throw new AppError(500, "No se pudo obtener el detalle del registro.");
  }
  if (!data) throw new AppError(404, "El registro de asistencia no existe.", "NOT_FOUND");

  const row = data as unknown as {
    att_id: number;
    stff_id: number;
    att_observation: string | null;
    staffs:
      | { role: { name: string | null } | { name: string | null }[] | null }
      | { role: { name: string | null } | { name: string | null }[] | null }[]
      | null;
  };

  const { count, error: countError } = await supabaseAdmin
    .from("attendance")
    .select("att_id", { count: "exact", head: true })
    .eq("stff_id", row.stff_id);

  if (countError) {
    console.error("attendance.getAttendanceDetail(count):", countError);
    throw new AppError(500, "No se pudo contar los registros del personal.");
  }

  return {
    att_id: row.att_id,
    att_observation: row.att_observation,
    role_name: one(one(row.staffs)?.role)?.name ?? null,
    total_records: count ?? 0,
  };
}

/** UPDATE: reemplaza las 4 horas del registro. */
export async function updateAttendanceTimes(
  custId: number,
  attId: number,
  times: AttendanceTimes,
): Promise<AttendanceTimesResult> {
  await assertAttendanceOfCustomer(custId, attId);

  const { data, error } = await supabaseAdmin
    .from("attendance")
    .update({
      att_schedule_start: times.att_inicio_jornada,
      att_refreshment_start: times.att_inicio_receso,
      att_refreshment_end: times.att_fin_receso,
      att_schedule_end: times.att_fin_jornada,
    })
    .eq("att_id", attId)
    .select("att_id, att_schedule_start, att_refreshment_start, att_refreshment_end, att_schedule_end")
    .single();

  if (error || !data) {
    console.error("attendance.updateAttendanceTimes:", error);
    throw new AppError(500, "No se pudieron guardar las horas.");
  }

  const row = data as {
    att_id: number;
    att_schedule_start: string | null;
    att_refreshment_start: string | null;
    att_refreshment_end: string | null;
    att_schedule_end: string | null;
  };
  return {
    att_id: row.att_id,
    att_inicio_jornada: row.att_schedule_start,
    att_inicio_receso: row.att_refreshment_start,
    att_fin_receso: row.att_refreshment_end,
    att_fin_jornada: row.att_schedule_end,
  };
}

/** UPDATE: guarda (o borra, con null) la observación del registro. */
export async function updateAttendanceObservation(
  custId: number,
  attId: number,
  observation: string | null,
): Promise<AttendanceObservationResult> {
  await assertAttendanceOfCustomer(custId, attId);

  const { error } = await supabaseAdmin
    .from("attendance")
    .update({ att_observation: observation })
    .eq("att_id", attId);

  if (error) {
    console.error("attendance.updateAttendanceObservation:", error);
    throw new AppError(500, "No se pudo guardar la observación.");
  }
  return { att_id: attId, att_observation: observation };
}

const JUSTIFICATION_COLUMN: Record<AttendanceJustificationType, string> = {
  delay: "att_justification_delay",
  refreshment_delay: "att_justification_refreshment_delay",
  absence: "att_justification_absence",
};

/** UPDATE: guarda (o borra, con null) una de las 3 justificaciones del registro. */
export async function updateAttendanceJustification(
  custId: number,
  attId: number,
  type: AttendanceJustificationType,
  text: string | null,
): Promise<AttendanceJustificationResult> {
  await assertAttendanceOfCustomer(custId, attId);

  const { error } = await supabaseAdmin
    .from("attendance")
    .update({ [JUSTIFICATION_COLUMN[type]]: text })
    .eq("att_id", attId);

  if (error) {
    console.error("attendance.updateAttendanceJustification:", error);
    throw new AppError(500, "No se pudo guardar la justificación.");
  }
  return { att_id: attId, type, text };
}

/** DELETE: elimina el registro (y sus incidencias, por si la FK no tiene ON DELETE CASCADE). */
export async function deleteAttendance(custId: number, attId: number): Promise<void> {
  await assertAttendanceOfCustomer(custId, attId);

  const { error: incidentsError } = await supabaseAdmin
    .from("staff_discount_incidents")
    .delete()
    .eq("att_id", attId);

  if (incidentsError) {
    console.error("attendance.deleteAttendance(incidents):", incidentsError);
    throw new AppError(500, "No se pudo eliminar el registro.");
  }

  const { error } = await supabaseAdmin.from("attendance").delete().eq("att_id", attId);

  if (error) {
    console.error("attendance.deleteAttendance:", error);
    throw new AppError(500, "No se pudo eliminar el registro.");
  }
}

/* ───────────────────────── Reporte de asistencia (por contrato) ───────────────────────── */

const LIMA_OFFSET_MS = -5 * 60 * 60 * 1000; // Perú no usa horario de verano

const limaMinutes = (iso: string): number => {
  const d = new Date(new Date(iso).getTime() + LIMA_OFFSET_MS);
  return d.getUTCHours() * 60 + d.getUTCMinutes();
};

const timeToMinutes = (time: string | null | undefined): number | null => {
  if (!time) return null;
  const [h, m] = time.split(":").map(Number);
  return Number.isFinite(h) && Number.isFinite(m) ? h * 60 + m : null;
};

const hhmm = (time: string | null | undefined): string | null => (time ? time.slice(0, 5) : null);

const addDays = (date: string, days: number): string => {
  const d = new Date(`${date}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
};

const REPORT_DAY_COLUMNS = [
  "stff_nn_wrkng_day_mondey", // (sic) así se llama la columna en la tabla
  "stff_nn_wrkng_day_tuesday",
  "stff_nn_wrkng_day_wednesday",
  "stff_nn_wrkng_day_thursday",
  "stff_nn_wrkng_day_friday",
  "stff_nn_wrkng_day_saturday",
  "stff_nn_wrkng_day_sunday",
] as const;

/** Horario del contrato (staff_contracts.stff_schdl_id) con su refrigerio y días no laborables. */
async function fetchContractSchedule(scheduleId: number | null): Promise<ReportSchedule | null> {
  if (!scheduleId) return null;

  const { data, error } = await supabaseAdmin
    .from("staff_schedules")
    .select(
      `stff_schdl_type, stff_schdl_start, stff_schdl_end, stff_schdl_start_tolerance, stff_schdl_required_minutes,
       refreshment:staff_refreshmenths(stff_rfrshmnth_type, stff_rfrshmnth_start, stff_rfrshmnth_end, stff_rfrshmnth_minutes),
       non_working:staff_non_working_days(*)`,
    )
    .eq("stff_schdl_id", scheduleId)
    .maybeSingle();

  if (error) {
    console.error("attendance.fetchContractSchedule:", error);
    throw new AppError(500, "No se pudo obtener el horario del contrato.");
  }
  if (!data) return null;

  // deno-lint-ignore no-explicit-any
  const row = data as any;
  const refreshment = one<Record<string, unknown>>(row.refreshment);
  const nonWorking = one<Record<string, unknown>>(row.non_working);

  return {
    type: row.stff_schdl_type,
    start: hhmm(row.stff_schdl_start),
    end: hhmm(row.stff_schdl_end),
    tolerance: Number(row.stff_schdl_start_tolerance ?? 0),
    requiredMinutes: row.stff_schdl_required_minutes ?? null,
    refreshment: refreshment
      ? {
          type: refreshment.stff_rfrshmnth_type as "fixed" | "flexible" | "free",
          start: hhmm(refreshment.stff_rfrshmnth_start as string | null),
          end: hhmm(refreshment.stff_rfrshmnth_end as string | null),
          minutes: (refreshment.stff_rfrshmnth_minutes as number | null) ?? null,
        }
      : null,
    nonWorkingDays:
      nonWorking?.stff_nn_wrkng_day_type === "fixed"
        ? { type: "fixed", days: REPORT_DAY_COLUMNS.map((c) => nonWorking[c] === true) }
        : nonWorking?.stff_nn_wrkng_day_type === "flexible"
          ? { type: "flexible", numberDays: Number(nonWorking.stff_nn_wrkng_day_number_days ?? 1) }
          : null,
  };
}

/** Minutos de tardanza: solo horario fijo, con hora de llegada y pasada la tolerancia. */
function delayMinutes(arrival: string | null, schedule: ReportSchedule | null): number | null {
  if (!arrival || schedule?.type !== "fixed") return null;
  const start = timeToMinutes(schedule.start);
  if (start === null) return null;
  const arrived = limaMinutes(arrival);
  return arrived > start + schedule.tolerance ? arrived - start : null;
}

/** Minutos que el refrigerio excedió lo permitido (fixed: fin − inicio; flexible: minutos). */
function refreshmentDelayMinutes(
  from: string | null,
  to: string | null,
  schedule: ReportSchedule | null,
): number | null {
  const rule = schedule?.refreshment;
  if (!to || !rule) return null;

  // Fijo: solo importa la hora de regreso frente a la hora de fin de la ventana.
  if (rule.type === "fixed") {
    const end = timeToMinutes(rule.end);
    if (end === null) return null;
    const late = limaMinutes(to) - end;
    return late > 0 ? late : null;
  }

  // Flexible: tiempo usado (regreso − salida) menos los minutos acordados.
  if (rule.type === "flexible") {
    if (!from || rule.minutes === null || rule.minutes === undefined) return null;
    const late = limaMinutes(to) - limaMinutes(from) - rule.minutes;
    return late > 0 ? late : null;
  }

  return null; // libre: no se calcula demora
}

/**
 * READ: reporte de asistencia de UN contrato del personal.
 * attendance / staff_advancements / staff_discount_incidents no tienen FK a staff_contracts:
 * se atribuyen al contrato por rango de fechas (inicio y fin del contrato, acotado por los contratos vecinos).
 */
export async function getAttendanceReport(
  custId: number,
  bucketName: string,
  stffId: number,
  contractId: number,
): Promise<AttendanceReport> {
  const [staffRes, contractsRes] = await Promise.all([
    supabaseAdmin
      .from("staffs")
      .select("stff_id, stff_name, stff_lastname, stff_dni, stff_link_img")
      .eq("stff_id", stffId)
      .eq("cust_id", custId)
      .maybeSingle(),
    supabaseAdmin
      .from("staff_contracts")
      .select("stff_cntrt_id, cntrt_start_date, cntrt_end_date, stff_schdl_id")
      .eq("stff_id", stffId)
      .order("stff_cntrt_id", { ascending: true }),
  ]);

  if (staffRes.error || contractsRes.error) {
    console.error("attendance.getAttendanceReport(base):", staffRes.error ?? contractsRes.error);
    throw new AppError(500, "No se pudo obtener el reporte.");
  }
  const staff = staffRes.data;
  if (!staff) throw new AppError(404, "El personal no existe.", "NOT_FOUND");

  const contracts = (contractsRes.data ?? []) as {
    stff_cntrt_id: number;
    cntrt_start_date: string | null;
    cntrt_end_date: string | null;
    stff_schdl_id: number | null;
  }[];
  const index = contracts.findIndex((c) => c.stff_cntrt_id === contractId);
  if (index < 0) throw new AppError(404, "El contrato no existe.", "NOT_FOUND");

  const contract = contracts[index];
  const prev = contracts[index - 1];
  const next = contracts[index + 1];

  // Contrato sin inicio: empieza al día siguiente de terminar el anterior.
  const rangeStart = contract.cntrt_start_date ?? (prev?.cntrt_end_date ? addDays(prev.cntrt_end_date, 1) : null);
  // El contrato siguiente (si ya empezó) corta este contrato para no mezclar registros.
  let rangeEnd = contract.cntrt_end_date;
  if (next) {
    const nextStart = next.cntrt_start_date ?? (contract.cntrt_end_date ? addDays(contract.cntrt_end_date, 1) : null);
    if (nextStart) {
      const cap = addDays(nextStart, -1);
      if (!rangeEnd || cap < rangeEnd) rangeEnd = cap;
    }
  }

  let attQuery = supabaseAdmin
    .from("attendance")
    .select(
      `att_id, att_date, att_schedule_start, att_refreshment_start, att_refreshment_end, att_schedule_end,
       att_justification_absence, att_justification_delay, att_justification_refreshment_delay, att_observation`,
    )
    .eq("stff_id", stffId);
  let advQuery = supabaseAdmin
    .from("staff_advancements")
    .select("stff_dvncmnt_date, stff_dvncmnt_amount")
    .eq("stff_id", stffId)
    .eq("cust_id", custId);
  if (rangeStart) {
    attQuery = attQuery.gte("att_date", rangeStart);
    advQuery = advQuery.gte("stff_dvncmnt_date", rangeStart);
  }
  if (rangeEnd) {
    attQuery = attQuery.lte("att_date", rangeEnd);
    advQuery = advQuery.lte("stff_dvncmnt_date", rangeEnd);
  }

  const [schedule, attRes, advRes, urls] = await Promise.all([
    fetchContractSchedule(contract.stff_schdl_id),
    attQuery.order("att_date", { ascending: true }).order("att_id", { ascending: true }),
    advQuery,
    signedImageUrls(bucketName, [staff.stff_link_img]),
  ]);

  if (attRes.error || advRes.error) {
    console.error("attendance.getAttendanceReport(rows):", attRes.error ?? advRes.error);
    throw new AppError(500, "No se pudo obtener el reporte.");
  }

  const attendance = (attRes.data ?? []) as {
    att_id: number;
    att_date: string;
    att_schedule_start: string | null;
    att_refreshment_start: string | null;
    att_refreshment_end: string | null;
    att_schedule_end: string | null;
    att_justification_absence: string | null;
    att_justification_delay: string | null;
    att_justification_refreshment_delay: string | null;
    att_observation: string | null;
  }[];

  // Incidencias de todos los registros en una sola consulta (sin N+1).
  const incidentsByAtt = new Map<number, ReportIncident[]>();
  if (attendance.length > 0) {
    const { data, error } = await supabaseAdmin
      .from("staff_discount_incidents")
      .select("stff_dscount_ncdnt_id, att_id, stff_dscount_description, stff_dscount_amount")
      .in("att_id", attendance.map((a) => a.att_id))
      .order("stff_dscount_ncdnt_id", { ascending: true });
    if (error) {
      console.error("attendance.getAttendanceReport(incidents):", error);
      throw new AppError(500, "No se pudieron obtener las incidencias.");
    }
    for (const inc of (data ?? []) as {
      att_id: number;
      stff_dscount_description: string;
      stff_dscount_amount: number | string;
    }[]) {
      const list = incidentsByAtt.get(inc.att_id) ?? [];
      list.push({ amount: Number(inc.stff_dscount_amount), description: inc.stff_dscount_description });
      incidentsByAtt.set(inc.att_id, list);
    }
  }

  // Adelantos del día (puede haber varios: se suman).
  const advancementByDate = new Map<string, number>();
  for (const adv of (advRes.data ?? []) as { stff_dvncmnt_date: string; stff_dvncmnt_amount: number | string }[]) {
    advancementByDate.set(
      adv.stff_dvncmnt_date,
      (advancementByDate.get(adv.stff_dvncmnt_date) ?? 0) + Number(adv.stff_dvncmnt_amount),
    );
  }

  const rows: ReportRow[] = attendance.map((a) => {
    const advancement = advancementByDate.get(a.att_date) ?? null;
    advancementByDate.delete(a.att_date);
    return {
      att_id: a.att_id,
      date: a.att_date,
      arrival: a.att_schedule_start,
      refreshment_start: a.att_refreshment_start,
      refreshment_end: a.att_refreshment_end,
      departure: a.att_schedule_end,
      is_worked: a.att_schedule_start !== null,
      is_absence: a.att_schedule_start === null && hasText(a.att_justification_absence),
      delay_minutes: delayMinutes(a.att_schedule_start, schedule),
      refreshment_delay_minutes: refreshmentDelayMinutes(a.att_refreshment_start, a.att_refreshment_end, schedule),
      advancement,
      incidents: incidentsByAtt.get(a.att_id) ?? [],
      observation: a.att_observation,
      justification_absence: a.att_justification_absence,
      justification_delay: a.att_justification_delay,
      justification_refreshment_delay: a.att_justification_refreshment_delay,
    };
  });

  // Adelantos en días sin asistencia: se muestran para que el dinero entregado no quede fuera del reporte.
  for (const [date, amount] of advancementByDate) {
    rows.push({
      att_id: null,
      date,
      arrival: null,
      refreshment_start: null,
      refreshment_end: null,
      departure: null,
      is_worked: false,
      is_absence: false,
      delay_minutes: null,
      refreshment_delay_minutes: null,
      advancement: amount,
      incidents: [],
      observation: null,
      justification_absence: null,
      justification_delay: null,
      justification_refreshment_delay: null,
    });
  }
  rows.sort((x, y) => x.date.localeCompare(y.date));

  return {
    staff: {
      id: staff.stff_id,
      name: staff.stff_name,
      lastname: staff.stff_lastname,
      dni: staff.stff_dni,
      img_url: staff.stff_link_img ? urls.get(staff.stff_link_img) ?? null : null,
    },
    contract: {
      id: contract.stff_cntrt_id,
      number: index + 1,
      start_date: contract.cntrt_start_date,
      end_date: contract.cntrt_end_date,
      range_start: rangeStart,
      range_end: rangeEnd,
    },
    schedule,
    rows,
  };
}