type EmbeddedName = { name: string | null } | { name: string | null }[] | null;

type EmbeddedSchedule =
  | { type: string | null; start: string | null; tolerance: number | null }
  | { type: string | null; start: string | null; tolerance: number | null }[]
  | null;

export interface AttendanceStaffEmbed {
  stff_name: string;
  stff_lastname: string;
  stff_dni: string;
  stff_link_img: string | null;
  cust_id: number;
  job_position: EmbeddedName;
  contracts:
    | {
        stff_cntrt_id: number;
        cntrt_start_date: string | null;
        cntrt_end_date: string | null;
        schedule: EmbeddedSchedule;
      }[]
    | null;
}

/**
 * Fila tal como la devuelve PostgREST (nombres reales de la tabla attendance).
 * Las columnas de hora son TIMESTAMPTZ: llegan en ISO 8601 con zona (UTC),
 * por ejemplo "2026-10-26T13:05:00+00:00". El frontend las convierte a hora local.
 */
export interface AttendanceRow {
  att_id: number;
  att_date: string; // DATE → "YYYY-MM-DD"
  att_schedule_start: string | null;
  att_refreshment_start: string | null;
  att_refreshment_end: string | null;
  att_schedule_end: string | null;
  att_justification_absence: string | null;
  att_justification_delay: string | null;
  att_justification_refreshment_delay: string | null;
  stff_id: number;
  staffs: AttendanceStaffEmbed | AttendanceStaffEmbed[] | null;
}

/**
 * Lo que recibe el frontend en GET /attendance (una fila por asistencia).
 * Se conservan los nombres del contrato actual (att_fecha, att_inicio_jornada, ...).
 */
export interface AttendanceItem {
  att_id: number;
  att_fecha: string;
  att_inicio_jornada: string | null;
  att_inicio_receso: string | null;
  att_fin_receso: string | null;
  att_fin_jornada: string | null;

  att_justification_absence: string | null;
  att_justification_delay: string | null;
  att_justification_refreshment_delay: string | null;

  stff_id: number;
  stff_name: string;
  stff_lastname: string;
  stff_dni: string;
  job_position_name: string | null;

  /** Horario del personal ("fixed" | "flexible" | "free"): decide si llegó tarde. */
  schedule_type: string | null;
  /** Hora de inicio del horario fijo ("08:00:00"). */
  schedule_start: string | null;
  /** Minutos de tolerancia después de la hora de inicio. */
  schedule_tolerance: number | null;

  /** URL firmada y temporal de la foto (null si no tiene). */
  img_url: string | null;
}

/** Respuesta completa de GET /attendance. */
export interface AttendanceResult {
  items: AttendanceItem[];
  /** Personal activo del customer (base de las tarjetas de resumen). */
  total_staff: number;
}

/* ───────────────────────── Nuevo registro (ingreso) ───────────────────────── */

/** Filtros de GET /attendance/pending. */
export interface PendingFilters {
  search: string;
  cargoId: number | null;
  rolId: number | null;
}

/** Asistencia de HOY embebida en la fila de `staffs` (solo trae las filas con att_date = hoy). */
export interface PendingAttendanceRow {
  att_id: number;
  att_schedule_start: string | null;
  att_justification_absence: string | null;
}

/** Fila de `staffs` con la asistencia de HOY embebida (solo las filas con att_date = hoy). */
export interface PendingStaffRow {
  stff_id: number;
  stff_name: string;
  stff_lastname: string;
  stff_dni: string;
  stff_link_img: string | null;
  job_position: EmbeddedName;
  role: EmbeddedName;
  attendance: PendingAttendanceRow[] | null;
}


type EmbeddedName =
  | { name: string | null }
  | { name: string | null }[]
  | null;

type EmbeddedSchedule =
  | {
      type: string | null;
      start: string | null;
      tolerance: number | null;
    }
  | {
      type: string | null;
      start: string | null;
      tolerance: number | null;
    }[]
  | null;

export interface AttendanceStaffEmbed {
  stff_name: string;
  stff_lastname: string;
  stff_dni: string;
  stff_link_img: string | null;
  cust_id: number;
  job_position: EmbeddedName;
  contracts:
    | {
        stff_cntrt_id: number;
        cntrt_start_date: string | null;
        cntrt_end_date: string | null;
        schedule: EmbeddedSchedule;
      }[]
    | null;
}

/**
 * Fila tal como la devuelve PostgREST.
 * Los nombres corresponden a las columnas reales de attendance.
 */
export interface AttendanceRow {
  att_id: number;
  stff_id: number;
  att_date: string;

  att_schedule_start: string | null;
  att_refreshment_start: string | null;
  att_refreshment_end: string | null;
  att_schedule_end: string | null;

  att_justification_absence: string | null;
  att_justification_delay: string | null;
  att_justification_refreshment_delay: string | null;
  att_observation: string | null;

  staffs: AttendanceStaffEmbed | AttendanceStaffEmbed[] | null;
}

/**
 * Lo que recibe el frontend en GET /attendance.
 * Conserva los nombres del contrato actual.
 */
export interface AttendanceItem {
  att_id: number;
  att_fecha: string;

  att_inicio_jornada: string | null;
  att_inicio_receso: string | null;
  att_fin_receso: string | null;
  att_fin_jornada: string | null;

  att_justification_absence: string | null;
  att_justification_delay: string | null;
  att_justification_refreshment_delay: string | null;
  att_observation: string | null;

  stff_id: number;
  stff_name: string;
  stff_lastname: string;
  stff_dni: string;
  job_position_name: string | null;

  /** Horario del personal: fixed | flexible | free. */
  schedule_type: string | null;
  /** Hora de inicio del horario fijo. */
  schedule_start: string | null;
  /** Minutos de tolerancia después del inicio. */
  schedule_tolerance: number | null;

  /** URL firmada y temporal de la foto. */
  img_url: string | null;
}

/** Respuesta completa de GET /attendance. */
export interface AttendanceResult {
  items: AttendanceItem[];
  total_staff: number;
}

/* ───────────────────────── Nuevo registro (ingreso) ───────────────────────── */

export interface PendingFilters {
  search: string;
  cargoId: number | null;
  rolId: number | null;
}

/** Asistencia de hoy embebida en la fila de staffs. */
export interface PendingAttendanceRow {
  att_id: number;
  att_schedule_start: string | null;
  att_justification_absence: string | null;
}

/** Fila de staffs con la asistencia de hoy embebida. */
export interface PendingStaffRow {
  stff_id: number;
  stff_name: string;
  stff_lastname: string;
  stff_dni: string;
  stff_link_img: string | null;
  job_position: EmbeddedName;
  role: EmbeddedName;
  attendance: PendingAttendanceRow[] | null;
}

/** Personal activo que todavía no registró su ingreso hoy. */
export interface PendingStaffItem {
  stff_id: number;
  stff_name: string;
  stff_lastname: string;
  stff_dni: string;
  job_position_name: string | null;
  role_name: string | null;
  img_url: string | null;
}

/** Respuesta de POST /attendance. */
export interface CheckInResult {
  att_id: number;
  att_schedule_start: string;
}

/** Respuesta de POST /attendance/absence. */
export interface AbsenceResult {
  att_id: number;
  att_justification_absence: string;
}

/* ───────────────────────── Detalle y edición de un registro ───────────────────────── */

/** GET /attendance/detail?id= → lo que el modal de un registro necesita además de la fila. */
export interface AttendanceDetail {
  att_id: number;
  att_observation: string | null;
  /** Rol del personal (customer_roles). */
  role_name: string | null;
  /** Cantidad de filas de attendance del personal (todas las fechas). */
  total_records: number;
}

/** Las 4 horas de un registro (ISO 8601 o null). */
export interface AttendanceTimes {
  att_inicio_jornada: string | null;
  att_inicio_receso: string | null;
  att_fin_receso: string | null;
  att_fin_jornada: string | null;
}

/** Respuesta de PATCH /attendance/times. */
export interface AttendanceTimesResult extends AttendanceTimes {
  att_id: number;
}

/** Qué justificación se edita. */
export type AttendanceJustificationType = "delay" | "refreshment_delay" | "absence";

/** Respuesta de PATCH /attendance/justification. */
export interface AttendanceJustificationResult {
  att_id: number;
  type: AttendanceJustificationType;
  text: string | null;
}

/** Respuesta de PATCH /attendance/observation. */
export interface AttendanceObservationResult {
  att_id: number;
  att_observation: string | null;
}

/* ───────────────────────── Reporte de asistencia (por contrato) ───────────────────────── */

export interface ReportSchedule {
  type: "fixed" | "flexible" | "free";
  /** "HH:MM" (solo fixed) */
  start: string | null;
  end: string | null;
  tolerance: number;
  requiredMinutes: number | null;
  refreshment: {
    type: "fixed" | "flexible" | "free";
    start: string | null;
    end: string | null;
    minutes: number | null;
  } | null;
  /** fixed: 7 posiciones lunes … domingo (true = día libre). */
  nonWorkingDays:
    | { type: "fixed"; days: boolean[] }
    | { type: "flexible"; numberDays: number }
    | null;
}

export interface ReportIncident {
  amount: number;
  description: string;
}

export interface ReportRow {
  /** null = día sin asistencia que solo tiene adelanto. */
  att_id: number | null;
  /** YYYY-MM-DD */
  date: string;
  /** ISO 8601 (UTC) */
  arrival: string | null;
  refreshment_start: string | null;
  refreshment_end: string | null;
  departure: string | null;
  /** Con hora de llegada = día trabajado válido. */
  is_worked: boolean;
  /** Sin llegada y con justificación de ausencia. */
  is_absence: boolean;
  delay_minutes: number | null;
  refreshment_delay_minutes: number | null;
  advancement: number | null;
  incidents: ReportIncident[];
  observation: string | null;
  justification_absence: string | null;
  justification_delay: string | null;
  justification_refreshment_delay: string | null;
}

export interface AttendanceReport {
  staff: { id: number; name: string; lastname: string; dni: string; img_url: string | null };
  contract: {
    id: number;
    number: number;
    start_date: string | null;
    end_date: string | null;
    /** Rango usado para filtrar (evita mezclar contratos vecinos). */
    range_start: string | null;
    range_end: string | null;
  };
  schedule: ReportSchedule | null;
  rows: ReportRow[];
}