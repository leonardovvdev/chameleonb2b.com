export interface Attendance {
  att_id: number;
  stff_id: number;
  att_date: string;
  att_schedule_start: string | null;
  att_refreshment_start: string | null;
  att_refreshment_end: string | null;
  att_schedule_end: string | null;
  att_justification_absence: string | null;
  att_justification_delay: string | null;
  att_justification_refreshment_delay: string | null;
  att_discount_absence: boolean;
  att_discount_delay: boolean;
  att_discount_refreshment_delay: boolean;
  att_observation: string | null;
}
