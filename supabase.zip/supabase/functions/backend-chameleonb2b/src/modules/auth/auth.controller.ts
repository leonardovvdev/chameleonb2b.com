import { AppError, json } from "../../shared/http.ts";
import {
  deleteOrphanGoogleUser,
  getCustomerSession,
  hasPassword,
  requireGoogleUser,
  requireUser,
  savePassword,
  validateNewPassword,
  findAccountByEmail,
  verifyGoogleCredential,
} from "./auth.services.ts";
import { createCustomerInSystem } from "../customers/customers.services.ts"; // ← antes .controller.ts
import type { Customer } from "../customers/customers.types.ts";

/** Datos del customer que se devuelven al frontend. */
function customerBody(customer: Customer) {
  return {
    cust_id: customer.cust_id,
    cust_name: customer.cust_name,
    cust_lastname: customer.cust_lastname,
    cust_code_system: customer.cust_code_system,
  };
}

// ////////////////////////////////////////////////////////////////////////////////////////////////
/** Crea la cuenta (customer + bucket + módulos por defecto). Solo cuentas de Google. */
export async function registerWithGoogle(req: Request): Promise<Response> {
  const user = await requireGoogleUser(req);
  const { created, customer, redirectUrl } = await createCustomerInSystem(user);

  return json(
    { created, redirect_url: redirectUrl, customer: customerBody(customer) },
    created ? 201 : 200,
  );
}

/**
 * Entrar con Google. No crea nada: si no existe el customer responde 404
 * con code = "CUSTOMER_NOT_FOUND" para que el frontend pregunte si desea crearlo.
 */
/**
 * Entrar con Google. No crea el customer: si no existe responde 404 con
 * code = "CUSTOMER_NOT_FOUND" y borra el usuario que Google dejó en Auth.
 */
export async function loginWithGoogle(req: Request): Promise<Response> {
  const user = await requireGoogleUser(req);

  try {
    const { customer, redirectUrl } = await getCustomerSession(user);
    return json({ redirect_url: redirectUrl, customer: customerBody(customer) });
  } catch (err) {
    if (err instanceof AppError && err.code === "CUSTOMER_NOT_FOUND") {
      await deleteOrphanGoogleUser(user);
    }
    throw err;
  }
}

/** Entrar con correo y contraseña (el JWT ya lo validó Supabase Auth en el frontend). */
export async function loginWithCorreoContrasena(req: Request): Promise<Response> {
  const user = await requireUser(req);
  const { customer, redirectUrl } = await getCustomerSession(user);

  return json({ redirect_url: redirectUrl, customer: customerBody(customer) });
}
// ////////////////////////////////////////////////////////////////////////////////////////////////
/** ¿La cuenta ya tiene clave? Solo responde sí/no, nunca la clave. */
export async function getPasswordStatus(req: Request): Promise<Response> {
  const user = await requireUser(req);
  return json({ has_password: hasPassword(user) });
}

/** Crea la clave si la cuenta no tiene, o la actualiza si ya tiene. */
export async function setPassword(req: Request): Promise<Response> {
  const user = await requireUser(req);
  const body = (await req.json().catch(() => null)) as
    | { password?: unknown; confirmPassword?: unknown }
    | null;

  const password = validateNewPassword(body?.password, body?.confirmPassword);
  const created = !hasPassword(user);
  await savePassword(user, password);

  return json({ created, has_password: true }, created ? 201 : 200);
}

/**
 * Paso 1 de "Acceder con Google". No necesita sesión y NO crea nada en Supabase.
 *  1) Google valida el token (OAuth) → el correo es de quien pulsó el botón.
 *  2) Se busca ese correo en Supabase Authentication y luego su customer.
 * exists = true solo si el correo está en Auth Y tiene customer.
 */
export async function checkGoogleAccount(req: Request): Promise<Response> {
  const body = (await req.json().catch(() => null)) as { credential?: unknown } | null;
  const identity = await verifyGoogleCredential(body?.credential);

  const cuenta = await findAccountByEmail(identity.email);
  if (cuenta.customer && !cuenta.customer.cust_is_active) {
    throw new AppError(403, "Tu cuenta está desactivada. Contacta a soporte.");
  }
  return json({ exists: cuenta.customer !== null, email: identity.email });
}