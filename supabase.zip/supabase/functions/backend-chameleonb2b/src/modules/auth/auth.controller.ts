import { json } from "../../shared/http.ts";
import {
  getCustomerSession,
  hasPassword,
  requireGoogleUser,
  requireUser,
  savePassword,
  validateNewPassword,
} from "./auth.services.ts";
import { createCustomerInSystem } from "../customers/customers.controller.ts";
import type { Customer } from "../customers/customers.types.ts";

/** Datos del customer que se devuelven al frontend. */
function customerBody(customer: Customer) {
  return {
    cust_id: customer.cust_id,
    cust_name: customer.cust_name,
    cust_lastname: customer.cust_lastname,
    cust_code_system: customer.cust_code_system,
  };
}

// ////////////////////////////////////////////////////////////////////////////////////////////////
/** Crea la cuenta (customer + bucket + módulos por defecto). Solo cuentas de Google. */
export async function registerWithGoogle(req: Request): Promise<Response> {
  const user = await requireGoogleUser(req);
  const { created, customer, redirectUrl } = await createCustomerInSystem(user);

  return json(
    { created, redirect_url: redirectUrl, customer: customerBody(customer) },
    created ? 201 : 200,
  );
}

/**
 * Entrar con Google. No crea nada: si no existe el customer responde 404
 * con code = "CUSTOMER_NOT_FOUND" para que el frontend pregunte si desea crearlo.
 */
export async function loginWithGoogle(req: Request): Promise<Response> {
  const user = await requireGoogleUser(req);
  const { customer, redirectUrl } = await getCustomerSession(user);

  return json({ redirect_url: redirectUrl, customer: customerBody(customer) });
}

/** Entrar con correo y contraseña (el JWT ya lo validó Supabase Auth en el frontend). */
export async function loginWithCorreoContrasena(req: Request): Promise<Response> {
  const user = await requireUser(req);
  const { customer, redirectUrl } = await getCustomerSession(user);

  return json({ redirect_url: redirectUrl, customer: customerBody(customer) });
}
// ////////////////////////////////////////////////////////////////////////////////////////////////
/** ¿La cuenta ya tiene clave? Solo responde sí/no, nunca la clave. */
export async function getPasswordStatus(req: Request): Promise<Response> {
  const user = await requireUser(req);
  return json({ has_password: hasPassword(user) });
}

/** Crea la clave si la cuenta no tiene, o la actualiza si ya tiene. */
export async function setPassword(req: Request): Promise<Response> {
  const user = await requireUser(req);
  const body = (await req.json().catch(() => null)) as
    | { password?: unknown; confirmPassword?: unknown }
    | null;

  const password = validateNewPassword(body?.password, body?.confirmPassword);
  const created = !hasPassword(user);
  await savePassword(user, password);

  return json({ created, has_password: true }, created ? 201 : 200);
}