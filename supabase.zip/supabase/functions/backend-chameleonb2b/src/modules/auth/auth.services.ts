import type { User } from "npm:@supabase/supabase-js@2";
import { AppError } from "../../shared/http.ts";
import { supabaseAdmin } from "../../shared/supabase.ts";
import { findByAuthId } from "../customers/customers.services.ts";

import { getFirstActiveRedirectUrl } from "../customer-modules/customer-modules.services.ts"; // ← antes decía .controller.ts
import type { Customer, RegisterResult } from "../customers/customers.types.ts";

// ─────────────── Verificación del usuario (JWT) ───────────────

function bearerToken(req: Request): string {
  const [scheme, token] = (req.headers.get("Authorization") ?? "").split(" ");
  if (scheme?.toLowerCase() !== "bearer" || !token) {
    throw new AppError(401, "Debes iniciar sesión para continuar.", "UNAUTHORIZED");
  }
  return token;
}

/** Usuario autenticado en Supabase Auth (correo/contraseña o Google). */
export async function requireUser(req: Request): Promise<User> {
  const { data, error } = await supabaseAdmin.auth.getUser(bearerToken(req));
  if (error || !data.user) {
    throw new AppError(401, "Tu sesión no es válida o expiró. Inicia sesión nuevamente.", "UNAUTHORIZED");
  }
  return data.user;
}

/** Igual que requireUser, pero además exige que la cuenta venga de Google. */
export async function requireGoogleUser(req: Request): Promise<User> {
  const user = await requireUser(req);
  const viaGoogle =
    user.app_metadata?.provider === "google" ||
    (user.identities ?? []).some((identity) => identity.provider === "google");

  if (!viaGoogle) {
    throw new AppError(403, "Esta acción solo está disponible con una cuenta de Google.", "GOOGLE_REQUIRED");
  }
  return user;
}

// //////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * Customer al que pertenece el usuario autenticado:
 *  - el dueño de la cuenta (customers.cust_auth_id), o
 *  - un personal con acceso al sistema (staffs.stff_auth_id): entra con el customer de su empresa.
 * Devuelve null si no es ninguno de los dos.
 */
export async function findCustomerForUser(user: User): Promise<Customer | null> {
  const owner = await findByAuthId(user.id);
  if (owner) return owner;

  const { data: staff, error } = await supabaseAdmin
    .from("staffs")
    .select("cust_id, stff_active, stff_access_system")
    .eq("stff_auth_id", user.id)
    .maybeSingle();

  if (error) {
    console.error("auth.findCustomerForUser (staff):", error);
    throw new AppError(500, "No se pudo consultar tu cuenta.");
  }
  if (!staff) return null;

  if (!staff.stff_active || !staff.stff_access_system) {
    throw new AppError(
      403,
      "Tu acceso al sistema está desactivado. Contacta a tu administrador.",
      "STAFF_ACCESS_DISABLED",
    );
  }

  const { data: customer, error: errCustomer } = await supabaseAdmin
    .from("customers")
    .select("*")
    .eq("cust_id", staff.cust_id)
    .maybeSingle();

  if (errCustomer) {
    console.error("auth.findCustomerForUser (customer):", errCustomer);
    throw new AppError(500, "No se pudo consultar tu cuenta.");
  }
  return customer as Customer | null;
}

// //////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * Login de un usuario ya autenticado (correo/contraseña o Google):
 * NO crea nada, solo comprueba que tenga customer activo y devuelve su destino.
 */
export async function getCustomerSession(user: User): Promise<RegisterResult> {
  const customer = await findCustomerForUser(user);

  if (!customer) {
    throw new AppError(
      404,
      "Esta cuenta no está registrada. Crea tu cuenta con Google primero.",
      "CUSTOMER_NOT_FOUND",
    );
  }
  if (!customer.cust_is_active) {
    throw new AppError(403, "Tu cuenta está desactivada. Contacta a soporte.");
  }

  const redirectUrl = await getFirstActiveRedirectUrl(customer.cust_id);
  return { created: false, customer, redirectUrl };
}
// //////////////////////////////////////////////////////////////////////////////////////////////////////
/** Customer dueño de la sesión. Lo usan todos los módulos (logos, storage, staffs...). */
export interface AccessContext {
  custId: number;
  codeSystem: number;
  bucketName: string;
}

export async function getAccessContext(req: Request): Promise<AccessContext> {
  const user = await requireUser(req);
  const customer = await findCustomerForUser(user);

  if (!customer) {
    throw new AppError(404, "Esta cuenta no está registrada.", "CUSTOMER_NOT_FOUND");
  }
  if (!customer.cust_is_active) {
    throw new AppError(403, "Tu cuenta está desactivada. Contacta a soporte.");
  }
  return {
    custId: customer.cust_id,
    codeSystem: customer.cust_code_system,
    bucketName: String(customer.cust_name_bucket),
  };
}
// ─────────────── Contraseña de la cuenta ───────────────

const MIN_PASSWORD = 6;
const MAX_PASSWORD = 72; // Supabase Auth ignora lo que pase de 72 bytes

/** ¿La cuenta ya tiene contraseña? (solo Google → false; correo/contraseña o clave creada → true). */
export function hasPassword(user: User): boolean {
  const providers = user.app_metadata?.providers;
  return (
    user.app_metadata?.has_password === true ||
    (Array.isArray(providers) && providers.includes("email")) ||
    (user.identities ?? []).some((identity) => identity.provider === "email")
  );
}

/** Valida la clave nueva y su confirmación. Devuelve la clave o lanza AppError 400. */
export function validateNewPassword(password: unknown, confirmPassword: unknown): string {
  if (typeof password !== "string" || password === "") {
    throw new AppError(400, "Ingresa tu nueva clave.", "INVALID_PASSWORD");
  }
  if (password.length < MIN_PASSWORD) {
    throw new AppError(400, `La clave debe tener al menos ${MIN_PASSWORD} caracteres.`, "INVALID_PASSWORD");
  }
  if (new TextEncoder().encode(password).length > MAX_PASSWORD) {
    throw new AppError(400, "La clave es demasiado larga.", "INVALID_PASSWORD");
  }
  if (password !== confirmPassword) {
    throw new AppError(400, "Las claves no coinciden.", "PASSWORD_MISMATCH");
  }
  return password;
}

/** Crea o reemplaza la contraseña del usuario. La clave nunca se guarda ni se devuelve. */
export async function savePassword(user: User, password: string): Promise<void> {
  const { error } = await supabaseAdmin.auth.admin.updateUserById(user.id, {
    password,
    app_metadata: { ...(user.app_metadata ?? {}), has_password: true },
  });

  if (error) {
    console.error("auth.savePassword:", error);
    if (error.code === "same_password") {
      throw new AppError(422, "La nueva clave debe ser distinta a la actual.", "SAME_PASSWORD");
    }
    if (error.code === "weak_password") {
      throw new AppError(400, "La clave es muy débil. Usa letras, números y símbolos.", "WEAK_PASSWORD");
    }
    throw new AppError(500, "No se pudo guardar la clave.");
  }
}
/**
 * "Acceder con Google" crea el usuario en Supabase Auth aunque no tenga cuenta en el sistema.
 * Si no tiene customer, se borra ese usuario para no dejar cuentas fantasma.
 * Ante la duda NO borra: no toca usuarios con staff o worker, ni con otro proveedor además de Google.
 */
export async function deleteOrphanGoogleUser(user: User): Promise<void> {
  const soloGoogle = (user.identities ?? []).every((identity) => identity.provider === "google");
  if (!soloGoogle) return;

  const [staff, worker] = await Promise.all([
    supabaseAdmin
      .from("staffs")
      .select("stff_id", { count: "exact", head: true })
      .eq("stff_auth_id", user.id),
    supabaseAdmin
      .from("workers")
      .select("wker_id", { count: "exact", head: true })
      .eq("wker_auth_id", user.id),
  ]);

  if (staff.error || worker.error) {
    console.error("auth.deleteOrphanGoogleUser:", staff.error ?? worker.error);
    return;
  }
  if ((staff.count ?? 0) > 0 || (worker.count ?? 0) > 0) return;

  const { error } = await supabaseAdmin.auth.admin.deleteUser(user.id);
  if (error) console.error("auth.deleteOrphanGoogleUser:", error);
}
// ─────────────── Verificación de Google SIN crear usuario en Supabase ───────────────

export interface GoogleIdentity {
  sub: string;
  email: string;
}

/** Valida el token de Google (firma, expiración, audiencia y correo verificado). */
export async function verifyGoogleCredential(credential: unknown): Promise<GoogleIdentity> {
  if (typeof credential !== "string" || credential.length < 20 || credential.length > 4096) {
    throw new AppError(400, "La credencial de Google no es válida.", "INVALID_GOOGLE_TOKEN");
  }

  const clientId = Deno.env.get("GOOGLE_CLIENT_ID");
  if (!clientId) {
    console.error("auth.verifyGoogleCredential: falta el secret GOOGLE_CLIENT_ID");
    throw new AppError(500, "Google no está configurado en el servidor.");
  }

  const res = await fetch(
    `https://oauth2.googleapis.com/tokeninfo?id_token=${encodeURIComponent(credential)}`,
  );
  if (!res.ok) {
    throw new AppError(401, "No se pudo verificar tu cuenta de Google.", "INVALID_GOOGLE_TOKEN");
  }

  const info = (await res.json().catch(() => null)) as Record<string, unknown> | null;
  const issuerOk = info?.iss === "accounts.google.com" || info?.iss === "https://accounts.google.com";
  const verified = String(info?.email_verified) === "true";

  if (
    !info || info.aud !== clientId || !issuerOk || !verified ||
    typeof info.sub !== "string" || typeof info.email !== "string"
  ) {
    throw new AppError(401, "No se pudo verificar tu cuenta de Google.", "INVALID_GOOGLE_TOKEN");
  }

  return { sub: info.sub, email: info.email.toLowerCase() };
}

/** Resultado de buscar un correo en Supabase Authentication y su customer. */
export interface CuentaPorCorreo {
  /** El correo existe en auth.users. */
  enAuth: boolean;
  /** Tiene fila en customers (cust_auth_id = id del usuario de Auth). */
  customer: { cust_id: number; cust_is_active: boolean } | null;
}

/**
 * Busca el correo (ya verificado por Google) en Supabase Authentication y, si existe,
 * su customer. Usa la función SQL customer_by_email.
 */
export async function findAccountByEmail(email: string): Promise<CuentaPorCorreo> {
  const { data, error } = await supabaseAdmin.rpc("customer_by_email", { p_email: email });

  if (error) {
    console.error("auth.findAccountByEmail:", error);
    throw new AppError(500, "No se pudo consultar tu cuenta.");
  }

  const row = (Array.isArray(data) ? data[0] : data) as
    | { auth_user_id: string | null; cust_id: number | null; cust_is_active: boolean | null }
    | null
    | undefined;

  if (!row?.auth_user_id) return { enAuth: false, customer: null };
  if (row.cust_id === null || row.cust_id === undefined) return { enAuth: true, customer: null };

  return {
    enAuth: true,
    customer: { cust_id: row.cust_id, cust_is_active: row.cust_is_active !== false },
  };
}