import type { User } from "npm:@supabase/supabase-js@2";
import { AppError } from "../../shared/http.ts";
import { supabaseAdmin } from "../../shared/supabase.ts";
import { findByAuthId } from "../customers/customers.services.ts";
import { getFirstActiveRedirectUrl } from "../customer-modules/customer-modules.controller.ts";
import type { RegisterResult } from "../customers/customers.types.ts";

// ─────────────── Verificación del usuario (JWT) ───────────────

function bearerToken(req: Request): string {
  const [scheme, token] = (req.headers.get("Authorization") ?? "").split(" ");
  if (scheme?.toLowerCase() !== "bearer" || !token) {
    throw new AppError(401, "Debes iniciar sesión para continuar.", "UNAUTHORIZED");
  }
  return token;
}

/** Usuario autenticado en Supabase Auth (correo/contraseña o Google). */
export async function requireUser(req: Request): Promise<User> {
  const { data, error } = await supabaseAdmin.auth.getUser(bearerToken(req));
  if (error || !data.user) {
    throw new AppError(401, "Tu sesión no es válida o expiró. Inicia sesión nuevamente.", "UNAUTHORIZED");
  }
  return data.user;
}

/** Igual que requireUser, pero además exige que la cuenta venga de Google. */
export async function requireGoogleUser(req: Request): Promise<User> {
  const user = await requireUser(req);
  const viaGoogle =
    user.app_metadata?.provider === "google" ||
    (user.identities ?? []).some((identity) => identity.provider === "google");

  if (!viaGoogle) {
    throw new AppError(403, "Esta acción solo está disponible con una cuenta de Google.", "GOOGLE_REQUIRED");
  }
  return user;
}

// //////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * Login de un usuario ya autenticado (correo/contraseña o Google):
 * NO crea nada, solo comprueba que tenga customer activo y devuelve su destino.
 */
export async function getCustomerSession(user: User): Promise<RegisterResult> {
  const customer = await findByAuthId(user.id);

  if (!customer) {
    throw new AppError(
      404,
      "Esta cuenta no está registrada. Crea tu cuenta con Google primero.",
      "CUSTOMER_NOT_FOUND",
    );
  }
  if (!customer.cust_is_active) {
    throw new AppError(403, "Tu cuenta está desactivada. Contacta a soporte.");
  }

  const redirectUrl = await getFirstActiveRedirectUrl(customer.cust_id);
  return { created: false, customer, redirectUrl };
}
// //////////////////////////////////////////////////////////////////////////////////////////////////////

// ─────────────── Contraseña de la cuenta ───────────────

const MIN_PASSWORD = 6;
const MAX_PASSWORD = 72; // Supabase Auth ignora lo que pase de 72 bytes

/** ¿La cuenta ya tiene contraseña? (solo Google → false; correo/contraseña o clave creada → true). */
export function hasPassword(user: User): boolean {
  const providers = user.app_metadata?.providers;
  return (
    user.app_metadata?.has_password === true ||
    (Array.isArray(providers) && providers.includes("email")) ||
    (user.identities ?? []).some((identity) => identity.provider === "email")
  );
}

/** Valida la clave nueva y su confirmación. Devuelve la clave o lanza AppError 400. */
export function validateNewPassword(password: unknown, confirmPassword: unknown): string {
  if (typeof password !== "string" || password === "") {
    throw new AppError(400, "Ingresa tu nueva clave.", "INVALID_PASSWORD");
  }
  if (password.length < MIN_PASSWORD) {
    throw new AppError(400, `La clave debe tener al menos ${MIN_PASSWORD} caracteres.`, "INVALID_PASSWORD");
  }
  if (new TextEncoder().encode(password).length > MAX_PASSWORD) {
    throw new AppError(400, "La clave es demasiado larga.", "INVALID_PASSWORD");
  }
  if (password !== confirmPassword) {
    throw new AppError(400, "Las claves no coinciden.", "PASSWORD_MISMATCH");
  }
  return password;
}

/** Crea o reemplaza la contraseña del usuario. La clave nunca se guarda ni se devuelve. */
export async function savePassword(user: User, password: string): Promise<void> {
  const { error } = await supabaseAdmin.auth.admin.updateUserById(user.id, {
    password,
    app_metadata: { ...(user.app_metadata ?? {}), has_password: true },
  });

  if (error) {
    console.error("auth.savePassword:", error);
    if (error.code === "same_password") {
      throw new AppError(422, "La nueva clave debe ser distinta a la actual.", "SAME_PASSWORD");
    }
    if (error.code === "weak_password") {
      throw new AppError(400, "La clave es muy débil. Usa letras, números y símbolos.", "WEAK_PASSWORD");
    }
    throw new AppError(500, "No se pudo guardar la clave.");
  }
}