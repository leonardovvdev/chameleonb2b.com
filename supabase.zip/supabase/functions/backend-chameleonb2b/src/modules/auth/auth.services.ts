import type { User } from "npm:@supabase/supabase-js@2";
import { AppError } from "../../shared/http.ts";
import { supabaseAdmin } from "../../shared/supabase.ts";
import { findByAuthId } from "../customers/customers.services.ts";
import { getFirstActiveRedirectUrl } from "../customer-modules/customer-modules.controller.ts";
import type { RegisterResult } from "../customers/customers.types.ts";

// ─────────────── Verificación del usuario (JWT) ───────────────

function bearerToken(req: Request): string {
  const [scheme, token] = (req.headers.get("Authorization") ?? "").split(" ");
  if (scheme?.toLowerCase() !== "bearer" || !token) {
    throw new AppError(401, "Debes iniciar sesión para continuar.", "UNAUTHORIZED");
  }
  return token;
}

/** Usuario autenticado en Supabase Auth (correo/contraseña o Google). */
export async function requireUser(req: Request): Promise<User> {
  const { data, error } = await supabaseAdmin.auth.getUser(bearerToken(req));
  if (error || !data.user) {
    throw new AppError(401, "Tu sesión no es válida o expiró. Inicia sesión nuevamente.", "UNAUTHORIZED");
  }
  return data.user;
}

/** Igual que requireUser, pero además exige que la cuenta venga de Google. */
export async function requireGoogleUser(req: Request): Promise<User> {
  const user = await requireUser(req);
  const viaGoogle =
    user.app_metadata?.provider === "google" ||
    (user.identities ?? []).some((identity) => identity.provider === "google");

  if (!viaGoogle) {
    throw new AppError(403, "Esta acción solo está disponible con una cuenta de Google.", "GOOGLE_REQUIRED");
  }
  return user;
}

// //////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * Login de un usuario ya autenticado (correo/contraseña o Google):
 * NO crea nada, solo comprueba que tenga customer activo y devuelve su destino.
 */
export async function getCustomerSession(user: User): Promise<RegisterResult> {
  const customer = await findByAuthId(user.id);

  if (!customer) {
    throw new AppError(
      404,
      "Esta cuenta no está registrada. Crea tu cuenta con Google primero.",
      "CUSTOMER_NOT_FOUND",
    );
  }
  if (!customer.cust_is_active) {
    throw new AppError(403, "Tu cuenta está desactivada. Contacta a soporte.");
  }

  const redirectUrl = await getFirstActiveRedirectUrl(customer.cust_id);
  return { created: false, customer, redirectUrl };
}
// //////////////////////////////////////////////////////////////////////////////////////////////////////