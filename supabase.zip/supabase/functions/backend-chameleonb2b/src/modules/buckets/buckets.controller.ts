import { supabaseAdmin } from "../../shared/supabase.ts";
import { AppError, json } from "../../shared/http.ts";
import { getAccessContext } from "../staffs/staff.services.ts";
import {
  createFolder,
  deleteFile,
  deleteFolder,
  listFolderContent,
  listFolders,
  MAX_IMAGE_BYTES,
  LIMITS,
  uploadFile,
} from "./buckets.services.ts";

/**
 * Carpetas que se crean por defecto dentro del bucket de cada cliente.
 * Supabase Storage no tiene carpetas reales: son prefijos de ruta, por eso
 * cada una se "materializa" subiendo un archivo vacío (placeholder).
 * Las rutas anidadas crean también su carpeta padre (gestion_digital/).
 */
const DEFAULT_FOLDERS = [
  "imagen_customer",
  "gestion_empresarial",
  "gestion_empresarial/imagen_staffs",
  "storage",
  "storage/logos",
  "storage/productos",
  "storage/marcas",
  "storage/categorias",
];

/** Mismo nombre que usa el dashboard de Supabase para carpetas vacías. */
const FOLDER_PLACEHOLDER = ".emptyFolderPlaceholder";

/** Crea el bucket privado del cliente. */
export async function createBucket(bucketName: string): Promise<void> {
  const { error } = await supabaseAdmin.storage.createBucket(bucketName, { public: false });

  if (error) {
    console.error("storage.createBucket", error);
    throw new AppError(500, "No se pudo crear el almacenamiento del cliente.");
  }
}

/** Crea las carpetas por defecto dentro del bucket del cliente. */
export async function createDefaultFolders(bucketName: string): Promise<void> {
  const results = await Promise.all(
    DEFAULT_FOLDERS.map((folder) =>
      supabaseAdmin.storage
        .from(bucketName)
        .upload(`${folder}/${FOLDER_PLACEHOLDER}`, new Uint8Array(0), {
          contentType: "text/plain",
          upsert: true,
        })
    ),
  );

  const failed = results.find((r) => r.error);
  if (failed?.error) {
    console.error("storage.createDefaultFolders", failed.error);
    throw new AppError(500, "No se pudieron crear las carpetas del cliente.");
  }
}

/**
 * Borra el bucket (rollback). Un bucket con archivos no se puede borrar:
 * primero se vacía (contiene los placeholders de las carpetas).
 * Nunca lanza error, para no tapar el error original del registro.
 */
export async function deleteBucket(bucketName: string): Promise<void> {
  await supabaseAdmin.storage.emptyBucket(bucketName).catch(() => {});
  await supabaseAdmin.storage.deleteBucket(bucketName).catch(() => {});
}

/** Segundos que dura el enlace firmado de una imagen (1 hora). */
const SIGNED_URL_SECONDS = 60 * 60;

/**
 * URL temporal para ver un archivo del bucket privado del cliente.
 * Devuelve null si el archivo no existe (la imagen es opcional, no debe romper la pantalla).
 */
export async function createSignedUrl(bucketName: string, filePath: string): Promise<string | null> {
  const { data, error } = await supabaseAdmin.storage
    .from(bucketName)
    .createSignedUrl(filePath, SIGNED_URL_SECONDS);

  if (error || !data) {
    console.error("storage.createSignedUrl", bucketName, filePath, error);
    return null;
  }
  return data.signedUrl;
}

/**
 * URLs temporales para varios archivos del bucket privado, en una sola llamada.
 * Devuelve un Map ruta → URL. Los archivos que no existen simplemente no aparecen.
 */
export async function createSignedUrls(
  bucketName: string,
  filePaths: string[],
): Promise<Map<string, string>> {
  const urls = new Map<string, string>();
  if (filePaths.length === 0) return urls;

  const { data, error } = await supabaseAdmin.storage
    .from(bucketName)
    .createSignedUrls(filePaths, SIGNED_URL_SECONDS);

  if (error || !data) {
    console.error("storage.createSignedUrls", bucketName, error);
    return urls; // las imágenes son opcionales: no deben romper la pantalla
  }

  for (const item of data) {
    if (item.path && item.signedUrl && !item.error) urls.set(item.path, item.signedUrl);
  }
  return urls;
}

/* ───────────────────────── Handlers de /storage ───────────────────────── */

const param = (req: Request, key: string) => new URL(req.url).searchParams.get(key) ?? "";

/** GET /storage/folders → { items, limits, userFolders } */
export async function listFoldersHandler(req: Request): Promise<Response> {
  const { bucketName } = await getAccessContext(req);
  return json(await listFolders(bucketName));
}

/** POST /storage/folders?name=Mi carpeta → la carpeta creada */
export async function createFolderHandler(req: Request): Promise<Response> {
  const { bucketName } = await getAccessContext(req);
  return json(await createFolder(bucketName, param(req, "name")), 201);
}

/** DELETE /storage/folders?name=Mi carpeta → { name } */
export async function deleteFolderHandler(req: Request): Promise<Response> {
  const { bucketName } = await getAccessContext(req);
  const name = param(req, "name");
  await deleteFolder(bucketName, name);
  return json({ name });
}

/** GET /storage/files?folder=Mi carpeta → { folder, subfolders, files } */
export async function listFilesHandler(req: Request): Promise<Response> {
  const { bucketName } = await getAccessContext(req);
  return json(await listFolderContent(bucketName, param(req, "folder")));
}

/** POST /storage/files (multipart: folder, file) → el archivo subido */
export async function uploadFileHandler(req: Request): Promise<Response> {
  const { bucketName } = await getAccessContext(req);

  const declared = Number(req.headers.get("content-length") ?? 0);
  if (declared > Math.max(MAX_IMAGE_BYTES, LIMITS.maxVideoBytes) + 1024 * 100) {
    throw new AppError(400, "El archivo no puede pesar más de 5 MB.", "FILE_TOO_LARGE");
  }

  const form = await req.formData().catch(() => null);
  if (!form) throw new AppError(400, "El cuerpo de la petición no es válido.", "INVALID_BODY");

  const rawFile = form.get("file");
  if (!(rawFile instanceof File) || rawFile.size === 0) {
    throw new AppError(400, "Debes seleccionar una imagen o un video.", "FILE_REQUIRED");
  }
  return json(await uploadFile(bucketName, String(form.get("folder") ?? ""), rawFile), 201);
}

/** DELETE /storage/files?folder=Mi carpeta&name=123.webp → { name } */
export async function deleteFileHandler(req: Request): Promise<Response> {
  const { bucketName } = await getAccessContext(req);
  const name = param(req, "name");
  await deleteFile(bucketName, param(req, "folder"), name);
  return json({ name });
}