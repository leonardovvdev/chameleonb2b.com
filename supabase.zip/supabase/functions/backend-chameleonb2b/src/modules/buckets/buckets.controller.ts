import { AppError, json } from "../../shared/http.ts";
import { getAccessContext } from "../auth/auth.services.ts";
import {
  createFolder,
  deleteFile,
  deleteFolder,
  listFolderContent,
  listFolders,
  MAX_IMAGE_BYTES,
  LIMITS,
  uploadFile,
} from "./buckets.services.ts";

const param = (req: Request, key: string) => new URL(req.url).searchParams.get(key) ?? "";

/** GET /storage/folders → { items, limits, userFolders } */
export async function listFoldersHandler(req: Request): Promise<Response> {
  const { bucketName } = await getAccessContext(req);
  return json(await listFolders(bucketName));
}

/** POST /storage/folders?name=Mi carpeta → la carpeta creada */
export async function createFolderHandler(req: Request): Promise<Response> {
  const { bucketName } = await getAccessContext(req);
  return json(await createFolder(bucketName, param(req, "name")), 201);
}

/** DELETE /storage/folders?name=Mi carpeta → { name } */
export async function deleteFolderHandler(req: Request): Promise<Response> {
  const { bucketName } = await getAccessContext(req);
  const name = param(req, "name");
  await deleteFolder(bucketName, name);
  return json({ name });
}

/** GET /storage/files?folder=Mi carpeta → { folder, subfolders, files } */
export async function listFilesHandler(req: Request): Promise<Response> {
  const { bucketName } = await getAccessContext(req);
  return json(await listFolderContent(bucketName, param(req, "folder")));
}

/** POST /storage/files (multipart: folder, file) → el archivo subido */
export async function uploadFileHandler(req: Request): Promise<Response> {
  const { bucketName } = await getAccessContext(req);

  const declared = Number(req.headers.get("content-length") ?? 0);
  if (declared > Math.max(MAX_IMAGE_BYTES, LIMITS.maxVideoBytes) + 1024 * 100) {
    throw new AppError(400, "El archivo no puede pesar más de 5 MB.", "FILE_TOO_LARGE");
  }

  const form = await req.formData().catch(() => null);
  if (!form) throw new AppError(400, "El cuerpo de la petición no es válido.", "INVALID_BODY");

  const rawFile = form.get("file");
  if (!(rawFile instanceof File) || rawFile.size === 0) {
    throw new AppError(400, "Debes seleccionar una imagen o un video.", "FILE_REQUIRED");
  }
  return json(await uploadFile(bucketName, String(form.get("folder") ?? ""), rawFile), 201);
}

/** DELETE /storage/files?folder=Mi carpeta&name=123.webp → { name } */
export async function deleteFileHandler(req: Request): Promise<Response> {
  const { bucketName } = await getAccessContext(req);
  const name = param(req, "name");
  await deleteFile(bucketName, param(req, "folder"), name);
  return json({ name });
}