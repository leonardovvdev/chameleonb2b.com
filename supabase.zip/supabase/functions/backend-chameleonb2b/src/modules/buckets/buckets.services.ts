import { AppError } from "../../shared/http.ts";
import { supabaseAdmin } from "../../shared/supabase.ts";
import { random11Digits } from "../../shared/random.ts";
import { convertImageToWebp } from "../../shared/convert-img-to-webp.ts";

import type {
  StorageFile,
  StorageFolder,
  StorageFolderContent,
  StorageLimits,
} from "./buckets.types.ts";

/* ───────────────────────── Bucket del customer ───────────────────────── */

/**
 * Carpetas que se crean por defecto dentro del bucket de cada cliente.
 * Supabase Storage no tiene carpetas reales: son prefijos de ruta, por eso
 * cada una se "materializa" subiendo un archivo vacío (placeholder).
 */
export const DEFAULT_FOLDERS = [
  "customer",
  "customer/customer_img",
  "gestion_empresarial",
  "gestion_empresarial/staffs_img",
  "storage",
  "storage/logos",
  "storage/productos",
  "storage/marcas",
  "storage/categorias",
];

/** Mismo nombre que usa el dashboard de Supabase para carpetas vacías. */
export const FOLDER_PLACEHOLDER = ".emptyFolderPlaceholder";

/** Carpeta y prefijo de la foto del customer dentro de su bucket. */
const CUSTOMER_IMG_FOLDER = "customer/customer_img";

/** Crea el bucket privado del cliente. */
export async function createBucket(bucketName: string): Promise<void> {
  const { error } = await supabaseAdmin.storage.createBucket(bucketName, { public: false });

  if (error) {
    console.error("storage.createBucket", error);
    throw new AppError(500, "No se pudo crear el almacenamiento del cliente.");
  }
}

/** Crea las carpetas por defecto dentro del bucket del cliente. */
export async function createDefaultFolders(bucketName: string): Promise<void> {
  const results = await Promise.all(
    DEFAULT_FOLDERS.map((folder) =>
      supabaseAdmin.storage
        .from(bucketName)
        .upload(`${folder}/${FOLDER_PLACEHOLDER}`, new Uint8Array(0), {
          contentType: "text/plain",
          upsert: true,
        })
    ),
  );

  const failed = results.find((r) => r.error);
  if (failed?.error) {
    console.error("storage.createDefaultFolders", failed.error);
    throw new AppError(500, "No se pudieron crear las carpetas del cliente.");
  }
}

/**
 * Borra el bucket (rollback). Un bucket con archivos no se puede borrar:
 * primero se vacía (contiene los placeholders de las carpetas).
 * Nunca lanza error, para no tapar el error original del registro.
 */
export async function deleteBucket(bucketName: string): Promise<void> {
  await supabaseAdmin.storage.emptyBucket(bucketName).catch(() => {});
  await supabaseAdmin.storage.deleteBucket(bucketName).catch(() => {});
}

/** Segundos que dura el enlace firmado de una imagen (1 hora). */
const SIGNED_URL_SECONDS = 60 * 60;

/**
 * URL temporal para ver un archivo del bucket privado del cliente.
 * Devuelve null si el archivo no existe (la imagen es opcional, no debe romper la pantalla).
 */
export async function createSignedUrl(bucketName: string, filePath: string): Promise<string | null> {
  const { data, error } = await supabaseAdmin.storage
    .from(bucketName)
    .createSignedUrl(filePath, SIGNED_URL_SECONDS);

  if (error || !data) {
    console.error("storage.createSignedUrl", bucketName, filePath, error);
    return null;
  }
  return data.signedUrl;
}

/**
 * URLs temporales para varios archivos del bucket privado, en una sola llamada.
 * Devuelve un Map ruta → URL. Los archivos que no existen simplemente no aparecen.
 */
export async function createSignedUrls(
  bucketName: string,
  filePaths: string[],
): Promise<Map<string, string>> {
  const urls = new Map<string, string>();
  if (filePaths.length === 0) return urls;

  const { data, error } = await supabaseAdmin.storage
    .from(bucketName)
    .createSignedUrls(filePaths, SIGNED_URL_SECONDS);

  if (error || !data) {
    console.error("storage.createSignedUrls", bucketName, error);
    return urls; // las imágenes son opcionales: no deben romper la pantalla
  }

  for (const item of data) {
    if (item.path && item.signedUrl && !item.error) urls.set(item.path, item.signedUrl);
  }
  return urls;
}

/** URL firmada de la foto del customer (null si no tiene foto). */
export async function getCustomerImageUrl(
  bucketName: string,
  imgLink: string | null,
): Promise<string | null> {
  if (!imgLink) return null;
  return await createSignedUrl(bucketName, `${CUSTOMER_IMG_FOLDER}/${imgLink}`);
}
/** Límites del módulo Storage. */
export const LIMITS: StorageLimits = {
  maxFolders: 5, // carpetas creadas por el usuario (sin subcarpetas)
  maxFilesPerFolder: 10, // imágenes + videos por carpeta
  maxVideoBytes: 5 * 1024 * 1024, // 5 MB
};
export const MAX_IMAGE_BYTES = 5 * 1024 * 1024;

/** Raíz de este módulo: solo se trabaja dentro de {bucket}/storage/. */
const ROOT = "storage";

/** Ruta completa de una carpeta dentro del bucket: storage/{carpeta} */
const at = (folder: string) => `${ROOT}/${folder}`;

/** Carpetas de storage/ que crea el sistema (DEFAULT_FOLDERS): no se borran ni cuentan para el máximo. */
const SYSTEM_FOLDERS = ["logos", "productos", "marcas", "categorias"];

const IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp", "image/gif"];
const VIDEO_TYPES = ["video/mp4", "video/webm", "video/quicktime"];
const VIDEO_EXT: Record<string, string> = {
  "video/mp4": "mp4",
  "video/webm": "webm",
  "video/quicktime": "mov",
};
const MAX_UPLOAD_ATTEMPTS = 5;
const MAX_FOLDER_NAME = 40;

/* ───────────────────────── Utilidades ───────────────────────── */

const isSystem = (name: string) => SYSTEM_FOLDERS.includes(name);

/** Una entrada de list() es carpeta cuando no trae id (Supabase no tiene carpetas reales). */
const isFolderEntry = (e: { id: string | null }) => e.id === null;

const kindOf = (name: string): "image" | "video" | null => {
  if (/\.(webp|jpe?g|png|gif)$/i.test(name)) return "image";
  if (/\.(mp4|webm|mov)$/i.test(name)) return "video";
  return null;
};

/** Solo letras, números, espacios, guion y guion bajo. Nunca "/" (no hay subcarpetas). */
export function cleanFolderName(raw: string): string {
  const name = raw.trim().replace(/\s+/g, " ");
  if (!name) throw new AppError(400, "El nombre de la carpeta es obligatorio.", "NAME_REQUIRED");
  if (name.length > MAX_FOLDER_NAME) {
    throw new AppError(400, `El nombre no puede superar los ${MAX_FOLDER_NAME} caracteres.`, "NAME_TOO_LONG");
  }
  if (!/^[\p{L}\p{N} _-]+$/u.test(name) || name.startsWith(".")) {
    throw new AppError(
      400,
      "Usa solo letras, números, espacios, guion y guion bajo. No se permiten subcarpetas.",
      "INVALID_NAME",
    );
  }
  return name;
}

async function listEntries(bucketName: string, path: string) {
  const { data, error } = await supabaseAdmin.storage
    .from(bucketName)
    .list(path, { limit: 1000, sortBy: { column: "name", order: "asc" } });

  if (error) {
    console.error("buckets.listEntries:", path, error);
    throw new AppError(500, "No se pudo leer el almacenamiento.");
  }
  return data ?? [];
}

/** Se valida que la carpeta exista dentro de storage/. */
async function assertFolderExists(bucketName: string, folder: string): Promise<void> {
  const root = await listEntries(bucketName, ROOT);
  if (!root.some((e) => isFolderEntry(e) && e.name === folder)) {
    throw new AppError(404, "La carpeta no existe.", "NOT_FOUND");
  }
}

async function countFiles(bucketName: string, folder: string): Promise<number> {
  const entries = await listEntries(bucketName, at(folder));
  return entries.filter((e) => !isFolderEntry(e) && kindOf(e.name)).length;
}

/* ───────────────────────── Carpetas ───────────────────────── */

/** READ: todas las carpetas que hay dentro de storage/. */
export async function listFolders(bucketName: string): Promise<{ items: StorageFolder[]; limits: StorageLimits; userFolders: number }> {
  const root = await listEntries(bucketName, ROOT);
  const names = root.filter(isFolderEntry).map((e) => e.name);

  const items = await Promise.all(
    names.map(async (name): Promise<StorageFolder> => {
      const entries = await listEntries(bucketName, at(name));
      return {
        name,
        system: isSystem(name),
        files: entries.filter((e) => !isFolderEntry(e) && kindOf(e.name)).length,
        subfolders: entries.filter(isFolderEntry).length,
      };
    }),
  );

  items.sort((a, b) => a.name.localeCompare(b.name, "es"));
  return { items, limits: LIMITS, userFolders: items.filter((f) => !f.system).length };
}

/** CREATE: carpeta de primer nivel (máximo 5 creadas por el usuario, sin subcarpetas). */
export async function createFolder(bucketName: string, rawName: string): Promise<StorageFolder> {
  const name = cleanFolderName(rawName);
  const { items } = await listFolders(bucketName);

  if (items.some((f) => f.name.toLowerCase() === name.toLowerCase())) {
    throw new AppError(409, "Ya existe una carpeta con ese nombre.", "FOLDER_EXISTS");
  }
  if (items.filter((f) => !f.system).length >= LIMITS.maxFolders) {
    throw new AppError(400, `Solo puedes crear hasta ${LIMITS.maxFolders} carpetas.`, "MAX_FOLDERS");
  }

  const { error } = await supabaseAdmin.storage
    .from(bucketName)
    .upload(`${at(name)}/${FOLDER_PLACEHOLDER}`, new Uint8Array(0), { contentType: "text/plain", upsert: false });

  if (error) {
    console.error("buckets.createFolder:", error);
    throw new AppError(500, "No se pudo crear la carpeta.");
  }
  return { name, system: false, files: 0, subfolders: 0 };
}

/** DELETE: borra una carpeta creada por el usuario y todo su contenido. */
export async function deleteFolder(bucketName: string, rawName: string): Promise<void> {
  const name = cleanFolderName(rawName);
  if (isSystem(name)) {
    throw new AppError(403, "Las carpetas del sistema no se pueden eliminar.", "SYSTEM_FOLDER");
  }
  await assertFolderExists(bucketName, name);

  const entries = await listEntries(bucketName, at(name));
  const paths = entries.filter((e) => !isFolderEntry(e)).map((e) => `${at(name)}/${e.name}`);

  if (paths.length > 0) {
    const { error } = await supabaseAdmin.storage.from(bucketName).remove(paths);
    if (error) {
      console.error("buckets.deleteFolder:", error);
      throw new AppError(500, "No se pudo eliminar la carpeta.");
    }
  }
}

/* ───────────────────────── Archivos ───────────────────────── */

/** READ: contenido de una carpeta (archivos con enlace firmado + subcarpetas existentes). */
export async function listFolderContent(bucketName: string, rawFolder: string): Promise<StorageFolderContent> {
  const folder = cleanFolderName(rawFolder);
  await assertFolderExists(bucketName, folder);

  const entries = await listEntries(bucketName, at(folder));
  const fileEntries = entries.filter((e) => !isFolderEntry(e) && kindOf(e.name));
  const urls = await createSignedUrls(bucketName, fileEntries.map((e) => `${at(folder)}/${e.name}`));

  const files: StorageFile[] = fileEntries.map((e) => ({
    name: e.name,
    path: `${at(folder)}/${e.name}`,
    kind: kindOf(e.name)!,
    size: (e.metadata as { size?: number } | null)?.size ?? null,
    url: urls.get(`${at(folder)}/${e.name}`) ?? null,
  }));

  return { folder, subfolders: entries.filter(isFolderEntry).map((e) => e.name), files };
}

/** CREATE: sube una imagen (se convierte a WebP) o un video (máx. 5 MB). Máximo 10 por carpeta. */
export async function uploadFile(bucketName: string, rawFolder: string, file: File): Promise<StorageFile> {
  const folder = cleanFolderName(rawFolder);
  await assertFolderExists(bucketName, folder);

  const isImage = IMAGE_TYPES.includes(file.type);
  const isVideo = VIDEO_TYPES.includes(file.type);

  if (!isImage && !isVideo) {
    throw new AppError(400, "Formato no permitido. Usa JPG, PNG, WEBP, GIF, MP4, WEBM o MOV.", "INVALID_FILE");
  }
  if (isVideo && file.size > LIMITS.maxVideoBytes) {
    throw new AppError(400, "El video no puede pesar más de 5 MB.", "VIDEO_TOO_LARGE");
  }
  if (isImage && file.size > MAX_IMAGE_BYTES) {
    throw new AppError(400, "La imagen no puede pesar más de 5 MB.", "IMAGE_TOO_LARGE");
  }
  if ((await countFiles(bucketName, folder)) >= LIMITS.maxFilesPerFolder) {
    throw new AppError(400, `Cada carpeta admite como máximo ${LIMITS.maxFilesPerFolder} imágenes o videos.`, "MAX_FILES");
  }

  let body: Uint8Array;
  let ext: string;
  let contentType: string;

  if (isImage) {
    try {
      body = await convertImageToWebp(new Uint8Array(await file.arrayBuffer()));
    } catch (err) {
      console.error("buckets.uploadFile(convert):", err);
      throw new AppError(400, "No se pudo procesar la imagen. Prueba con otro archivo.", "INVALID_FILE");
    }
    ext = "webp";
    contentType = "image/webp";
  } else {
    body = new Uint8Array(await file.arrayBuffer());
    ext = VIDEO_EXT[file.type];
    contentType = file.type;
  }

  for (let attempt = 0; attempt < MAX_UPLOAD_ATTEMPTS; attempt++) {
    const name = `${random11Digits()}.${ext}`;
    const path = `${at(folder)}/${name}`;

    const { error } = await supabaseAdmin.storage
      .from(bucketName)
      .upload(path, body, { contentType, upsert: false });

    if (!error) {
      const urls = await createSignedUrls(bucketName, [path]);
      return { name, path, kind: isImage ? "image" : "video", size: body.byteLength, url: urls.get(path) ?? null };
    }

    const exists =
      String((error as { statusCode?: string | number }).statusCode) === "409" ||
      /already exists|duplicate/i.test(error.message ?? "");
    if (!exists) {
      console.error("buckets.uploadFile(upload):", error);
      throw new AppError(500, "No se pudo subir el archivo.");
    }
  }
  throw new AppError(500, "No se pudo generar un nombre único para el archivo. Intenta de nuevo.");
}

/** DELETE: borra un archivo de una carpeta. */
export async function deleteFile(bucketName: string, rawFolder: string, fileName: string): Promise<void> {
  const folder = cleanFolderName(rawFolder);
  if (!fileName || fileName.includes("/") || fileName.startsWith(".") || !kindOf(fileName)) {
    throw new AppError(400, "El nombre del archivo no es válido.", "INVALID_FILE");
  }
  await assertFolderExists(bucketName, folder);

  const { error } = await supabaseAdmin.storage.from(bucketName).remove([`${at(folder)}/${fileName}`]);
  if (error) {
    console.error("buckets.deleteFile:", error);
    throw new AppError(500, "No se pudo eliminar el archivo.");
  }
}