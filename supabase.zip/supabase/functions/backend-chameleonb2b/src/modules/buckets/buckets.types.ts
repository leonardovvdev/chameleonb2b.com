/** Carpeta de primer nivel dentro del bucket del customer. */
export interface StorageFolder {
  name: string;
  /** true = carpeta del sistema (no se borra ni cuenta para el máximo de 5). */
  system: boolean;
  /** Archivos (imágenes/videos) que tiene directamente. */
  files: number;
  /** Subcarpetas ya existentes (solo las del sistema pueden tener). */
  subfolders: number;
}

export interface StorageFile {
  name: string;
  /** Ruta completa dentro del bucket (carpeta/archivo). */
  path: string;
  kind: "image" | "video";
  size: number | null;
  /** Enlace firmado y temporal (el bucket es privado). */
  url: string | null;
}

export interface StorageFolderContent {
  folder: string;
  subfolders: string[];
  files: StorageFile[];
}

export interface StorageLimits {
  maxFolders: number;
  maxFilesPerFolder: number;
  maxVideoBytes: number;
}