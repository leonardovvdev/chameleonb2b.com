export interface Category {
  ctgry_id: number;
  cust_id: number;
  ctgry_name: string;
  ctgry_name_img_link: string | null;
  ctgry_important: boolean;
}
