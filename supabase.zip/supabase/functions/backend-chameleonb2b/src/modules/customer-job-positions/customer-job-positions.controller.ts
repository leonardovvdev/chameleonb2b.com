import { AppError, json } from "../../shared/http.ts";
import {
  deleteJobPosition,
  getSessionCustId,
  insertJobPosition,
  listByCustomer,
  updateJobPosition,
} from "./customer-job-positions.service.ts";
import type { CustomerJobPositionInput } from "./customer-job-positions.types.ts";

const MAX_NAME_LENGTH = 200; // VARCHAR(200) en la tabla

/** Lee y valida ?id=123 de la URL. */
function parseId(req: Request): number {
  const raw = new URL(req.url).searchParams.get("id");
  const id = Number(raw);
  if (!raw || !Number.isSafeInteger(id) || id <= 0) {
    throw new AppError(400, "El id del cargo no es válido.", "INVALID_ID");
  }
  return id;
}

/** Lee y valida el body { name, description }. */
async function parseInput(req: Request): Promise<CustomerJobPositionInput> {
  const body = await req.json().catch(() => null);
  if (!body || typeof body !== "object") {
    throw new AppError(400, "El cuerpo de la petición no es válido.", "INVALID_BODY");
  }

  const { name, description } = body as Record<string, unknown>;

  const cleanName = typeof name === "string" ? name.trim() : "";
  if (!cleanName) {
    throw new AppError(400, "El nombre del cargo es obligatorio.", "NAME_REQUIRED");
  }
  if (cleanName.length > MAX_NAME_LENGTH) {
    throw new AppError(
      400,
      `El nombre no puede superar los ${MAX_NAME_LENGTH} caracteres.`,
      "NAME_TOO_LONG",
    );
  }

  if (description != null && typeof description !== "string") {
    throw new AppError(400, "La descripción no es válida.", "INVALID_DESCRIPTION");
  }
  const cleanDescription = typeof description === "string" ? description.trim() || null : null;

  return { name: cleanName, description: cleanDescription };
}

/** GET /customer-job-positions → { items } con los cargos del customer de la sesión. */
export async function listCustomerJobPositions(req: Request): Promise<Response> {
  const custId = await getSessionCustId(req);
  const items = await listByCustomer(custId);
  return json({ items });
}

/** POST /customer-job-positions → crea un cargo. */
export async function createCustomerJobPosition(req: Request): Promise<Response> {
  const custId = await getSessionCustId(req);
  const input = await parseInput(req);
  const created = await insertJobPosition(custId, input);
  return json(created, 201);
}

/** PATCH /customer-job-positions?id=123 → edita un cargo. */
export async function updateCustomerJobPosition(req: Request): Promise<Response> {
  const custId = await getSessionCustId(req);
  const id = parseId(req);
  const input = await parseInput(req);
  const updated = await updateJobPosition(id, custId, input);
  return json(updated);
}

/** DELETE /customer-job-positions?id=123 → elimina un cargo. */
export async function deleteCustomerJobPosition(req: Request): Promise<Response> {
  const custId = await getSessionCustId(req);
  const id = parseId(req);
  await deleteJobPosition(id, custId);
  return json({ id });
}
