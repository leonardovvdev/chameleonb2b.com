import { AppError, json } from "../../shared/http.ts";
import { getAccessContext } from "../auth/auth.services.ts";
import {
  createJobPosition,
  deleteJobPosition,
  listJobPositions,
  updateJobPosition,
} from "./customer-job-positions.service.ts";
import type { JobPositionInput } from "./customer-job-positions.types.ts";

const MAX_NAME_LENGTH = 200; // mismo límite que el input del frontend

/** Lee y valida ?id=123 de la URL. */
function parseId(req: Request): number {
  const raw = new URL(req.url).searchParams.get("id");
  const id = Number(raw);
  if (!raw || !Number.isSafeInteger(id) || id <= 0) {
    throw new AppError(400, "El id del cargo no es válido.", "INVALID_ID");
  }
  return id;
}

/** Lee el JSON { name, description } y lo valida. */
async function readInput(req: Request): Promise<JobPositionInput> {
  const body = await req.json().catch(() => null);
  if (!body || typeof body !== "object") {
    throw new AppError(400, "El cuerpo de la petición no es válido.", "INVALID_BODY");
  }

  const name = typeof body.name === "string" ? body.name.trim() : "";
  if (!name) throw new AppError(400, "El nombre del cargo es obligatorio.", "NAME_REQUIRED");
  if (name.length > MAX_NAME_LENGTH) {
    throw new AppError(
      400,
      `El nombre no puede superar los ${MAX_NAME_LENGTH} caracteres.`,
      "NAME_TOO_LONG",
    );
  }

  const description =
    typeof body.description === "string" ? body.description.trim() : "";

  return { name, description: description || null };
}

/** GET /customer-job-positions → { items: [{ id, name, description }] } */
export async function listJobPositionsHandler(req: Request): Promise<Response> {
  const { custId } = await getAccessContext(req);
  return json({ items: await listJobPositions(custId) });
}

/** POST /customer-job-positions (JSON) → el cargo creado */
export async function createJobPositionHandler(req: Request): Promise<Response> {
  const { custId } = await getAccessContext(req);
  const input = await readInput(req);
  return json(await createJobPosition(custId, input), 201);
}

/** PATCH /customer-job-positions?id=123 (JSON) → el cargo actualizado */
export async function updateJobPositionHandler(req: Request): Promise<Response> {
  const { custId } = await getAccessContext(req);
  const id = parseId(req);
  const input = await readInput(req);
  return json(await updateJobPosition(id, custId, input));
}

/** DELETE /customer-job-positions?id=123 → { id } */
export async function deleteJobPositionHandler(req: Request): Promise<Response> {
  const { custId } = await getAccessContext(req);
  const id = parseId(req);
  await deleteJobPosition(id, custId);
  return json({ id });
}