import { AppError } from "../../shared/http.ts";
import { supabaseAdmin } from "../../shared/supabase.ts";
import type {
  CustomerJobPosition,
  JobPositionInput,
  JobPositionItem,
} from "./customer-job-positions.types.ts";

const TABLE = "customer_job_positions";
const COLUMNS = "cust_jb_pstn_id, cust_id, cust_jb_pstn_name, cust_jb_pstn_description";

const toItem = (r: CustomerJobPosition): JobPositionItem => ({
  id: r.cust_jb_pstn_id,
  name: r.cust_jb_pstn_name,
  description: r.cust_jb_pstn_description,
});

/** Códigos de error de Postgres que se traducen a 409. */
const isUniqueViolation = (e: { code?: string }) => e.code === "23505";
const isForeignKeyViolation = (e: { code?: string }) => e.code === "23503";

/** Cargo que exista Y sea de este customer (el id llega del cliente). */
async function findOwned(id: number, custId: number): Promise<CustomerJobPosition> {
  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .select(COLUMNS)
    .eq("cust_jb_pstn_id", id)
    .eq("cust_id", custId)
    .maybeSingle();

  if (error) {
    console.error("customer-job-positions.findOwned:", error);
    throw new AppError(500, "No se pudo consultar el cargo.");
  }
  if (!data) throw new AppError(404, "El cargo no existe.", "NOT_FOUND");
  return data as CustomerJobPosition;
}

/** READ: cargos del customer ordenados por nombre. */
export async function listJobPositions(custId: number): Promise<JobPositionItem[]> {
  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .select(COLUMNS)
    .eq("cust_id", custId)
    .order("cust_jb_pstn_name");

  if (error) {
    console.error("customer-job-positions.list:", error);
    throw new AppError(500, "No se pudieron cargar los cargos.");
  }
  return ((data ?? []) as CustomerJobPosition[]).map(toItem);
}

/** CREATE */
export async function createJobPosition(
  custId: number,
  input: JobPositionInput,
): Promise<JobPositionItem> {
  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .insert({
      cust_id: custId,
      cust_jb_pstn_name: input.name,
      cust_jb_pstn_description: input.description,
    })
    .select(COLUMNS)
    .single();

  if (error || !data) {
    console.error("customer-job-positions.create:", error);
    if (error && isUniqueViolation(error)) {
      throw new AppError(409, "Ya existe un cargo con ese nombre.", "DUPLICATE_NAME");
    }
    throw new AppError(500, "No se pudo crear el cargo.");
  }
  return toItem(data as CustomerJobPosition);
}

/** UPDATE */
export async function updateJobPosition(
  id: number,
  custId: number,
  input: JobPositionInput,
): Promise<JobPositionItem> {
  await findOwned(id, custId);

  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .update({
      cust_jb_pstn_name: input.name,
      cust_jb_pstn_description: input.description,
    })
    .eq("cust_jb_pstn_id", id)
    .eq("cust_id", custId)
    .select(COLUMNS)
    .single();

  if (error || !data) {
    console.error("customer-job-positions.update:", error);
    if (error && isUniqueViolation(error)) {
      throw new AppError(409, "Ya existe un cargo con ese nombre.", "DUPLICATE_NAME");
    }
    throw new AppError(500, "No se pudo actualizar el cargo.");
  }
  return toItem(data as CustomerJobPosition);
}

/** DELETE */
export async function deleteJobPosition(id: number, custId: number): Promise<void> {
  await findOwned(id, custId);

  const { error } = await supabaseAdmin
    .from(TABLE)
    .delete()
    .eq("cust_jb_pstn_id", id)
    .eq("cust_id", custId);

  if (error) {
    console.error("customer-job-positions.delete:", error);
    if (isForeignKeyViolation(error)) {
      throw new AppError(
        409,
        "No se puede eliminar: hay personal asignado a este cargo.",
        "IN_USE",
      );
    }
    throw new AppError(500, "No se pudo eliminar el cargo.");
  }
}