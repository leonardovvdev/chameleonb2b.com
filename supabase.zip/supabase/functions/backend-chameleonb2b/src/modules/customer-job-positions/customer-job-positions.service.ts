import { AppError } from "../../shared/http.ts";
import { supabaseAdmin } from "../../shared/supabase.ts";
import { requireUser } from "../auth/auth.services.ts";
import { findByAuthId } from "../customers/customers.services.ts";
import type {
  CustomerJobPosition,
  CustomerJobPositionInput,
} from "./customer-job-positions.types.ts";

const TABLE = "customer_job_positions";
const UNIQUE_VIOLATION = "23505";
const FOREIGN_KEY_VIOLATION = "23503";

/** Columnas de la tabla con el nombre que usa el frontend. */
const COLUMNS =
  "id:cust_jb_pstn_id, name:cust_jb_pstn_name, description:cust_jb_pstn_description";

/** cust_id del usuario de la sesión (JWT). El cliente nunca lo manda en la petición. */
export async function getSessionCustId(req: Request): Promise<number> {
  const user = await requireUser(req);
  const customer = await findByAuthId(user.id);

  if (!customer) {
    throw new AppError(
      404,
      "Esta cuenta no está registrada. Crea tu cuenta con Google primero.",
      "CUSTOMER_NOT_FOUND",
    );
  }
  if (!customer.cust_is_active) {
    throw new AppError(403, "Tu cuenta está desactivada. Contacta a soporte.");
  }
  return customer.cust_id;
}

const duplicatedName = () =>
  new AppError(409, "Ya existe un cargo con ese nombre.", "DUPLICATED_NAME");

/** READ: cargos del customer, ordenados por nombre. */
export async function listByCustomer(custId: number): Promise<CustomerJobPosition[]> {
  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .select(COLUMNS)
    .eq("cust_id", custId)
    .order("cust_jb_pstn_name", { ascending: true });

  if (error) {
    console.error("customer-job-positions.listByCustomer:", error);
    throw new AppError(500, "No se pudo obtener la lista de cargos.");
  }
  return (data ?? []) as unknown as CustomerJobPosition[];
}

/** CREATE */
export async function insertJobPosition(
  custId: number,
  input: CustomerJobPositionInput,
): Promise<CustomerJobPosition> {
  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .insert({
      cust_id: custId,
      cust_jb_pstn_name: input.name,
      cust_jb_pstn_description: input.description,
    })
    .select(COLUMNS)
    .single();

  if (error?.code === UNIQUE_VIOLATION) throw duplicatedName();
  if (error || !data) {
    console.error("customer-job-positions.insertJobPosition:", error);
    throw new AppError(500, "No se pudo crear el cargo.");
  }
  return data as unknown as CustomerJobPosition;
}

/** UPDATE: solo si el cargo pertenece al customer. Si no existe → 404. */
export async function updateJobPosition(
  id: number,
  custId: number,
  input: CustomerJobPositionInput,
): Promise<CustomerJobPosition> {
  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .update({
      cust_jb_pstn_name: input.name,
      cust_jb_pstn_description: input.description,
    })
    .eq("cust_jb_pstn_id", id)
    .eq("cust_id", custId)
    .select(COLUMNS)
    .maybeSingle();

  if (error?.code === UNIQUE_VIOLATION) throw duplicatedName();
  if (error) {
    console.error("customer-job-positions.updateJobPosition:", error);
    throw new AppError(500, "No se pudo actualizar el cargo.");
  }
  if (!data) throw new AppError(404, "El cargo no existe.", "NOT_FOUND");
  return data as unknown as CustomerJobPosition;
}

/** DELETE: solo si el cargo pertenece al customer. Si no existe → 404. */
export async function deleteJobPosition(id: number, custId: number): Promise<void> {
  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .delete()
    .eq("cust_jb_pstn_id", id)
    .eq("cust_id", custId)
    .select("cust_jb_pstn_id")
    .maybeSingle();

  if (error?.code === FOREIGN_KEY_VIOLATION) {
    throw new AppError(409, "No se puede eliminar: el cargo está en uso.", "IN_USE");
  }
  if (error) {
    console.error("customer-job-positions.deleteJobPosition:", error);
    throw new AppError(500, "No se pudo eliminar el cargo.");
  }
  if (!data) throw new AppError(404, "El cargo no existe.", "NOT_FOUND");
}
