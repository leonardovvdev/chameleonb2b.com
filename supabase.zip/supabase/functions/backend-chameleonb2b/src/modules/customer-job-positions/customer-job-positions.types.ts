/** Fila tal como sale de la tabla customer_job_positions. */
export interface CustomerJobPosition {
  cust_jb_pstn_id: number;
  cust_id: number;
  cust_jb_pstn_name: string;
  cust_jb_pstn_description: string | null;
}

/** Datos editables que llegan del frontend. */
export interface JobPositionInput {
  name: string;
  description: string | null;
}

/** Cargo tal como lo consume el frontend. */
export interface JobPositionItem {
  id: number;
  name: string;
  description: string | null;
}