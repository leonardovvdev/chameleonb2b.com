/**
 * Cargo tal como se devuelve al frontend.
 * Viene de la tabla `customer_job_positions` (cust_jb_pstn_id, cust_jb_pstn_name,
 * cust_jb_pstn_description) renombrando las columnas con alias en el select.
 */
export interface CustomerJobPosition {
  id: number;
  name: string;
  description: string | null;
}

/** Datos que el frontend envía al crear o editar un cargo. */
export interface CustomerJobPositionInput {
  name: string;
  description: string | null;
}
