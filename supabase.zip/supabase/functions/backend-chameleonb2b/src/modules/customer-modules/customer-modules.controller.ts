import { AppError } from "../../shared/http.ts";
import {
  insertCustomerModules,
  listActiveModuleUrls,
  listModuleIdsForNewCustomer,
} from "./customer-modules.services.ts";

/** Asigna al customer nuevo los módulos que se muestran al crear la cuenta. */
export async function assignDefaultModules(custId: number): Promise<void> {
  const modIds = await listModuleIdsForNewCustomer();
  await insertCustomerModules(custId, modIds);
}

/** Ruta del primer módulo activo del customer (ej. "/habits"). Es el destino tras el login. */
export async function getFirstActiveRedirectUrl(custId: number): Promise<string> {
  const [first] = await listActiveModuleUrls(custId);

  if (!first) {
    throw new AppError(403, "Tu cuenta no tiene un módulo activo. Contacta a soporte.", "NO_ACTIVE_MODULE");
  }
  return first;
}