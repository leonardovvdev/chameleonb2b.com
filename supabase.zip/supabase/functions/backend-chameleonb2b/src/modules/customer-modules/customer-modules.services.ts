import { supabaseAdmin } from "../../shared/supabase.ts";
import { AppError } from "../../shared/http.ts";

interface ActiveModuleRow {
  mod_id: number;
  modules: { mod_direction_url: string | null } | { mod_direction_url: string | null }[] | null;
}

/** Ids de los módulos que se asignan al crear una cuenta. */
export async function listModuleIdsForNewCustomer(): Promise<number[]> {
  const { data, error } = await supabaseAdmin
    .from("modules")
    .select("mod_id")
    .eq("mod_is_active", true)
    .eq("cust_mod_is_active_show_login", true)
    .order("mod_id");

  if (error) {
    console.error("customer-modules.listModuleIdsForNewCustomer:", error);
    throw new AppError(500, "No se pudieron obtener los módulos.");
  }
  return (data ?? []).map((row) => row.mod_id as number);
}

/** Asigna módulos al customer (si ya los tiene, no se duplican). */
export async function insertCustomerModules(custId: number, modIds: number[]): Promise<void> {
  if (modIds.length === 0) return;

  const rows = modIds.map((mod_id) => ({ cust_id: custId, mod_id, cust_mod_is_active: true }));
  const { error } = await supabaseAdmin
    .from("customer_modules")
    .upsert(rows, { onConflict: "cust_id,mod_id", ignoreDuplicates: true });

  if (error) {
    console.error("customer-modules.insertCustomerModules:", error);
    throw new AppError(500, "No se pudieron asignar los módulos a tu cuenta.");
  }
}

/** URLs de los módulos activos del customer (activos para él y en general), por orden de mod_id. */
export async function listActiveModuleUrls(custId: number): Promise<string[]> {
  const { data, error } = await supabaseAdmin
    .from("customer_modules")
    .select("mod_id, modules!inner(mod_direction_url)")
    .eq("cust_id", custId)
    .eq("cust_mod_is_active", true)
    .eq("modules.mod_is_active", true)
    .order("mod_id");

  if (error) {
    console.error("customer-modules.listActiveModuleUrls:", error);
    throw new AppError(500, "No se pudieron obtener tus módulos.");
  }

  return ((data ?? []) as unknown as ActiveModuleRow[])
    .map((row) => (Array.isArray(row.modules) ? row.modules[0] : row.modules)?.mod_direction_url)
    .filter((url): url is string => typeof url === "string" && url.length > 0);
}