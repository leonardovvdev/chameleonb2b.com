import { AppError } from "../../shared/http.ts";
import { supabaseAdmin } from "../../shared/supabase.ts";

/** Primer módulo activo del customer → su mod_direction_url (ej. "/gestion-empresarial"). */
export async function getFirstActiveRedirectUrl(custId: number): Promise<string | null> {
  const { data: asignados, error: errAsignados } = await supabaseAdmin
    .from("customer_modules")
    .select("mod_id")
    .eq("cust_id", custId)
    .eq("cust_mod_is_active", true);

  if (errAsignados) {
    console.error("customer-modules.getFirstActiveRedirectUrl:", errAsignados);
    throw new AppError(500, "No se pudieron consultar tus módulos.");
  }

  const ids = (asignados ?? []).map((m) => m.mod_id as number);
  if (ids.length === 0) return null;

  const { data: modulo, error: errModulo } = await supabaseAdmin
    .from("modules")
    .select("mod_direction_url")
    .in("mod_id", ids)
    .eq("mod_is_active", true)
    .not("mod_direction_url", "is", null)
    .order("mod_id", { ascending: true })
    .limit(1)
    .maybeSingle();

  if (errModulo) {
    console.error("customer-modules.getFirstActiveRedirectUrl:", errModulo);
    throw new AppError(500, "No se pudieron consultar tus módulos.");
  }
  return (modulo?.mod_direction_url as string | undefined) ?? null;
}

/** Asigna al customer nuevo los módulos que se muestran al crear la cuenta. */
export async function assignDefaultModules(custId: number): Promise<void> {
  const { data: modulos, error } = await supabaseAdmin
    .from("modules")
    .select("mod_id")
    .eq("mod_is_active", true)
    .eq("cust_mod_is_active_show_login", true);

  if (error) {
    console.error("customer-modules.assignDefaultModules:", error);
    throw new AppError(500, "No se pudieron asignar los módulos.");
  }
  if (!modulos || modulos.length === 0) return;

  const { error: errInsert } = await supabaseAdmin.from("customer_modules").insert(
    modulos.map((m) => ({ cust_id: custId, mod_id: m.mod_id, cust_mod_is_active: true })),
  );
  if (errInsert) {
    console.error("customer-modules.assignDefaultModules:", errInsert);
    throw new AppError(500, "No se pudieron asignar los módulos.");
  }
}

/** Nombres de los módulos activos del customer (los que arman el sidebar). */
export async function listActiveModuleNames(custId: number): Promise<string[]> {
  const { data, error } = await supabaseAdmin
    .from("customer_modules")
    .select("modules(mod_name, mod_is_active)")
    .eq("cust_id", custId)
    .eq("cust_mod_is_active", true);

  if (error) {
    console.error("customer-modules.listActiveModuleNames:", error);
    throw new AppError(500, "No se pudieron consultar tus módulos.");
  }

  type Modulo = { mod_name: string | null; mod_is_active: boolean | null };
  const nombres: string[] = [];

  for (const fila of (data ?? []) as unknown as Array<{ modules: Modulo | Modulo[] | null }>) {
    const modulo = Array.isArray(fila.modules) ? fila.modules[0] : fila.modules;
    if (modulo && modulo.mod_is_active !== false && modulo.mod_name) nombres.push(modulo.mod_name);
  }
  return nombres;
}