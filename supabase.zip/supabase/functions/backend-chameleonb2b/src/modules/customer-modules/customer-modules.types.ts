export interface CustomerModule {
  cust_mod_id: number;
  cust_id: number;
  mod_id: number;
  cust_mod_is_active: boolean;
}
