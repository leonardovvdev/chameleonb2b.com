import { AppError, json } from "../../shared/http.ts";
import {
  deleteRole,
  getSessionCustId,
  insertRole,
  listByCustomer,
  updateRole,
} from "./customer-roles.services.ts";
import type { CustomerRoleInput } from "./customer-roles.types.ts";

const MAX_NAME_LENGTH = 200; // VARCHAR(200) en la tabla

/** Lee y valida ?id=123 de la URL. */
function parseId(req: Request): number {
  const raw = new URL(req.url).searchParams.get("id");
  const id = Number(raw);
  if (!raw || !Number.isSafeInteger(id) || id <= 0) {
    throw new AppError(400, "El id del rol no es válido.", "INVALID_ID");
  }
  return id;
}

/** Lee y valida el body { name, description }. */
async function parseInput(req: Request): Promise<CustomerRoleInput> {
  const body = await req.json().catch(() => null);
  if (!body || typeof body !== "object") {
    throw new AppError(400, "El cuerpo de la petición no es válido.", "INVALID_BODY");
  }

  const { name, description } = body as Record<string, unknown>;

  const cleanName = typeof name === "string" ? name.trim() : "";
  if (!cleanName) {
    throw new AppError(400, "El nombre del rol es obligatorio.", "NAME_REQUIRED");
  }
  if (cleanName.length > MAX_NAME_LENGTH) {
    throw new AppError(
      400,
      `El nombre no puede superar los ${MAX_NAME_LENGTH} caracteres.`,
      "NAME_TOO_LONG",
    );
  }

  if (description != null && typeof description !== "string") {
    throw new AppError(400, "La descripción no es válida.", "INVALID_DESCRIPTION");
  }
  const cleanDescription = typeof description === "string" ? description.trim() || null : null;

  return { name: cleanName, description: cleanDescription };
}

/** GET /customer-roles → { items } con los roles del customer de la sesión. */
export async function listCustomerRoles(req: Request): Promise<Response> {
  const custId = await getSessionCustId(req);
  const items = await listByCustomer(custId);
  return json({ items });
}

/** POST /customer-roles → crea un rol. */
export async function createCustomerRole(req: Request): Promise<Response> {
  const custId = await getSessionCustId(req);
  const input = await parseInput(req);
  const created = await insertRole(custId, input);
  return json(created, 201);
}

/** PATCH /customer-roles?id=123 → edita un rol. */
export async function updateCustomerRole(req: Request): Promise<Response> {
  const custId = await getSessionCustId(req);
  const id = parseId(req);
  const input = await parseInput(req);
  const updated = await updateRole(id, custId, input);
  return json(updated);
}

/** DELETE /customer-roles?id=123 → elimina un rol. */
export async function deleteCustomerRole(req: Request): Promise<Response> {
  const custId = await getSessionCustId(req);
  const id = parseId(req);
  await deleteRole(id, custId);
  return json({ id });
}
