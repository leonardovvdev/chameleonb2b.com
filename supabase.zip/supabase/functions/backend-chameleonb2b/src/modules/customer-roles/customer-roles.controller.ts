import { AppError, json } from "../../shared/http.ts";
import { getAccessContext } from "../auth/auth.services.ts";
import {
  createRole,
  deleteRole,
  listRoles,
  updateRole,
} from "./customer-roles.services.ts";
import type { RoleInput } from "./customer-roles.types.ts";

const MAX_NAME_LENGTH = 200; // mismo límite que el input del frontend

/** Lee y valida ?id=123 de la URL. */
function parseId(req: Request): number {
  const raw = new URL(req.url).searchParams.get("id");
  const id = Number(raw);
  if (!raw || !Number.isSafeInteger(id) || id <= 0) {
    throw new AppError(400, "El id del rol no es válido.", "INVALID_ID");
  }
  return id;
}

/** Lee el JSON { name, description } y lo valida. */
async function readInput(req: Request): Promise<RoleInput> {
  const body = await req.json().catch(() => null);
  if (!body || typeof body !== "object") {
    throw new AppError(400, "El cuerpo de la petición no es válido.", "INVALID_BODY");
  }

  const name = typeof body.name === "string" ? body.name.trim() : "";
  if (!name) throw new AppError(400, "El nombre del rol es obligatorio.", "NAME_REQUIRED");
  if (name.length > MAX_NAME_LENGTH) {
    throw new AppError(
      400,
      `El nombre no puede superar los ${MAX_NAME_LENGTH} caracteres.`,
      "NAME_TOO_LONG",
    );
  }

  const description =
    typeof body.description === "string" ? body.description.trim() : "";

  return { name, description: description || null };
}

/** GET /customer-roles → { items: [{ id, name, description }] } */
export async function listRolesHandler(req: Request): Promise<Response> {
  const { custId } = await getAccessContext(req);
  return json({ items: await listRoles(custId) });
}

/** POST /customer-roles (JSON) → el rol creado */
export async function createRoleHandler(req: Request): Promise<Response> {
  const { custId } = await getAccessContext(req);
  const input = await readInput(req);
  return json(await createRole(custId, input), 201);
}

/** PATCH /customer-roles?id=123 (JSON) → el rol actualizado */
export async function updateRoleHandler(req: Request): Promise<Response> {
  const { custId } = await getAccessContext(req);
  const id = parseId(req);
  const input = await readInput(req);
  return json(await updateRole(id, custId, input));
}

/** DELETE /customer-roles?id=123 → { id } */
export async function deleteRoleHandler(req: Request): Promise<Response> {
  const { custId } = await getAccessContext(req);
  const id = parseId(req);
  await deleteRole(id, custId);
  return json({ id });
}