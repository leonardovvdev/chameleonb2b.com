import { AppError } from "../../shared/http.ts";
import { supabaseAdmin } from "../../shared/supabase.ts";
import type { CustomerRole, RoleInput, RoleItem } from "./customer-roles.types.ts";

const TABLE = "customer_roles";
const COLUMNS = "cust_role_id, cust_id, cust_role_name, cust_role_description";

const toItem = (r: CustomerRole): RoleItem => ({
  id: r.cust_role_id,
  name: r.cust_role_name,
  description: r.cust_role_description,
});

/** Códigos de error de Postgres que se traducen a 409. */
const isUniqueViolation = (e: { code?: string }) => e.code === "23505";
const isForeignKeyViolation = (e: { code?: string }) => e.code === "23503";

/** Rol que exista Y sea de este customer (el id llega del cliente). */
async function findOwned(id: number, custId: number): Promise<CustomerRole> {
  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .select(COLUMNS)
    .eq("cust_role_id", id)
    .eq("cust_id", custId)
    .maybeSingle();

  if (error) {
    console.error("customer-roles.findOwned:", error);
    throw new AppError(500, "No se pudo consultar el rol.");
  }
  if (!data) throw new AppError(404, "El rol no existe.", "NOT_FOUND");
  return data as CustomerRole;
}

/** READ: roles del customer ordenados por nombre. */
export async function listRoles(custId: number): Promise<RoleItem[]> {
  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .select(COLUMNS)
    .eq("cust_id", custId)
    .order("cust_role_name");

  if (error) {
    console.error("customer-roles.list:", error);
    throw new AppError(500, "No se pudieron cargar los roles.");
  }
  return ((data ?? []) as CustomerRole[]).map(toItem);
}

/** CREATE */
export async function createRole(custId: number, input: RoleInput): Promise<RoleItem> {
  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .insert({
      cust_id: custId,
      cust_role_name: input.name,
      cust_role_description: input.description,
    })
    .select(COLUMNS)
    .single();

  if (error || !data) {
    console.error("customer-roles.create:", error);
    if (error && isUniqueViolation(error)) {
      throw new AppError(409, "Ya existe un rol con ese nombre.", "DUPLICATE_NAME");
    }
    throw new AppError(500, "No se pudo crear el rol.");
  }
  return toItem(data as CustomerRole);
}

/** UPDATE */
export async function updateRole(
  id: number,
  custId: number,
  input: RoleInput,
): Promise<RoleItem> {
  await findOwned(id, custId);

  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .update({
      cust_role_name: input.name,
      cust_role_description: input.description,
    })
    .eq("cust_role_id", id)
    .eq("cust_id", custId)
    .select(COLUMNS)
    .single();

  if (error || !data) {
    console.error("customer-roles.update:", error);
    if (error && isUniqueViolation(error)) {
      throw new AppError(409, "Ya existe un rol con ese nombre.", "DUPLICATE_NAME");
    }
    throw new AppError(500, "No se pudo actualizar el rol.");
  }
  return toItem(data as CustomerRole);
}

/** DELETE */
export async function deleteRole(id: number, custId: number): Promise<void> {
  await findOwned(id, custId);

  const { error } = await supabaseAdmin
    .from(TABLE)
    .delete()
    .eq("cust_role_id", id)
    .eq("cust_id", custId);

  if (error) {
    console.error("customer-roles.delete:", error);
    if (isForeignKeyViolation(error)) {
      throw new AppError(
        409,
        "No se puede eliminar: hay personal asignado a este rol.",
        "IN_USE",
      );
    }
    throw new AppError(500, "No se pudo eliminar el rol.");
  }
}