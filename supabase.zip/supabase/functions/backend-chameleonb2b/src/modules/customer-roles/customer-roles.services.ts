import { AppError } from "../../shared/http.ts";
import { supabaseAdmin } from "../../shared/supabase.ts";
import { requireUser } from "../auth/auth.services.ts";
import { findByAuthId } from "../customers/customers.services.ts";
import type { CustomerRole, CustomerRoleInput } from "./customer-roles.types.ts";

const TABLE = "customer_roles";
const UNIQUE_VIOLATION = "23505";
const FOREIGN_KEY_VIOLATION = "23503";

/** Columnas de la tabla con el nombre que usa el frontend. */
const COLUMNS = "id:cust_role_id, name:cust_role_name, description:cust_role_description";

/** cust_id del usuario de la sesión (JWT). El cliente nunca lo manda en la petición. */
export async function getSessionCustId(req: Request): Promise<number> {
  const user = await requireUser(req);
  const customer = await findByAuthId(user.id);

  if (!customer) {
    throw new AppError(
      404,
      "Esta cuenta no está registrada. Crea tu cuenta con Google primero.",
      "CUSTOMER_NOT_FOUND",
    );
  }
  if (!customer.cust_is_active) {
    throw new AppError(403, "Tu cuenta está desactivada. Contacta a soporte.");
  }
  return customer.cust_id;
}

const duplicatedName = () =>
  new AppError(409, "Ya existe un rol con ese nombre.", "DUPLICATED_NAME");

/** READ: roles del customer, ordenados por nombre. */
export async function listByCustomer(custId: number): Promise<CustomerRole[]> {
  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .select(COLUMNS)
    .eq("cust_id", custId)
    .order("cust_role_name", { ascending: true });

  if (error) {
    console.error("customer-roles.listByCustomer:", error);
    throw new AppError(500, "No se pudo obtener la lista de roles.");
  }
  return (data ?? []) as unknown as CustomerRole[];
}

/** CREATE */
export async function insertRole(custId: number, input: CustomerRoleInput): Promise<CustomerRole> {
  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .insert({
      cust_id: custId,
      cust_role_name: input.name,
      cust_role_description: input.description,
    })
    .select(COLUMNS)
    .single();

  if (error?.code === UNIQUE_VIOLATION) throw duplicatedName();
  if (error || !data) {
    console.error("customer-roles.insertRole:", error);
    throw new AppError(500, "No se pudo crear el rol.");
  }
  return data as unknown as CustomerRole;
}

/** UPDATE: solo si el rol pertenece al customer. Si no existe → 404. */
export async function updateRole(
  id: number,
  custId: number,
  input: CustomerRoleInput,
): Promise<CustomerRole> {
  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .update({
      cust_role_name: input.name,
      cust_role_description: input.description,
    })
    .eq("cust_role_id", id)
    .eq("cust_id", custId)
    .select(COLUMNS)
    .maybeSingle();

  if (error?.code === UNIQUE_VIOLATION) throw duplicatedName();
  if (error) {
    console.error("customer-roles.updateRole:", error);
    throw new AppError(500, "No se pudo actualizar el rol.");
  }
  if (!data) throw new AppError(404, "El rol no existe.", "NOT_FOUND");
  return data as unknown as CustomerRole;
}

/** DELETE: solo si el rol pertenece al customer. Si no existe → 404. */
export async function deleteRole(id: number, custId: number): Promise<void> {
  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .delete()
    .eq("cust_role_id", id)
    .eq("cust_id", custId)
    .select("cust_role_id")
    .maybeSingle();

  if (error?.code === FOREIGN_KEY_VIOLATION) {
    throw new AppError(409, "No se puede eliminar: el rol está en uso.", "IN_USE");
  }
  if (error) {
    console.error("customer-roles.deleteRole:", error);
    throw new AppError(500, "No se pudo eliminar el rol.");
  }
  if (!data) throw new AppError(404, "El rol no existe.", "NOT_FOUND");
}
