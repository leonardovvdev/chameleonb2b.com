/** Fila tal como sale de la tabla customer_roles. */
export interface CustomerRole {
  cust_role_id: number;
  cust_id: number;
  cust_role_name: string;
  cust_role_description: string | null;
}

/** Datos editables que llegan del frontend. */
export interface RoleInput {
  name: string;
  description: string | null;
}

/** Rol tal como lo consume el frontend. */
export interface RoleItem {
  id: number;
  name: string;
  description: string | null;
}