/**
 * Rol tal como se devuelve al frontend.
 * Viene de la tabla `customer_roles` (cust_role_id, cust_role_name,
 * cust_role_description) renombrando las columnas con alias en el select.
 */
export interface CustomerRole {
  id: number;
  name: string;
  description: string | null;
}

/** Datos que el frontend envía al crear o editar un rol. */
export interface CustomerRoleInput {
  name: string;
  description: string | null;
}
