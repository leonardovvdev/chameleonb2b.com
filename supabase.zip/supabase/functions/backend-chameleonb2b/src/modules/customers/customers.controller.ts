import { AppError, json } from "../../shared/http.ts";
import { requireUser } from "../auth/auth.services.ts";
import { getCustomerImageUrl } from "../buckets/buckets.services.ts";
import { findByAuthId } from "./customers.services.ts";

/** GET /customers/me → datos del customer de la sesión (+ foto firmada). */
export async function getMeHandler(req: Request): Promise<Response> {
  const user = await requireUser(req);
  const customer = await findByAuthId(user.id);
  if (!customer) {
    throw new AppError(404, "Esta cuenta no está registrada.", "CUSTOMER_NOT_FOUND");
  }

  const imgUrl = await getCustomerImageUrl(
    String(customer.cust_name_bucket),
    customer.cust_name_img_link,
  );

  return json({
    cust_id: customer.cust_id,
    cust_name: customer.cust_name,
    cust_lastname: customer.cust_lastname,
    cust_name_bucket: customer.cust_name_bucket,
    cust_name_img_link: customer.cust_name_img_link,
    cust_name_img_url: imgUrl,
  });
}