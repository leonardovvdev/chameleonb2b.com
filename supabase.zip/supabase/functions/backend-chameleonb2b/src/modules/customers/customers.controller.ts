import type { User } from "npm:@supabase/supabase-js@2";
import { AppError, json } from "../../shared/http.ts";
import { random11Digits } from "../../shared/random.ts";
import {
  createBucket,
  createDefaultFolders,
  createSignedUrl,
  deleteBucket,
} from "../buckets/buckets.controller.ts";
import { requireUser } from "../auth/auth.services.ts";
import {
  assignDefaultModules,
  getFirstActiveRedirectUrl,
} from "../customer-modules/customer-modules.controller.ts";
import { deleteCustomer, findByAuthId, insertCustomer } from "./customers.services.ts";
import type { Customer, RegisterResult } from "./customers.types.ts";

const MAX_ATTEMPTS = 5;

/** Nombre y apellido que Google deja en los metadatos del usuario. */
function namesFromGoogle(user: User): { name: string; lastname: string } {
  const meta = user.user_metadata ?? {};
  const full = String(meta.full_name ?? meta.name ?? "").trim();
  const words = full ? full.split(/\s+/) : [];

  const name =
    String(meta.given_name ?? "").trim() || words[0] || user.email?.split("@")[0] || "Cliente";
  const lastname = String(meta.family_name ?? "").trim() || words.slice(1).join(" ");

  return { name: name.slice(0, 100), lastname: lastname.slice(0, 100) };
}

/** El customer ya existía: no se crea nada, solo se devuelve su destino. */
async function existingResult(customer: Customer): Promise<RegisterResult> {
  if (!customer.cust_is_active) {
    throw new AppError(403, "Tu cuenta está desactivada. Contacta a soporte.");
  }
  const redirectUrl = await getFirstActiveRedirectUrl(customer.cust_id);
  return { created: false, customer, redirectUrl };
}

/**
 * Crea la cuenta: customer + bucket con sus carpetas + módulos por defecto.
 * Se puede repetir sin duplicar. Si algo falla, deshace lo que creó.
 */
export async function createCustomerInSystem(user: User): Promise<RegisterResult> {
  const existing = await findByAuthId(user.id);
  if (existing) return await existingResult(existing);

  const { name, lastname } = namesFromGoogle(user);

  // 1) Customer, con números al azar únicos (se reintenta si se repite alguno).
  let customer: Customer | null = null;
  for (let attempt = 0; attempt < MAX_ATTEMPTS && !customer; attempt++) {
    customer = await insertCustomer({
      cust_name: name,
      cust_lastname: lastname,
      cust_name_bucket: random11Digits(),
      cust_code_system: random11Digits(),
      cust_auth_id: user.id,
    });

    if (!customer) {
      // Choque de UNIQUE: puede que otra petición ya lo haya creado.
      const concurrent = await findByAuthId(user.id);
      if (concurrent) return await existingResult(concurrent);
    }
  }
  if (!customer) throw new AppError(500, "No se pudo crear tu cuenta. Intenta de nuevo.");

  // 2) Bucket, carpetas y módulos. Si falla algo, rollback.
  const bucketName = String(customer.cust_name_bucket);
  try {
    await createBucket(bucketName);
    await createDefaultFolders(bucketName);
    await assignDefaultModules(customer.cust_id);

    const redirectUrl = await getFirstActiveRedirectUrl(customer.cust_id);
    return { created: true, customer, redirectUrl };
  } catch (err) {
    await deleteBucket(bucketName);
    await deleteCustomer(customer.cust_id);
    throw err;
  }
}

/**
 * GET /customers/me — datos del customer de la sesión actual.
 * La imagen se guarda en el bucket privado como
 *   {cust_name_bucket}/imagen_customer/{cust_name_img_link}
 * por eso se devuelve también `cust_name_img_url`, un enlace firmado temporal.
 */
export async function getMyCustomer(req: Request): Promise<Response> {
  const user = await requireUser(req);
  const customer = await findByAuthId(user.id);

  if (!customer) {
    throw new AppError(
      404,
      "Esta cuenta no está registrada. Crea tu cuenta con Google primero.",
      "CUSTOMER_NOT_FOUND",
    );
  }
  if (!customer.cust_is_active) {
    throw new AppError(403, "Tu cuenta está desactivada. Contacta a soporte.");
  }

  const imgUrl = customer.cust_name_img_link
    ? await createSignedUrl(
        String(customer.cust_name_bucket),
        `imagen_customer/${customer.cust_name_img_link}`,
      )
    : null;

  return json({
    cust_id: customer.cust_id,
    cust_name: customer.cust_name,
    cust_lastname: customer.cust_lastname,
    cust_name_bucket: customer.cust_name_bucket,
    cust_name_img_link: customer.cust_name_img_link,
    cust_name_img_url: imgUrl,
  });
}