import type { User } from "npm:@supabase/supabase-js@2";
import { AppError } from "../../shared/http.ts";
import { random11Digits } from "../../shared/random.ts";
import { supabaseAdmin } from "../../shared/supabase.ts";
import { createBucket, createDefaultFolders, deleteBucket } from "../buckets/buckets.services.ts";
import {
  assignDefaultModules,
  getFirstActiveRedirectUrl,
} from "../customer-modules/customer-modules.services.ts";
import type { Customer, RegisterResult } from "./customers.types.ts";

/* ───────────────────────── Datos ───────────────────────── */

/** Customer dueño de la sesión (cust_auth_id = id del usuario de Supabase Auth). */
export async function findByAuthId(authId: string): Promise<Customer | null> {
  const { data, error } = await supabaseAdmin
    .from("customers")
    .select("*")
    .eq("cust_auth_id", authId)
    .maybeSingle();

  if (error) {
    console.error("customers.findByAuthId:", error);
    throw new AppError(500, "No se pudo consultar tu cuenta.");
  }
  return data as Customer | null;
}

export async function insertCustomer(data: {
  cust_name: string;
  cust_lastname: string;
  cust_auth_id: string;
  cust_name_bucket: number;
  cust_code_system: number;
}): Promise<Customer> {
  const { data: row, error } = await supabaseAdmin
    .from("customers")
    .insert({ ...data, cust_is_active: true })
    .select("*")
    .single();

  if (error) {
    console.error("customers.insertCustomer:", error);
    // 23505 = el customer ya existe (doble clic / dos pestañas)
    if (error.code === "23505") throw new AppError(409, "La cuenta ya existe.", "CUSTOMER_EXISTS");
    throw new AppError(500, "No se pudo crear tu cuenta.");
  }
  return row as Customer;
}

export async function deleteCustomer(custId: number): Promise<void> {
  await supabaseAdmin.from("customers").delete().eq("cust_id", custId).then(() => {}, () => {});
}

/* ───────────────────────── Creación del customer ───────────────────────── */

/** Nombre y apellido desde los datos que entrega Google. */
function namesFromGoogle(user: User): { name: string; lastname: string } {
  const meta = (user.user_metadata ?? {}) as Record<string, unknown>;
  const str = (v: unknown) => (typeof v === "string" ? v.trim() : "");

  let name = str(meta.given_name);
  let lastname = str(meta.family_name);

  if (!name) {
    const parts = (str(meta.full_name) || str(meta.name)).split(/\s+/).filter(Boolean);
    name = parts[0] ?? "";
    lastname = lastname || parts.slice(1).join(" ");
  }
  if (!name) name = (user.email ?? "Usuario").split("@")[0];

  return { name, lastname };
}

/** Devuelve el customer ya existente con su destino (sin crear nada). */
async function existingResult(customer: Customer): Promise<RegisterResult> {
  return {
    created: false,
    customer,
    redirectUrl: await getFirstActiveRedirectUrl(customer.cust_id),
  };
}

/**
 * Crea customer + bucket privado + carpetas + módulos por defecto.
 * Si ya existe, no duplica: devuelve el existente (created: false).
 * Si algo falla a mitad, deshace lo creado (rollback).
 */
export async function createCustomerInSystem(user: User): Promise<RegisterResult> {
  const existing = await findByAuthId(user.id);
  if (existing) {
    if (!existing.cust_is_active) {
      throw new AppError(403, "Tu cuenta está desactivada. Contacta a soporte.");
    }
    return await existingResult(existing);
  }

  const { name, lastname } = namesFromGoogle(user);
  const bucketNumber = random11Digits();
  const bucketName = String(bucketNumber);

  await createBucket(bucketName);

  let customer: Customer | null = null;
  try {
    await createDefaultFolders(bucketName);
    customer = await insertCustomer({
      cust_name: name,
      cust_lastname: lastname,
      cust_auth_id: user.id,
      cust_name_bucket: bucketNumber,
      cust_code_system: random11Digits(),
    });
    await assignDefaultModules(customer.cust_id);
  } catch (err) {
    if (customer) await deleteCustomer(customer.cust_id);
    await deleteBucket(bucketName);

    // Otra petición lo creó justo antes: se devuelve ese en vez de fallar.
    if (err instanceof AppError && err.code === "CUSTOMER_EXISTS") {
      const creado = await findByAuthId(user.id);
      if (creado) return await existingResult(creado);
    }
    throw err;
  }

  return {
    created: true,
    customer,
    redirectUrl: await getFirstActiveRedirectUrl(customer.cust_id),
  };
}