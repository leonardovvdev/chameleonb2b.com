import { supabaseAdmin } from "../../shared/supabase.ts";
import { AppError } from "../../shared/http.ts";
import type { Customer, NewCustomer } from "./customers.types.ts";

const UNIQUE_VIOLATION = "23505";

/** Customer ligado a un usuario de Supabase Auth, o null si no existe. */
export async function findByAuthId(authId: string): Promise<Customer | null> {
  const { data, error } = await supabaseAdmin
    .from("customers")
    .select("*")
    .eq("cust_auth_id", authId)
    .maybeSingle();

  if (error) {
    console.error("customers.findByAuthId:", error);
    throw new AppError(500, "No se pudo consultar tu cuenta.");
  }
  return (data as Customer | null) ?? null;
}

/** Inserta el customer. Devuelve null si choca un UNIQUE (para reintentar con otros números). */
export async function insertCustomer(newCustomer: NewCustomer): Promise<Customer | null> {
  const { data, error } = await supabaseAdmin
    .from("customers")
    .insert(newCustomer)
    .select()
    .single();

  if (error?.code === UNIQUE_VIOLATION) return null;
  if (error || !data) {
    console.error("customers.insertCustomer:", error);
    throw new AppError(500, "No se pudo crear tu cuenta.");
  }
  return data as Customer;
}

/** Borra el customer (rollback). Nunca lanza error. */
export async function deleteCustomer(custId: number): Promise<void> {
  const { error } = await supabaseAdmin.from("customers").delete().eq("cust_id", custId);
  if (error) console.error("customers.deleteCustomer:", error);
}

/** Customer por su id, o null si no existe. */
export async function findByCustId(custId: number): Promise<Customer | null> {
  const { data, error } = await supabaseAdmin
    .from("customers")
    .select("*")
    .eq("cust_id", custId)
    .maybeSingle();

  if (error) {
    console.error("customers.findByCustId:", error);
    throw new AppError(500, "No se pudo consultar la cuenta.");
  }
  return (data as Customer | null) ?? null;
}