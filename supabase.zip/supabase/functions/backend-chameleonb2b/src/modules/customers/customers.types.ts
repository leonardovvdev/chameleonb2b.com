/** Fila de la tabla `customers`. */
export interface Customer {
  cust_id: number;
  cust_name: string;
  cust_lastname: string;
  cust_name_bucket: number;
  cust_name_img_link: string | null;
  cust_auth_id: string | null;
  cust_code_system: number;
  cust_is_active: boolean;
  cust_creation_date: string;
  cust_updated_date: string;
}

/** Datos que se envían al insertar (el resto lo llena la base de datos). */
export interface NewCustomer {
  cust_name: string;
  cust_lastname: string;
  cust_name_bucket: number;
  cust_code_system: number;
  cust_auth_id: string;
}

/** Resultado de registrar / entrar: si se creó, el customer y a dónde ir. */
export interface RegisterResult {
  created: boolean;
  customer: Customer;
  redirectUrl: string;
}