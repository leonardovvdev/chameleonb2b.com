import { AppError, json } from "../../shared/http.ts";
import { supabaseAdmin } from "../../shared/supabase.ts";
import { getAccessContext } from "../auth/auth.services.ts";

/** GET /fotochecks/default → { fotocheck: Fotocheck | null } */
export async function getDefaultFotocheckHandler(req: Request): Promise<Response> {
  const { custId } = await getAccessContext(req);

  const { data, error } = await supabaseAdmin
    .from("fotochecks")
    .select("*")
    .eq("cust_id", custId)
    .eq("is_default", true)
    .eq("fotocheck_active", true)
    .maybeSingle();

  if (error) {
    console.error("fotochecks.default:", error);
    throw new AppError(500, "No se pudo cargar el fotocheck.");
  }
  return json({ fotocheck: data ?? null });
}