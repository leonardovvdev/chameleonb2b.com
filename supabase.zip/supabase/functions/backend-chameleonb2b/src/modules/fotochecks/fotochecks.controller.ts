import { json } from "../../shared/http.ts";
import { getAccessContext } from "../staffs/staff.services.ts";
import { getDefaultFotocheckByCust } from "./fotochecks.services.ts";

/**
 * GET /fotochecks/default → { fotocheck }  (fotocheck = null si el customer no tiene predeterminado).
 * Va envuelto en un objeto porque el frontend (callBackend) rechaza una respuesta `null` pelada.
 */
export async function getDefaultFotocheck(req: Request): Promise<Response> {
  const { custId, bucketName } = await getAccessContext(req);
  return json({ fotocheck: await getDefaultFotocheckByCust(custId, bucketName) });
}