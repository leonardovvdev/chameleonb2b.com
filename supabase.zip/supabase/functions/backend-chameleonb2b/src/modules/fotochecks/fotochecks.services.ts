import { AppError } from "../../shared/http.ts";
import { supabaseAdmin } from "../../shared/supabase.ts";
import { createSignedUrls } from "../buckets/buckets.controller.ts";
import type {
  FotocheckConfigData,
  FotocheckItem,
  FotocheckRow,
} from "./fotochecks.types.ts";

const TABLE = "fotochecks";
const COLUMNS =
  "fotocheck_id, fotocheck_name, fotocheck_description, fotocheck_config, fotocheck_config_back, " +
  "fotocheck_preview, fotocheck_preview_back, fotocheck_active, is_default, cust_id, created_at, updated_at";

/**
 * Agrega `url` firmada a cada elemento de tipo imagen (bucket privado del customer).
 * Si el elemento no trae `path`, se deja igual.
 */
async function signConfigImages(
  bucketName: string,
  config: FotocheckConfigData | null,
): Promise<FotocheckConfigData | null> {
  if (!config || !Array.isArray(config.elements)) return config;

  const paths = config.elements
    .filter((el) => el.type === "image" && typeof el.path === "string" && el.path !== "")
    .map((el) => el.path as string);

  const urls = await createSignedUrls(bucketName, [...new Set(paths)]);

  return {
    ...config,
    elements: config.elements.map((el) =>
      el.type === "image" && typeof el.path === "string" && urls.has(el.path)
        ? { ...el, url: urls.get(el.path)! }
        : el
    ),
  };
}

/** Fotocheck con is_default = true del customer, con enlaces firmados. null si no hay. */
export async function getDefaultFotocheckByCust(
  custId: number,
  bucketName: string,
): Promise<FotocheckItem | null> {
  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .select(COLUMNS)
    .eq("cust_id", custId)
    .eq("is_default", true)
    .limit(1)
    .maybeSingle();

  if (error) {
    console.error("fotochecks.getDefaultFotocheckByCust:", error);
    throw new AppError(500, "No se pudo consultar el fotocheck.");
  }
  if (!data) return null;

  const row = data as FotocheckRow;
  return {
    ...row,
    fotocheck_config: (await signConfigImages(bucketName, row.fotocheck_config))!,
    fotocheck_config_back: await signConfigImages(bucketName, row.fotocheck_config_back),
  };
}