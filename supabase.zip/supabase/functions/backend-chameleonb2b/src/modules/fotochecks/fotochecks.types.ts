export interface Fotocheck {
  fotocheck_id: number;
  fotocheck_name: string;
  fotocheck_description: string | null;
  fotocheck_config: Record<string, unknown>;
  fotocheck_config_back: Record<string, unknown>;
  fotocheck_preview: string | null;
  fotocheck_preview_back: string | null;
  fotocheck_active: boolean;
  is_default: boolean;
  cust_id: number;
  created_at: string;
  updated_at: string;
}
