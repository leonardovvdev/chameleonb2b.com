/** Fila de la tabla `fotochecks` (los nombres de columnas deben coincidir con tu BD). */
export interface FotocheckRow {
  fotocheck_id: number;
  fotocheck_name: string;
  fotocheck_description: string | null;
  fotocheck_config: FotocheckConfigData;
  fotocheck_config_back: FotocheckConfigData | null;
  fotocheck_preview: string | null;
  fotocheck_preview_back: string | null;
  fotocheck_active: boolean;
  is_default: boolean;
  cust_id: number;
  created_at: string;
  updated_at: string;
}

/** Elemento del diseño. Si es imagen, el backend agrega `url` firmada. */
export interface FotocheckElementData {
  type: string;
  bucket?: string | null;
  path?: string | null;
  url?: string | null;
  [key: string]: unknown;
}

export interface FotocheckConfigData {
  elements?: FotocheckElementData[];
  [key: string]: unknown;
}

/** Fotocheck tal como se devuelve al frontend. */
export type FotocheckItem = FotocheckRow;