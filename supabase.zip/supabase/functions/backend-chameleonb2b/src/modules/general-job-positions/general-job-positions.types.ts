export interface GeneralJobPosition {
  gnral_jb_pstn_id: number;
  gnral_jb_pstn_name: string;
  gnral_jb_pstn_description: string | null;
}
