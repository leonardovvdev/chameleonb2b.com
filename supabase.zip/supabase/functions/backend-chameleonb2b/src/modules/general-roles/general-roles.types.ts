export interface GeneralRole {
  gnral_role_id: number;
  gnral_role_name: string;
  gnral_role_desc: string | null;
  gnral_role_is_active_cust: boolean;
  gnral_role_is_active: boolean;
  gnral_role_created_at: string;
}
