/** Fila de la tabla `logos`. `logo_link_img` es solo el nombre del archivo (ej. "48213749201.webp"). */
export interface LogoRow {
  logo_id: number;
  cust_id: number;
  logo_name: string;
  logo_description: string | null;
  logo_link_img: string;
}

/** Lo que recibe el frontend: la fila + el enlace firmado de la imagen (el bucket es privado). */
export interface LogoItem extends LogoRow {
  img_url: string | null;
}

export interface LogoInput {
  name: string;
  description: string | null;
}