import { AppError, json } from "../../shared/http.ts";
import { getAccessContext } from "../auth/auth.services.ts";
import { createLogo, deleteLogo, listLogos, MAX_IMAGE_BYTES, updateLogo } from "./logos.services.ts";
import type { LogoInput } from "./logos.types.ts";

const MAX_NAME_LENGTH = 200; // VARCHAR(200) en la tabla


/** Lee y valida ?id=123 de la URL. */
function parseId(req: Request): number {
  const raw = new URL(req.url).searchParams.get("id");
  const id = Number(raw);
  if (!raw || !Number.isSafeInteger(id) || id <= 0) {
    throw new AppError(400, "El id del logo no es válido.", "INVALID_ID");
  }
  return id;
}

/** Lee el multipart: name, description y file (opcional aquí; create lo exige). */
async function readForm(req: Request): Promise<{ input: LogoInput; file: File | null }> {
  const declared = Number(req.headers.get("content-length") ?? 0);
  if (declared > MAX_IMAGE_BYTES + 1024 * 100) {
    throw new AppError(400, "La imagen no puede pesar más de 5 MB.", "IMAGE_TOO_LARGE");
  }

  const form = await req.formData().catch(() => null);
  if (!form) throw new AppError(400, "El cuerpo de la petición no es válido.", "INVALID_BODY");

  const name = String(form.get("name") ?? "").trim();
  if (!name) throw new AppError(400, "El nombre del logo es obligatorio.", "NAME_REQUIRED");
  if (name.length > MAX_NAME_LENGTH) {
    throw new AppError(400, `El nombre no puede superar los ${MAX_NAME_LENGTH} caracteres.`, "NAME_TOO_LONG");
  }

  const description = String(form.get("description") ?? "").trim();
  const rawFile = form.get("file");
  const file = rawFile instanceof File && rawFile.size > 0 ? rawFile : null;

  return { input: { name, description: description || null }, file };
}

/** GET /logos → { items } */
export async function listLogosHandler(req: Request): Promise<Response> {
  const { custId, bucketName } = await getAccessContext(req);
  return json({ items: await listLogos(custId, bucketName) });
}

/** POST /logos (multipart: name, description, file) → el logo creado */
export async function createLogoHandler(req: Request): Promise<Response> {
  const { custId, bucketName } = await getAccessContext(req);
  const { input, file } = await readForm(req);

  if (!file) {
    throw new AppError(400, "Debes seleccionar una imagen para el logo.", "FILE_REQUIRED");
  }
  return json(await createLogo(custId, bucketName, input, file), 201);
}

/** PATCH /logos?id=123 (multipart: name, description, file opcional) → el logo actualizado */
export async function updateLogoHandler(req: Request): Promise<Response> {
  const { custId, bucketName } = await getAccessContext(req);
  const id = parseId(req);
  const { input, file } = await readForm(req);

  return json(await updateLogo(id, custId, bucketName, input, file));
}

/** DELETE /logos?id=123 → { id } */
export async function deleteLogoHandler(req: Request): Promise<Response> {
  const { custId, bucketName } = await getAccessContext(req);
  const id = parseId(req);

  await deleteLogo(id, custId, bucketName);
  return json({ id });
}