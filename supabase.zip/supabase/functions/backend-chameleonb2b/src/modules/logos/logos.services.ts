import { AppError } from "../../shared/http.ts";
import { supabaseAdmin } from "../../shared/supabase.ts";
import { random11Digits } from "../../shared/random.ts";
import { convertImageToWebp } from "../../shared/convert-img-to-webp.ts";
import { createSignedUrls } from "../buckets/buckets.services.ts";
import type { LogoInput, LogoItem, LogoRow } from "./logos.types.ts";

const TABLE = "logos";
const COLUMNS = "logo_id, cust_id, logo_name, logo_description, logo_link_img";

/** Carpeta dentro del bucket del customer: {cust_name_bucket}/storage/logos/ */
const LOGOS_FOLDER = "storage/logos";

const ALLOWED_TYPES = ["image/jpeg", "image/png", "image/webp", "image/gif"];
const MAX_UPLOAD_ATTEMPTS = 5;
export const MAX_IMAGE_BYTES = 5 * 1024 * 1024;

const imagePath = (fileName: string) => `${LOGOS_FOLDER}/${fileName}`;

/* ───────────────────────── Imagen ───────────────────────── */

/** ¿Storage rechazó la subida porque ya existe un archivo con ese nombre? */
function isAlreadyExists(error: { message?: string; statusCode?: string | number; status?: number }): boolean {
  return (
    String(error.statusCode ?? error.status) === "409" ||
    /already exists|duplicate/i.test(error.message ?? "")
  );
}

/** Borra una imagen del bucket. Nunca lanza error. */
async function removeImage(bucketName: string, fileName: string): Promise<void> {
  const { error } = await supabaseAdmin.storage.from(bucketName).remove([imagePath(fileName)]);
  if (error) console.error("logos.removeImage:", error);
}

/**
 * Valida la imagen, la convierte a WebP y la sube a {bucket}/logos/ con un nombre al azar.
 * upsert:false garantiza que nunca se pise otra imagen: si el nombre ya existe, se reintenta con otro.
 * Devuelve el nombre del archivo (ej. "48213749201.webp").
 */
async function uploadLogoImage(bucketName: string, file: File): Promise<string> {
  if (!ALLOWED_TYPES.includes(file.type)) {
    throw new AppError(400, "Formato no permitido. Usa JPG, PNG, WEBP o GIF.", "INVALID_IMAGE");
  }
  if (file.size > MAX_IMAGE_BYTES) {
    throw new AppError(400, "La imagen no puede pesar más de 5 MB.", "IMAGE_TOO_LARGE");
  }

  let webp: Uint8Array;
  try {
    webp = await convertImageToWebp(new Uint8Array(await file.arrayBuffer()));
  } catch (err) {
    console.error("logos.uploadLogoImage(convert):", err);
    throw new AppError(400, "No se pudo procesar la imagen. Prueba con otro archivo.", "INVALID_IMAGE");
  }

  for (let attempt = 0; attempt < MAX_UPLOAD_ATTEMPTS; attempt++) {
    const fileName = `${random11Digits()}.webp`;

    const { error } = await supabaseAdmin.storage
      .from(bucketName)
      .upload(imagePath(fileName), webp, { contentType: "image/webp", upsert: false });

    if (!error) return fileName;

    if (!isAlreadyExists(error)) {
      console.error("logos.uploadLogoImage(upload):", error);
      throw new AppError(500, "No se pudo subir la imagen.");
    }
    // Ya existía ese nombre: se prueba con otro número al azar.
  }

  throw new AppError(500, "No se pudo generar un nombre único para la imagen. Intenta de nuevo.");
}

/** Agrega el enlace firmado de la imagen a una o varias filas. */
async function withImageUrls(bucketName: string, rows: LogoRow[]): Promise<LogoItem[]> {
  const urls = await createSignedUrls(bucketName, rows.map((r) => imagePath(r.logo_link_img)));
  return rows.map((row) => ({ ...row, img_url: urls.get(imagePath(row.logo_link_img)) ?? null }));
}

/* ───────────────────────── Datos ───────────────────────── */

/** Logo que exista Y sea de este customer (el id llega del cliente). */
async function findOwned(id: number, custId: number): Promise<LogoRow> {
  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .select(COLUMNS)
    .eq("logo_id", id)
    .eq("cust_id", custId)
    .maybeSingle();

  if (error) {
    console.error("logos.findOwned:", error);
    throw new AppError(500, "No se pudo consultar el logo.");
  }
  if (!data) throw new AppError(404, "El logo no existe.", "NOT_FOUND");
  return data as LogoRow;
}

/** READ: logos del customer, del más nuevo al más antiguo. */
export async function listLogos(custId: number, bucketName: string): Promise<LogoItem[]> {
  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .select(COLUMNS)
    .eq("cust_id", custId)
    .order("logo_id", { ascending: false });

  if (error) {
    console.error("logos.listLogos:", error);
    throw new AppError(500, "No se pudieron obtener los logos.");
  }
  return await withImageUrls(bucketName, (data ?? []) as LogoRow[]);
}

/** CREATE: sube la imagen (WebP, nombre al azar) y guarda el logo. */
export async function createLogo(
  custId: number,
  bucketName: string,
  input: LogoInput,
  file: File,
): Promise<LogoItem> {
  const fileName = await uploadLogoImage(bucketName, file);

  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .insert({
      cust_id: custId,
      logo_name: input.name,
      logo_description: input.description,
      logo_link_img: fileName,
    })
    .select(COLUMNS)
    .single();

  if (error || !data) {
    console.error("logos.createLogo:", error);
    await removeImage(bucketName, fileName); // rollback de la imagen
    throw new AppError(500, "No se pudo guardar el logo.");
  }

  const [item] = await withImageUrls(bucketName, [data as LogoRow]);
  return item;
}

/** UPDATE: edita nombre y descripción; si llega imagen nueva, reemplaza la anterior. */
export async function updateLogo(
  id: number,
  custId: number,
  bucketName: string,
  input: LogoInput,
  file: File | null,
): Promise<LogoItem> {
  const current = await findOwned(id, custId);
  const newFileName = file ? await uploadLogoImage(bucketName, file) : null;

  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .update({
      logo_name: input.name,
      logo_description: input.description,
      ...(newFileName ? { logo_link_img: newFileName } : {}),
    })
    .eq("logo_id", id)
    .eq("cust_id", custId)
    .select(COLUMNS)
    .single();

  if (error || !data) {
    console.error("logos.updateLogo:", error);
    if (newFileName) await removeImage(bucketName, newFileName); // rollback de la imagen nueva
    throw new AppError(500, "No se pudo actualizar el logo.");
  }

  // La imagen anterior ya no se usa: se borra (si falla no importa).
  if (newFileName) await removeImage(bucketName, current.logo_link_img);

  const [item] = await withImageUrls(bucketName, [data as LogoRow]);
  return item;
}

/** DELETE: borra el logo y su imagen del bucket. */
export async function deleteLogo(id: number, custId: number, bucketName: string): Promise<void> {
  const current = await findOwned(id, custId);

  const { error } = await supabaseAdmin
    .from(TABLE)
    .delete()
    .eq("logo_id", id)
    .eq("cust_id", custId);

  if (error) {
    console.error("logos.deleteLogo:", error);
    throw new AppError(500, "No se pudo eliminar el logo.");
  }

  await removeImage(bucketName, current.logo_link_img);
}