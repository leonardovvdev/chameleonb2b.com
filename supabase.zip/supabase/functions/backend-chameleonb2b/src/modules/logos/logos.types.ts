export interface Logo {
  logo_id: number;
  cust_id: number;
  logo_name: string;
  logo_description: string | null;
  logo_link_img: string;
}

/** Fila tal como sale de la tabla logos. */
export type LogoRow = Logo;

/** Datos editables que llegan del formulario. */
export interface LogoInput {
  name: string;
  description: string | null;
}

/** Logo con su enlace firmado para mostrar la imagen. */
export interface LogoItem extends Logo {
  img_url: string | null;
}