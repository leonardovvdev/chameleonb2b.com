export interface Customer {
  cust_id: number;
  cust_name: string;
  cust_lastname: string;
  cust_name_bucket: number;
  cust_name_img_link: string | null;
  cust_auth_id: string | null;
  cust_code_system: number;
  cust_is_active: boolean;
  cust_creation_date: string;
  cust_updated_date: string;
}

/** Datos para insertar un customer (lo demás lo pone la BD). */
export interface NewCustomer {
  cust_name: string;
  cust_lastname: string;
  cust_name_bucket: number;
  cust_auth_id: string;
  cust_code_system: number;
}

export interface RegisterResult {
  created: boolean;
  customer: Customer;
  redirectUrl: string;
}