import { supabaseAdmin } from "../../shared/supabase.ts";
import { AppError } from "../../shared/http.ts";
import type { Supervisor, SupervisorRow } from "./staff.types.ts";

/** Nombre del cargo, venga como objeto o como arreglo. */
function jobPositionName(row: SupervisorRow): string | null {
  const jp = Array.isArray(row.customer_job_positions)
    ? row.customer_job_positions[0]
    : row.customer_job_positions;
  return jp?.cust_jb_pstn_name ?? null;
}

/**
 * Convierte las filas de staffs en supervisores con su cantidad de subordinados
 * y los ordena: primero el que tiene más personal a cargo, al final los que no
 * tienen a nadie. Si empatan, por nombre y apellido.
 */
export function buildSupervisors(rows: SupervisorRow[]): Supervisor[] {
  // stff_supervisor_id → cuántos staffs lo tienen como jefe directo
  const subordinates = new Map<number, number>();
  for (const row of rows) {
    if (row.stff_supervisor_id !== null) {
      subordinates.set(row.stff_supervisor_id, (subordinates.get(row.stff_supervisor_id) ?? 0) + 1);
    }
  }

  return rows
    .map((row) => ({
      id: row.stff_id,
      name: row.stff_name,
      lastname: row.stff_lastname,
      img_link: row.stff_link_img,
      job_position: jobPositionName(row),
      subordinates: subordinates.get(row.stff_id) ?? 0,
    }))
    .sort(
      (a, b) =>
        b.subordinates - a.subordinates ||
        `${a.name} ${a.lastname}`.localeCompare(`${b.name} ${b.lastname}`, "es"),
    );
}

/** Todo el personal del cliente, ordenado como posibles supervisores. */
export async function listSupervisors(custId: number): Promise<Supervisor[]> {
  const { data, error } = await supabaseAdmin
    .from("staffs")
    .select(
      "stff_id, stff_name, stff_lastname, stff_link_img, stff_supervisor_id, customer_job_positions(cust_jb_pstn_name)",
    )
    .eq("cust_id", custId);

  if (error) {
    console.error("staffs.listSupervisors:", error);
    throw new AppError(500, "No se pudo obtener la lista de supervisores.");
  }

  return buildSupervisors((data ?? []) as SupervisorRow[]);
}

/*
 * TODO createStaff (tus notas):
 *   - nombre, apellido, dni, phone
 *   - imagen: se guarda en el bucket del cliente, en gestion_empresarial/imagen_staffs/,
 *     convertida a webp y con un número al azar como nombre (ej. "61651988941.webp");
 *     ese nombre con su extensión va en la columna stff_link_img.
 */