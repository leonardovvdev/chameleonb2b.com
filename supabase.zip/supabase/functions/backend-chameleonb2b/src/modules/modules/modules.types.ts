export interface Module {
  mod_id: number;
  mod_name: string;
  mod_description: string | null;
  mod_direction_url: string | null;
  cust_mod_is_active_show_login: boolean;
  mod_is_active: boolean;
}
