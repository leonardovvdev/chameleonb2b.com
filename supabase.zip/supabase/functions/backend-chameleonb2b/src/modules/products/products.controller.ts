export interface Product {
  prdct_id: number;
  ctgry_id: number | null;
  brnd_id: number | null;
  cust_id: number;
  prdct_name: string;
  prdct_name_img_link: string | null;
  prdct_important: boolean;
  prdct_price: number;
}
