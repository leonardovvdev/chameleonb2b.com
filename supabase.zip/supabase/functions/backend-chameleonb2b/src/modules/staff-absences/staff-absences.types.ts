export interface StaffAbsence {
  stff_absc_id: number;
  stff_id: number;
  stff_absc_start_date: string;
  stff_absc_end_date: string;
  stff_absc_type: 'vacaciones' | 'licencia_medica' | 'permiso_particular' | 'suspension' | 'otro';
  stff_absc_approved_by: number | null;
  stff_absc_description: string;
}
