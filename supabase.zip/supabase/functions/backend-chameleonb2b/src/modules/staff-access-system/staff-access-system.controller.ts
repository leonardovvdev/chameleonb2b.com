export interface StaffAccessSystem {
  stff_ccss_systm_id: number;
  stff_id: number;
  stff_ccss_login_at: string;
  stff_ccss_logout_at: string | null;
  stff_ccss_success: boolean;
  stff_ccss_ip: string | null;
  stff_ccss_device: string | null;
}
