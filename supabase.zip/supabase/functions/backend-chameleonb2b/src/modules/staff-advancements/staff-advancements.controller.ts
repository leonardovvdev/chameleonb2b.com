import { AppError, json } from "../../shared/http.ts";
import { getAccessContext } from "../staffs/staff.services.ts";
import { getActorStaffId } from "../staff-discount-incidents/staff-discount-incidents.services.ts";
import {
  createAdvancement,
  getActor,
  listAdvancements,
  updateAdvancement,
} from "./staff-advancements.services.ts";
import type {
  CreateStaffAdvancementInput,
  StaffAdvancementFilters,
  UpdateStaffAdvancementInput,
} from "./staff-advancements.types.ts";

const MAX_PAGE_SIZE = 100;
const MAX_SEARCH_LENGTH = 100;
const MAX_DESCRIPTION_LENGTH = 500;
const MAX_AMOUNT = 9_999_999_999.99; // NUMERIC(12,2)

/** Fecha de HOY en Lima (YYYY-MM-DD): la misma zona que usa attendance. */
const todayInLima = (): string =>
  new Intl.DateTimeFormat("en-CA", { timeZone: "America/Lima" }).format(new Date());

const invalid = (message: string, code = "INVALID_BODY") => new AppError(400, message, code);

const toPositiveId = (raw: unknown, message = "El id no es válido.", code = "INVALID_ID"): number => {
  const n = Number(raw);
  if (raw === null || raw === "" || !Number.isSafeInteger(n) || n <= 0) throw invalid(message, code);
  return n;
};

/** YYYY-MM-DD y que sea una fecha real (rechaza 2026-02-31). */
const toDate = (raw: unknown, message: string, code: string): string => {
  if (typeof raw !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(raw)) throw invalid(message, code);
  const d = new Date(`${raw}T00:00:00Z`);
  if (Number.isNaN(d.getTime()) || d.toISOString().slice(0, 10) !== raw) throw invalid(message, code);
  return raw;
};

const toAmount = (raw: unknown): number => {
  const amount = typeof raw === "string" && raw.trim() === "" ? NaN : Number(raw);
  if (!Number.isFinite(amount) || amount <= 0 || amount > MAX_AMOUNT) {
    throw invalid("El importe debe ser mayor a 0.", "INVALID_AMOUNT");
  }
  return Math.round(amount * 100) / 100;
};

/** Texto opcional: vacío / null → null. */
const toDescription = (raw: unknown): string | null => {
  if (raw === null || raw === undefined) return null;
  if (typeof raw !== "string") throw invalid("La descripción no es válida.", "INVALID_DESCRIPTION");
  const text = raw.trim();
  if (text.length > MAX_DESCRIPTION_LENGTH) {
    throw invalid(`La descripción no puede superar ${MAX_DESCRIPTION_LENGTH} caracteres.`, "INVALID_DESCRIPTION");
  }
  return text === "" ? null : text;
};

async function readBody(req: Request): Promise<Record<string, unknown>> {
  const body = await req.json().catch(() => null);
  if (!body || typeof body !== "object" || Array.isArray(body)) throw invalid("Los datos no son válidos.");
  return body as Record<string, unknown>;
}

function parseListFilters(req: Request): StaffAdvancementFilters {
  const params = new URL(req.url).searchParams;

  const optionalId = (key: string): number | null => {
    const raw = params.get(key);
    return raw ? toPositiveId(raw, "Los filtros no son válidos.", "INVALID_FILTER") : null;
  };
  const optionalDate = (key: string): string | null => {
    const raw = params.get(key);
    return raw ? toDate(raw, "Los filtros de fecha no son válidos.", "INVALID_FILTER") : null;
  };

  const dateFrom = optionalDate("dateFrom");
  const dateTo = optionalDate("dateTo");
  if (dateFrom && dateTo && dateFrom > dateTo) {
    throw invalid("La fecha inicial no puede ser mayor a la final.", "INVALID_FILTER");
  }

  return {
    page: Math.max(1, Math.floor(Number(params.get("page"))) || 1),
    pageSize: Math.min(MAX_PAGE_SIZE, Math.max(1, Math.floor(Number(params.get("pageSize"))) || 10)),
    search: (params.get("search") ?? "").trim().slice(0, MAX_SEARCH_LENGTH),
    stffId: optionalId("stffId"),
    dateFrom,
    dateTo,
  };
}

/** GET /staff-advancements?page=&pageSize=&search=&stffId=&dateFrom=&dateTo= → { items, count } */
export async function listAdvancementsHandler(req: Request): Promise<Response> {
  const { custId } = await getAccessContext(req);
  return json(await listAdvancements(custId, parseListFilters(req)));
}

/** GET /staff-advancements/actor → { staffId, name } (staffId null = el dueño) */
export async function getActorHandler(req: Request): Promise<Response> {
  await getAccessContext(req);
  return json(await getActor(req));
}

/** POST /staff-advancements  body { stffId, amount, date?, description? } — entrega: el usuario autenticado */
export async function createAdvancementHandler(req: Request): Promise<Response> {
  const { custId } = await getAccessContext(req);
  const body = await readBody(req);

  const input: CreateStaffAdvancementInput = {
    stffId: toPositiveId(body.stffId, "Selecciona el personal que recibe el adelanto.", "INVALID_STAFF"),
    // Quien entrega es SIEMPRE quien está autenticado (sale del JWT, nunca del body). null = el dueño.
    deliveredByStaffId: await getActorStaffId(req),
    amount: toAmount(body.amount),
    description: toDescription(body.description),
    date:
      body.date === undefined || body.date === null || body.date === ""
        ? todayInLima()
        : toDate(body.date, "La fecha no es válida.", "INVALID_DATE"),
  };

  return json(await createAdvancement(custId, input), 201);
}

/** PATCH /staff-advancements?id=  body { stffId?, amount?, date?, description? } */
export async function updateAdvancementHandler(req: Request): Promise<Response> {
  const { custId } = await getAccessContext(req);
  const id = toPositiveId(new URL(req.url).searchParams.get("id"), "El id del adelanto no es válido.");
  const body = await readBody(req);

  const input: UpdateStaffAdvancementInput = {};
  if (body.stffId !== undefined) {
    input.stffId = toPositiveId(body.stffId, "Selecciona el personal que recibe el adelanto.", "INVALID_STAFF");
  }
  // deliveredByStaffId no se puede cambiar al editar: se conserva quien entregó el adelanto.
  if (body.amount !== undefined) input.amount = toAmount(body.amount);
  if (body.description !== undefined) input.description = toDescription(body.description);
  if (body.date !== undefined) input.date = toDate(body.date, "La fecha no es válida.", "INVALID_DATE");

  if (Object.keys(input).length === 0) throw invalid("No hay cambios para guardar.", "NO_CHANGES");

  return json(await updateAdvancement(custId, id, input));
}