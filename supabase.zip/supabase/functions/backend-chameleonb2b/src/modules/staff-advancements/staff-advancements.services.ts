import { AppError } from "../../shared/http.ts";
import { supabaseAdmin } from "../../shared/supabase.ts";
import { sanitizeSearchWord } from "../staffs/staff.services.ts";
import { getActorStaffId } from "../staff-discount-incidents/staff-discount-incidents.services.ts";
import type {
  CreateStaffAdvancementInput,
  StaffAdvancementFilters,
  StaffAdvancementItem,
  StaffAdvancementListResult,
  StaffAdvancementRow,
  UpdateStaffAdvancementInput,
} from "./staff-advancements.types.ts";

const TABLE = "staff_advancements";

/** Tope de ids de personal al buscar por texto (evita URLs gigantes en el .in()). */
const MAX_SEARCH_MATCHES = 500;

type StaffNameRow = { stff_id: number; stff_name: string; stff_lastname: string; stff_dni: string | null };

/**
 * Filas de la BD → lo que recibe el frontend.
 * Se piden los nombres aparte (en vez de embeber) porque la tabla tiene DOS llaves foráneas a staffs
 * y PostgREST necesitaría el nombre exacto de cada constraint para desambiguar.
 */
async function toItems(rows: StaffAdvancementRow[]): Promise<StaffAdvancementItem[]> {
  const ids = [
    ...new Set(rows.flatMap((r) => [r.stff_id, r.stff_id_advancement_by]).filter((id): id is number => id !== null)),
  ];
  const staffById = new Map<number, StaffNameRow>();

  if (ids.length > 0) {
    const { data, error } = await supabaseAdmin
      .from("staffs")
      .select("stff_id, stff_name, stff_lastname, stff_dni")
      .in("stff_id", ids);

    if (error) {
      console.error("staff-advancements.toItems:", error);
      throw new AppError(500, "No se pudo obtener el personal de los adelantos.");
    }
    for (const s of (data ?? []) as StaffNameRow[]) staffById.set(s.stff_id, s);
  }

  const fullName = (s: StaffNameRow | undefined) => (s ? `${s.stff_name} ${s.stff_lastname}`.trim() : null);

  return rows.map((row) => {
    const receiver = staffById.get(row.stff_id);
    return {
      id: row.stff_dvncmnt_id,
      stff_id: row.stff_id,
      stff_name: receiver?.stff_name ?? "",
      stff_lastname: receiver?.stff_lastname ?? "",
      stff_dni: receiver?.stff_dni ?? null,
      delivered_by_staff_id: row.stff_id_advancement_by,
      delivered_by_name:
        row.stff_id_advancement_by !== null ? fullName(staffById.get(row.stff_id_advancement_by)) : null,
      amount: Number(row.stff_dvncmnt_amount),
      description: row.stff_dvncmnt_description,
      date: row.stff_dvncmnt_date,
    };
  });
}

/** Lanza 404 si alguno de los ids no es personal del customer (evita usar personal de otra empresa). */
async function assertStaffsOfCustomer(custId: number, stffIds: number[]): Promise<void> {
  const unique = [...new Set(stffIds)];
  if (unique.length === 0) return;

  const { data, error } = await supabaseAdmin
    .from("staffs")
    .select("stff_id")
    .eq("cust_id", custId)
    .in("stff_id", unique);

  if (error) {
    console.error("staff-advancements.assertStaffsOfCustomer:", error);
    throw new AppError(500, "No se pudo consultar el personal.");
  }
  if ((data ?? []).length !== unique.length) {
    throw new AppError(404, "El personal indicado no existe.", "STAFF_NOT_FOUND");
  }
}

/** ids del personal del customer que coinciden con el texto (misma búsqueda que la lista de personal). */
async function findStaffIdsBySearch(custId: number, search: string): Promise<number[]> {
  let query = supabaseAdmin.from("staffs").select("stff_id").eq("cust_id", custId);

  const words = search.split(/\s+/).map(sanitizeSearchWord).filter(Boolean);
  for (const word of words) {
    query = query.or(`stff_name.ilike.%${word}%,stff_lastname.ilike.%${word}%,stff_dni.ilike.%${word}%`);
  }

  const { data, error } = await query.limit(MAX_SEARCH_MATCHES);
  if (error) {
    console.error("staff-advancements.findStaffIdsBySearch:", error);
    throw new AppError(500, "No se pudo buscar el personal.");
  }
  return ((data ?? []) as { stff_id: number }[]).map((r) => r.stff_id);
}

/** READ: una página de adelantos del customer (los más recientes primero). */
export async function listAdvancements(
  custId: number,
  filters: StaffAdvancementFilters,
): Promise<StaffAdvancementListResult> {
  let query = supabaseAdmin.from(TABLE).select("*", { count: "exact" }).eq("cust_id", custId);

  if (filters.stffId !== null) query = query.eq("stff_id", filters.stffId);
  if (filters.dateFrom) query = query.gte("stff_dvncmnt_date", filters.dateFrom);
  if (filters.dateTo) query = query.lte("stff_dvncmnt_date", filters.dateTo);

  if (filters.search !== "") {
    const ids = await findStaffIdsBySearch(custId, filters.search);
    if (ids.length === 0) return { items: [], count: 0 };
    query = query.in("stff_id", ids);
  }

  const from = (filters.page - 1) * filters.pageSize;
  const to = from + filters.pageSize - 1;

  const { data, error, count } = await query
    .order("stff_dvncmnt_date", { ascending: false })
    .order("stff_dvncmnt_id", { ascending: false })
    .range(from, to);

  if (error) {
    console.error("staff-advancements.listAdvancements:", error);
    throw new AppError(500, "No se pudieron obtener los adelantos.");
  }
  return { items: await toItems((data ?? []) as StaffAdvancementRow[]), count: count ?? 0 };
}

/** CREATE: nuevo adelanto. El cust_id sale siempre del JWT, nunca del body. */
export async function createAdvancement(
  custId: number,
  input: CreateStaffAdvancementInput,
): Promise<StaffAdvancementItem> {
  await assertStaffsOfCustomer(custId, [input.stffId, ...(input.deliveredByStaffId !== null ? [input.deliveredByStaffId] : [])]);

  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .insert({
      stff_id: input.stffId,
      stff_id_advancement_by: input.deliveredByStaffId,
      cust_id: custId,
      stff_dvncmnt_amount: input.amount,
      stff_dvncmnt_description: input.description,
      stff_dvncmnt_date: input.date,
    })
    .select("*")
    .single();

  if (error || !data) {
    console.error("staff-advancements.createAdvancement:", error);
    throw new AppError(500, "No se pudo crear el adelanto.");
  }
  const [item] = await toItems([data as StaffAdvancementRow]);
  return item;
}

/** UPDATE: edita un adelanto del customer. Solo cambia los campos que llegan. */
export async function updateAdvancement(
  custId: number,
  id: number,
  input: UpdateStaffAdvancementInput,
): Promise<StaffAdvancementItem> {
  const staffIds: number[] = [];
  if (input.stffId !== undefined) staffIds.push(input.stffId);
  if (input.deliveredByStaffId !== undefined && input.deliveredByStaffId !== null) {
    staffIds.push(input.deliveredByStaffId);
  }
  await assertStaffsOfCustomer(custId, staffIds);

  const changes: Record<string, unknown> = {};
  if (input.stffId !== undefined) changes.stff_id = input.stffId;
  if (input.deliveredByStaffId !== undefined) changes.stff_id_advancement_by = input.deliveredByStaffId;
  if (input.amount !== undefined) changes.stff_dvncmnt_amount = input.amount;
  if (input.description !== undefined) changes.stff_dvncmnt_description = input.description;
  if (input.date !== undefined) changes.stff_dvncmnt_date = input.date;

  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .update(changes)
    .eq("stff_dvncmnt_id", id)
    .eq("cust_id", custId)
    .select("*")
    .maybeSingle();

  if (error) {
    console.error("staff-advancements.updateAdvancement:", error);
    throw new AppError(500, "No se pudo actualizar el adelanto.");
  }
  if (!data) throw new AppError(404, "El adelanto no existe.", "NOT_FOUND");

  const [item] = await toItems([data as StaffAdvancementRow]);
  return item;
}

/**
 * Quién está usando el sistema: el staff autenticado (con su nombre) o, si es el titular de la
 * cuenta (dueño), staffId = null. Sirve para preseleccionar "Entregado por" en el formulario.
 */
export async function getActor(req: Request): Promise<{ staffId: number | null; name: string | null }> {
  const staffId = await getActorStaffId(req);
  if (staffId === null) return { staffId: null, name: null };

  const { data, error } = await supabaseAdmin
    .from("staffs")
    .select("stff_name, stff_lastname")
    .eq("stff_id", staffId)
    .maybeSingle();

  if (error) {
    console.error("staff-advancements.getActor:", error);
    throw new AppError(500, "No se pudo consultar tu cuenta.");
  }
  const row = data as { stff_name: string; stff_lastname: string } | null;
  return { staffId, name: row ? `${row.stff_name} ${row.stff_lastname}`.trim() : null };
}