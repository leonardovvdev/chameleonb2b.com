export interface StaffAdvancement {
  stff_dvncmnt_id: number;
  att_id: number;
  stff_id_advancement_by: number | null;
  stff_dvncmnt_amount: number;
  stff_dvncmnt_description: string | null;
}
