/** Fila tal como la devuelve PostgREST (tabla staff_advancements). */
export interface StaffAdvancementRow {
  stff_dvncmnt_id: number;
  stff_id: number;
  stff_id_advancement_by: number | null;
  cust_id: number;
  stff_dvncmnt_amount: number | string;
  stff_dvncmnt_description: string | null;
  stff_dvncmnt_date: string;
}

/** Datos ya validados para crear un adelanto. */
export interface CreateStaffAdvancementInput {
  stffId: number;
  /** null = el dueño entregó el dinero. */
  deliveredByStaffId: number | null;
  amount: number;
  description: string | null;
  date: string;
}

/** Datos ya validados para editar un adelanto (solo llegan los campos que se quieren cambiar). */
export interface UpdateStaffAdvancementInput {
  stffId?: number;
  deliveredByStaffId?: number | null;
  amount?: number;
  description?: string | null;
  date?: string;
}

export interface StaffAdvancementFilters {
  page: number;
  pageSize: number;
  /** Busca por nombre, apellido o DNI del personal que recibió el adelanto. */
  search: string;
  /** Solo los adelantos de este personal. */
  stffId: number | null;
  /** YYYY-MM-DD (inclusive). */
  dateFrom: string | null;
  dateTo: string | null;
}

/** Lo que recibe el frontend (GET / POST / PATCH /staff-advancements). */
export interface StaffAdvancementItem {
  id: number;
  /** Personal que recibió el adelanto. */
  stff_id: number;
  stff_name: string;
  stff_lastname: string;
  stff_dni: string | null;
  /** Personal que entregó el dinero (null = el dueño). */
  delivered_by_staff_id: number | null;
  delivered_by_name: string | null;
  amount: number;
  description: string | null;
  /** YYYY-MM-DD */
  date: string;
}

export interface StaffAdvancementListResult {
  items: StaffAdvancementItem[];
  count: number;
}