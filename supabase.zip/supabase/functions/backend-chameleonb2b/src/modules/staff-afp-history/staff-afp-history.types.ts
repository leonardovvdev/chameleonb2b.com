export interface StaffAfpHistory {
  stff_afp_hstry_id: number;

  afp_id: number;
  stff_cntrt_id: number;

  stff_afp_start: string;
  stff_afp_end: string | null;
}

export interface StaffAfpHistoryInsert {
  afp_id: number;
  stff_cntrt_id: number;

  stff_afp_start: string;
  stff_afp_end?: string | null;
}

export interface StaffAfpHistoryUpdate {
  afp_id?: number;
  stff_cntrt_id?: number;

  stff_afp_start?: string;
  stff_afp_end?: string | null;
}