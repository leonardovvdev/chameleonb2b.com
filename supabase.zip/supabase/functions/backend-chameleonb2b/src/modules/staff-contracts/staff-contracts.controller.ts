import { AppError, json } from "../../shared/http.ts";
import { getAccessContext } from "../staffs/staff.services.ts";
import { listContractsByStaff } from "./staff-contracts.services.ts";

/** GET /staff-contracts?stffId= → { items } */
export async function listContracts(req: Request): Promise<Response> {
  const { custId } = await getAccessContext(req);

  const raw = new URL(req.url).searchParams.get("stffId");
  const stffId = Number(raw);
  if (!raw || !Number.isSafeInteger(stffId) || stffId <= 0) {
    throw new AppError(400, "El id del personal no es válido.", "INVALID_ID");
  }

  return json({ items: await listContractsByStaff(custId, stffId) });
}