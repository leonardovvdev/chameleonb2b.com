import { AppError, json } from "../../shared/http.ts";
import { getAccessContext } from "../auth/auth.services.ts";
import { parseId } from "../attendance/attendance.services.ts";
import {
  getCurrentContract,
  listStaffContracts,
  updateContract,
  updateContractSchedule,
} from "./staff-contracts.services.ts";

/** GET /staff-contracts?stffId= */
export async function listStaffContractsHandler(req: Request): Promise<Response> {
  const ctx = await getAccessContext(req);
  const stffId = parseId(new URL(req.url).searchParams.get("stffId"), "El personal");
  return json(await listStaffContracts(ctx, stffId));
}

/** GET /staff-contracts/current?stffId= */
export async function getCurrentContractHandler(req: Request): Promise<Response> {
  const ctx = await getAccessContext(req);
  const stffId = parseId(new URL(req.url).searchParams.get("stffId"), "El personal");
  return json(await getCurrentContract(ctx, stffId));
}

async function readBody(req: Request): Promise<unknown> {
  const body = await req.json().catch(() => null);
  if (body === null) throw new AppError(400, "El cuerpo de la petición no es válido.", "INVALID_BODY");
  return body;
}

/** PATCH /staff-contracts */
export async function updateContractHandler(req: Request): Promise<Response> {
  const ctx = await getAccessContext(req);
  return json(await updateContract(ctx, await readBody(req)));
}

/** PATCH /staff-contracts/schedule */
export async function updateContractScheduleHandler(req: Request): Promise<Response> {
  const ctx = await getAccessContext(req);
  return json(await updateContractSchedule(ctx, await readBody(req)));
}