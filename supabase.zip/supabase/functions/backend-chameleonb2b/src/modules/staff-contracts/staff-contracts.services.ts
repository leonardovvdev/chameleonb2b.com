import { AppError } from "../../shared/http.ts";
import { supabaseAdmin } from "../../shared/supabase.ts";
import type { AccessContext } from "../auth/auth.services.ts";

// deno-lint-ignore no-explicit-any
type Row = Record<string, any>;

/** Comprueba que el personal sea de este customer y devuelve las columnas pedidas. */
export async function assertStaffOfCustomer(ctx: AccessContext, stffId: number, columns = "stff_id"): Promise<Row> {
  const { data, error } = await supabaseAdmin
    .from("staffs")
    .select(columns)
    .eq("stff_id", stffId)
    .eq("cust_id", ctx.custId)
    .maybeSingle();
  if (error) {
    console.error("staff-contracts: no se pudo validar al personal", error);
    throw new AppError(500, "No se pudo validar al personal.");
  }
  if (!data) throw new AppError(404, "El personal no existe.", "NOT_FOUND");
  return data as Row;
}

/** GET /staff-contracts?stffId= → { items } (del más reciente al más antiguo). `number` = orden de contratación. */
export async function listStaffContracts(ctx: AccessContext, stffId: number) {
  await assertStaffOfCustomer(ctx, stffId);

  const { data, error } = await supabaseAdmin
    .from("staff_contracts")
    .select("stff_cntrt_id, cntrt_start_date, cntrt_end_date, cntrt_status")
    .eq("stff_id", stffId)
    .order("stff_cntrt_id", { ascending: true });
  if (error) {
    console.error("staff-contracts: no se pudieron cargar los contratos", error);
    throw new AppError(500, "No se pudieron cargar los contratos.");
  }

  const items = (data ?? []).map((c, i) => ({
    id: c.stff_cntrt_id as number,
    number: i + 1,
    start_date: (c.cntrt_start_date as string | null) ?? null,
    end_date: (c.cntrt_end_date as string | null) ?? null,
    status: c.cntrt_status as "activo" | "inactivo",
  }));
  return { items: items.reverse() };
}

/* ═════════════════════ Contrato actual: ver y editar ═════════════════════
 * "Contrato actual" = el más reciente del personal (el mismo que usa GET /staffs/detail).
 * Los datos de horario, refrigerio y días no laborables son propios de cada contrato
 * (staff_add_contract crea filas nuevas por contrato), así que editarlos solo afecta a este contrato.
 */

const bad = (message: string, code = "INVALID_DATA") => new AppError(400, message, code);

const asObj = (v: unknown, label: string): Row => {
  if (typeof v !== "object" || v === null || Array.isArray(v)) throw bad(`${label} no es válido.`);
  return v as Row;
};

const hhmmOut = (v: string | null) => (v ? v.slice(0, 5) : null);

const parseTime = (v: unknown, label: string): string => {
  const t = typeof v === "string" ? v.trim().slice(0, 5) : "";
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(t)) throw bad(`${label} no es válida.`);
  return t;
};

const parseIntRange = (v: unknown, min: number, max: number, label: string): number => {
  const n = Number(v);
  if (!Number.isInteger(n) || n < min || n > max) throw bad(`${label} no es válido.`);
  return n;
};

const parseDateOrNull = (v: unknown, label: string): string | null => {
  if (v === null || v === undefined || v === "") return null;
  const d = typeof v === "string" ? v.trim().slice(0, 10) : "";
  if (!/^\d{4}-\d{2}-\d{2}$/.test(d) || Number.isNaN(new Date(`${d}T00:00:00Z`).getTime())) {
    throw bad(`${label} no es válida.`);
  }
  return d;
};

/** Número con 2 decimales entre 0 y `max`. */
const parseDecimal = (v: unknown, max: number, label: string): number => {
  const n = Math.round(Number(v) * 100) / 100;
  if (v === "" || v === null || v === undefined || !Number.isFinite(n) || n < 0 || n > max) {
    throw bad(`${label} no es válido.`);
  }
  return n;
};

async function loadOwnedContract(ctx: AccessContext, stffId: number, contractId: number): Promise<Row> {
  await assertStaffOfCustomer(ctx, stffId);
  const { data, error } = await supabaseAdmin
    .from("staff_contracts")
    .select("*")
    .eq("stff_cntrt_id", contractId)
    .eq("stff_id", stffId)
    .maybeSingle();
  if (error) {
    console.error("staff-contracts: no se pudo cargar el contrato", error);
    throw new AppError(500, "No se pudo cargar el contrato.");
  }
  if (!data) throw new AppError(404, "El contrato no existe.", "NOT_FOUND");
  return data as Row;
}

function contractDto(c: Row) {
  return {
    id: c.stff_cntrt_id as number,
    status: c.cntrt_status as "activo" | "inactivo",
    start_date: c.cntrt_start_date ? String(c.cntrt_start_date).slice(0, 10) : null,
    end_date: c.cntrt_end_date ? String(c.cntrt_end_date).slice(0, 10) : null,
    salary_amount: Number(c.cntrt_salary_amount),
    payroll: c.cntrt_payroll === true,
    afp_discount: Number(c.cntrt_afp_discount ?? 0),
    insurance_premium: Number(c.cntrt_insurance_premium ?? 0),
    discount_absence: c.cntrt_discount_absence === true,
    discount_delay: c.cntrt_discount_delay === true,
    discount_refreshment_delay: c.cntrt_discount_refreshment_delay === true,
  };
}

/** GET /staff-contracts/current?stffId= → contrato más reciente + su horario, refrigerio y días no laborables. */
export async function getCurrentContract(ctx: AccessContext, stffId: number) {
  await assertStaffOfCustomer(ctx, stffId);

  const { data: c, error } = await supabaseAdmin
    .from("staff_contracts")
    .select("*")
    .eq("stff_id", stffId)
    .order("stff_cntrt_id", { ascending: false })
    .limit(1)
    .maybeSingle();
  if (error) {
    console.error("staff-contracts: no se pudo cargar el contrato actual", error);
    throw new AppError(500, "No se pudo cargar el contrato.");
  }
  if (!c) throw new AppError(404, "Este personal no tiene contrato registrado.", "NO_CONTRACT");

  const { data: hist, error: hErr } = await supabaseAdmin
    .from("staff_schedule_history")
    .select("stff_schdl_id")
    .eq("stff_cntrt_id", c.stff_cntrt_id)
    .order("schdl_hstry_end", { ascending: false, nullsFirst: true })
    .limit(1)
    .maybeSingle();
  if (hErr) {
    console.error("staff-contracts: no se pudo cargar el horario del contrato", hErr);
    throw new AppError(500, "No se pudo cargar el horario del contrato.");
  }

  let schedule: Row | null = null;
  let refreshment: Row | null = null;
  let nonWorkingDays: Row | null = null;

  if (hist) {
    const { data: sch, error: sErr } = await supabaseAdmin
      .from("staff_schedules")
      .select("*")
      .eq("stff_schdl_id", hist.stff_schdl_id)
      .maybeSingle();
    if (sErr) {
      console.error("staff-contracts: no se pudo cargar el horario", sErr);
      throw new AppError(500, "No se pudo cargar el horario.");
    }

    if (sch) {
      const [rfr, nwd] = await Promise.all([
        sch.stff_rfrshmnth_id
          ? supabaseAdmin.from("staff_refreshments").select("*").eq("stff_rfrshmnth_id", sch.stff_rfrshmnth_id).maybeSingle()
          : Promise.resolve({ data: null, error: null }),
        sch.stff_nn_wrkng_day_id
          ? supabaseAdmin.from("staff_non_working_days").select("*").eq("stff_nn_wrkng_day_id", sch.stff_nn_wrkng_day_id).maybeSingle()
          : Promise.resolve({ data: null, error: null }),
      ]);
      if (rfr.error || nwd.error) {
        console.error("staff-contracts: no se pudo cargar refrigerio/días no laborables", rfr.error ?? nwd.error);
        throw new AppError(500, "No se pudo cargar el refrigerio o los días no laborables.");
      }

      schedule = {
        type: sch.stff_schdl_type,
        start: hhmmOut(sch.stff_schdl_start),
        end: hhmmOut(sch.stff_schdl_end),
        toleranceMinutes: Number(sch.stff_schdl_start_tolerance ?? 0),
        requiredMinutes: sch.stff_schdl_required_minutes ?? null,
      };

      const r = rfr.data as Row | null;
      refreshment = r
        ? {
            type: r.stff_rfrshmnth_type,
            start: hhmmOut(r.stff_rfrshmnth_start),
            end: hhmmOut(r.stff_rfrshmnth_end),
            minutes: r.stff_rfrshmnth_minutes ?? null,
          }
        : { type: "free", start: null, end: null, minutes: null };

      const n = nwd.data as Row | null;
      nonWorkingDays = !n
        ? null
        : n.stff_nn_wrkng_day_type === "fixed"
          ? {
              type: "fixed",
              days: [
                n.stff_nn_wrkng_day_monday, n.stff_nn_wrkng_day_tuesday, n.stff_nn_wrkng_day_wednesday,
                n.stff_nn_wrkng_day_thursday, n.stff_nn_wrkng_day_friday, n.stff_nn_wrkng_day_saturday,
                n.stff_nn_wrkng_day_sunday,
              ].map((d) => d === true),
            }
          : { type: "flexible", numberDays: Number(n.stff_nn_wrkng_day_number_days ?? 0) };
    }
  }

  return { ...contractDto(c as Row), schedule, refreshment, nonWorkingDays };
}

/**
 * PATCH /staff-contracts { stffId, contractId, startDate, endDate, salaryAmount, payroll,
 *   afpDiscount, insurancePremium, discountFlags: { absence, delay, refreshmentDelay } }
 */
export async function updateContract(ctx: AccessContext, raw: unknown) {
  const b = asObj(raw, "Los datos");
  const stffId = parseIntRange(b.stffId, 1, Number.MAX_SAFE_INTEGER, "El personal");
  const contractId = parseIntRange(b.contractId, 1, Number.MAX_SAFE_INTEGER, "El contrato");
  const current = await loadOwnedContract(ctx, stffId, contractId);

  const startDate = parseDateOrNull(b.startDate, "La fecha de inicio");
  const endDate = parseDateOrNull(b.endDate, "La fecha de fin");
  if (startDate && endDate && endDate < startDate) {
    throw bad("La fecha de fin no puede ser anterior a la de inicio.");
  }
  // Un contrato terminado (inactivo) siempre debe conservar su fecha de fin.
  if (current.cntrt_status === "inactivo" && !endDate) {
    throw bad("Este contrato está terminado: la fecha de fin es obligatoria.");
  }

  const salary = Math.round(Number(b.salaryAmount) * 100) / 100;
  if (!Number.isFinite(salary) || salary <= 0 || salary >= 1e10) throw bad("Ingresa un sueldo válido.");

  if (typeof b.payroll !== "boolean") throw bad("El campo planilla no es válido.");
  const afp = parseDecimal(b.afpDiscount, 100, "El descuento de AFP");
  const premium = parseDecimal(b.insurancePremium, 100, "La prima de seguro");

  const f = asObj(b.discountFlags, "Los descuentos");
  if (typeof f.absence !== "boolean" || typeof f.delay !== "boolean" || typeof f.refreshmentDelay !== "boolean") {
    throw bad("Los descuentos no son válidos.");
  }

  const { data, error } = await supabaseAdmin
    .from("staff_contracts")
    .update({
      cntrt_start_date: startDate,
      cntrt_end_date: endDate,
      cntrt_salary_amount: salary,
      cntrt_payroll: b.payroll,
      cntrt_afp_discount: afp,
      cntrt_insurance_premium: premium,
      cntrt_discount_absence: f.absence,
      cntrt_discount_delay: f.delay,
      cntrt_discount_refreshment_delay: f.refreshmentDelay,
    })
    .eq("stff_cntrt_id", contractId)
    .eq("stff_id", stffId)
    .select("*")
    .single();
  if (error || !data) {
    console.error("staff-contracts: no se pudo guardar el contrato", error);
    if (error?.code === "23514") throw bad("Revisa las fechas del contrato.");
    throw new AppError(500, "No se pudo guardar el contrato.");
  }
  return contractDto(data as Row);
}

/**
 * PATCH /staff-contracts/schedule { stffId, contractId, schedule, refreshment, nonWorkingDays, effectiveDate? }
 * Misma forma que recibe POST /staffs. Se guarda de una sola vez con staff_update_schedule (SQL).
 * effectiveDate (YYYY-MM-DD, opcional): desde qué día rige el horario nuevo. Por defecto, hoy (hora de Lima).
 * Los días anteriores conservan el horario que tenían: el SQL cierra el tramo vigente del historial y abre uno nuevo.
 */
export async function updateContractSchedule(ctx: AccessContext, raw: unknown) {
  const b = asObj(raw, "Los datos");
  const stffId = parseIntRange(b.stffId, 1, Number.MAX_SAFE_INTEGER, "El personal");
  const contractId = parseIntRange(b.contractId, 1, Number.MAX_SAFE_INTEGER, "El contrato");
  await loadOwnedContract(ctx, stffId, contractId);

  const TYPES = ["fixed", "flexible", "free"];

  const s = asObj(b.schedule, "El horario");
  if (typeof s.type !== "string" || !TYPES.includes(s.type)) throw bad("El tipo de horario no es válido.");
  const schedule =
    s.type === "fixed"
      ? {
          type: "fixed",
          start: parseTime(s.start, "La hora de entrada"),
          end: parseTime(s.end, "La hora de salida"),
          toleranceMinutes: parseIntRange(s.toleranceMinutes ?? 0, 0, 1440, "La tolerancia"),
          requiredMinutes: null,
        }
      : s.type === "flexible"
        ? {
            type: "flexible", start: null, end: null, toleranceMinutes: 0,
            requiredMinutes: parseIntRange(s.requiredMinutes, 1, 1440, "Las horas de trabajo"),
          }
        : { type: "free", start: null, end: null, toleranceMinutes: 0, requiredMinutes: null };

  const r = asObj(b.refreshment, "El refrigerio");
  if (typeof r.type !== "string" || !TYPES.includes(r.type)) throw bad("El tipo de refrigerio no es válido.");
  const refreshment =
    r.type === "fixed"
      ? {
          type: "fixed",
          start: parseTime(r.start, "La hora de inicio del refrigerio"),
          end: parseTime(r.end, "La hora de fin del refrigerio"),
          minutes: null,
        }
      : r.type === "flexible"
        ? { type: "flexible", start: null, end: null, minutes: parseIntRange(r.minutes, 1, 1440, "Los minutos de refrigerio") }
        : { type: "free", start: null, end: null, minutes: null };

  let nonWorkingDays: Row | null = null;
  if (b.nonWorkingDays !== null && b.nonWorkingDays !== undefined) {
    const n = asObj(b.nonWorkingDays, "Los días no laborables");
    if (n.type === "fixed") {
      if (!Array.isArray(n.days) || n.days.length !== 7) throw bad("Los días no laborables no son válidos.");
      nonWorkingDays = { type: "fixed", days: n.days.map((d) => d === true) };
    } else if (n.type === "flexible") {
      nonWorkingDays = { type: "flexible", numberDays: parseIntRange(n.numberDays, 1, 7, "La cantidad de días no laborables") };
    } else {
      throw bad("El tipo de días no laborables no es válido.");
    }
  }

  let effectiveDate: string | null = null;
  if (b.effectiveDate !== undefined && b.effectiveDate !== null && b.effectiveDate !== "") {
    const d = typeof b.effectiveDate === "string" ? b.effectiveDate.trim().slice(0, 10) : "";
    if (!/^\d{4}-\d{2}-\d{2}$/.test(d) || Number.isNaN(new Date(`${d}T00:00:00Z`).getTime())) {
      throw bad("La fecha desde la que rige el horario no es válida.");
    }
    effectiveDate = d;
  }

  const { error } = await supabaseAdmin.rpc("staff_update_schedule", {
    p_cust_id: ctx.custId,
    p_stff_id: stffId,
    p_cntrt_id: contractId,
    p_data: { schedule, refreshment, nonWorkingDays },
    p_effective_date: effectiveDate,
  });
  if (error) {
    console.error("staff-contracts.staff_update_schedule:", error);
    if (error.message?.includes("CONTRACT_NOT_FOUND")) throw new AppError(404, "El contrato no existe.", "NOT_FOUND");
    if (error.message?.includes("SCHEDULE_NOT_FOUND")) {
      throw new AppError(404, "El contrato no tiene un horario registrado.", "NO_SCHEDULE");
    }
    if (error.message?.includes("INVALID_EFFECTIVE_DATE")) {
      throw bad("La fecha no puede ser anterior al inicio del horario actual.", "INVALID_EFFECTIVE_DATE");
    }
    if (error.code === "23514") throw bad("Revisa el horario, el refrigerio y los días no laborables.");
    throw new AppError(500, "No se pudo guardar el horario.");
  }
  return { stffId, contractId };
}