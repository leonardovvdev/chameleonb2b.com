import { AppError } from "../../shared/http.ts";
import { supabaseAdmin } from "../../shared/supabase.ts";
import type { ContractDbRow, ContractItem } from "./staff-contracts.types.ts";

const TABLE = "staff_contracts";

/** Fecha de hoy en Lima (YYYY-MM-DD), igual que el DEFAULT de la tabla. */
export const todayInLima = (): string =>
  new Date().toLocaleDateString("en-CA", { timeZone: "America/Lima" });

/** Fila de contrato tal como se lee de la tabla. */
export interface ContractRow {
  stff_cntrt_id: number;
  cntrt_start_date: string | null;
  cntrt_end_date: string | null;
  /** Horario del contrato (staff_schedules). */
  stff_schdl_id: number | null;
}

/** READ: contrato más reciente del personal, o null si no tiene. */
export async function getLatestContract(staffId: number): Promise<ContractRow | null> {
  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .select("stff_cntrt_id, cntrt_start_date, cntrt_end_date, stff_schdl_id")
    .eq("stff_id", staffId)
    .order("stff_cntrt_id", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (error) {
    console.error("staff-contracts.getLatestContract:", error);
    throw new AppError(500, "No se pudo consultar el contrato del personal.");
  }
  return (data as ContractRow | null) ?? null;
}

/**
 * CREATE: nuevo contrato activo con su horario (`scheduleId`).
 * `null` = fecha abierta (inicio: primera asistencia · fin: indefinido).
 */
export async function insertContract(
  staffId: number,
  contract: { startDate: string | null; endDate: string | null },
  scheduleId: number,
): Promise<number> {
  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .insert({
      stff_id: staffId,
      stff_schdl_id: scheduleId,
      cntrt_start_date: contract.startDate,
      cntrt_end_date: contract.endDate,
      cntrt_status: "activo",
    })
    .select("stff_cntrt_id")
    .single();

  if (error || !data) {
    console.error("staff-contracts.insertContract:", error);
    throw new AppError(500, "No se pudo guardar el contrato.");
  }
  return Number(data.stff_cntrt_id);
}

/**
 * UPDATE: fija `cntrt_start_date` solo si sigue en null (no pisa una fecha ya puesta).
 * Se usa con la primera asistencia del personal.
 */
export async function setContractStartDate(contractId: number, date: string): Promise<void> {
  const { error } = await supabaseAdmin
    .from(TABLE)
    .update({ cntrt_start_date: date })
    .eq("stff_cntrt_id", contractId)
    .is("cntrt_start_date", null);

  if (error) {
    console.error("staff-contracts.setContractStartDate:", error);
    throw new AppError(500, "No se pudo actualizar la fecha de inicio del contrato.");
  }
}

/** UPDATE: pone la fecha de hoy en `cntrt_end_date` del contrato indicado. */
export async function endContractById(contractId: number): Promise<void> {
  const { error } = await supabaseAdmin
    .from(TABLE)
    .update({ cntrt_end_date: todayInLima() })
    .eq("stff_cntrt_id", contractId);

  if (error) {
    console.error("staff-contracts.endContractById:", error);
    // 23514 = chk_contract_dates (la fecha de inicio es posterior a hoy)
    if (error.code === "23514") {
      throw new AppError(
        400,
        "La fecha de inicio del contrato es posterior a hoy; no se puede terminar.",
        "INVALID_CONTRACT_DATES",
      );
    }
    throw new AppError(500, "No se pudo actualizar la fecha de fin del contrato.");
  }
}

/**
 * UPDATE: pone la fecha de hoy en `cntrt_end_date` del contrato más reciente del personal.
 * Se usa al terminar el contrato. Si el personal no tiene contratos no hace nada.
 */
export async function endLatestContract(staffId: number): Promise<void> {
  const { data: latest, error: readError } = await supabaseAdmin
    .from(TABLE)
    .select("stff_cntrt_id")
    .eq("stff_id", staffId)
    .order("stff_cntrt_id", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (readError) {
    console.error("staff-contracts.endLatestContract(read):", readError);
    throw new AppError(500, "No se pudo consultar el contrato del personal.");
  }
  if (!latest) return;

  await endContractById(latest.stff_cntrt_id);
}
const CONTRACT_COLUMNS =
  "stff_cntrt_id, cntrt_start_date, cntrt_end_date, cntrt_status, cntrt_termination_reason, " +
  "cntrt_descount_afp, cntrt_descount_absence, cntrt_descount_delay, cntrt_descount_refreshment_delay";

/** El personal debe existir y ser de este customer. */
export async function assertStaffOfCustomer(custId: number, staffId: number): Promise<void> {
  const { data, error } = await supabaseAdmin
    .from("staffs")
    .select("stff_id")
    .eq("stff_id", staffId)
    .eq("cust_id", custId)
    .maybeSingle();

  if (error) {
    console.error("staff-contracts.assertStaffOfCustomer:", error);
    throw new AppError(500, "No se pudo consultar al personal.");
  }
  if (!data) throw new AppError(404, "El personal no existe.", "NOT_FOUND");
}

/** READ: todos los contratos del personal, el más reciente primero. */
export async function listContractsByStaff(custId: number, staffId: number): Promise<ContractItem[]> {
  await assertStaffOfCustomer(custId, staffId);

  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .select(CONTRACT_COLUMNS)
    .eq("stff_id", staffId)
    .order("stff_cntrt_id", { ascending: true });

  if (error) {
    console.error("staff-contracts.listContractsByStaff:", error);
    throw new AppError(500, "No se pudieron obtener los contratos.");
  }

  const items = ((data ?? []) as unknown as ContractDbRow[]).map((row, i): ContractItem => ({
    id: row.stff_cntrt_id,
    number: i + 1,
    start_date: row.cntrt_start_date,
    end_date: row.cntrt_end_date,
    status: row.cntrt_status,
    termination_reason: row.cntrt_termination_reason,
    afp: Number(row.cntrt_descount_afp ?? 0),
    discount_absence: row.cntrt_descount_absence !== false,
    discount_delay: row.cntrt_descount_delay !== false,
    discount_refreshment_delay: row.cntrt_descount_refreshment_delay !== false,
  }));

  return items.reverse();
}