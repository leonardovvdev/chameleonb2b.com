export type ContractStatus = "activo" | "inactivo";

export interface ContractDbRow {
  stff_cntrt_id: number;
  cntrt_start_date: string | null;
  cntrt_end_date: string | null;
  cntrt_status: ContractStatus;
  cntrt_termination_reason: string | null;
  cntrt_descount_afp: number | string;
  cntrt_descount_absence: boolean;
  cntrt_descount_delay: boolean;
  cntrt_descount_refreshment_delay: boolean;
}

export interface ContractItem {
  id: number;
  number: number;
  start_date: string | null;
  end_date: string | null;
  status: ContractStatus;
  termination_reason: string | null;
  afp: number;
  discount_absence: boolean;
  discount_delay: boolean;
  discount_refreshment_delay: boolean;
}