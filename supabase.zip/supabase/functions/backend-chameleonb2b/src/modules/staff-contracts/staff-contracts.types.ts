export interface StaffContract {
  stff_cntrt_id: number;
  stff_id: number;
  cntrt_start_creation: string;
  cntrt_start_date: string | null;
  cntrt_end_date: string | null;
  cntrt_status: 'activo' | 'inactivo';
  cntrt_description: string | null;
  cntrt_salary_amount: number;
  cntrt_discount_absence: boolean;
  cntrt_discount_delay: boolean;
  cntrt_discount_refreshment_delay: boolean;
  cntrt_termination_reason: 'Renuncia' | 'Despido' | 'Fin de contrato' | 'Mutuo acuerdo' | 'Otro' | null;
}
