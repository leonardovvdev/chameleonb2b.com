import { AppError, json } from "../../shared/http.ts";
import { getAccessContext } from "../staffs/staff.services.ts";
import {
  createIncident,
  getActorStaffId,
  listIncidentsByAttendance,
} from "./staff-discount-incidents.services.ts";

const MAX_DESCRIPTION_LENGTH = 200; // ajusta al tamaño real de stff_dscount_description
const MAX_AMOUNT = 99_999_999.99; // ajusta a la precisión real de stff_dscount_amount

const invalid = (message: string, code = "INVALID_BODY") => new AppError(400, message, code);

const toPositiveId = (raw: unknown): number => {
  const n = Number(raw);
  if (!Number.isSafeInteger(n) || n <= 0) throw invalid("El id del registro no es válido.", "INVALID_ID");
  return n;
};

/** GET /staff-discount-incidents?attId= → { items } */
export async function listIncidents(req: Request): Promise<Response> {
  const { custId } = await getAccessContext(req);
  const attId = toPositiveId(new URL(req.url).searchParams.get("attId"));
  return json({ items: await listIncidentsByAttendance(custId, attId) });
}

/** POST /staff-discount-incidents  body { attId, description, amount } → crea una incidencia "other" */
export async function createIncidentHandler(req: Request): Promise<Response> {
  const { custId } = await getAccessContext(req);

  const body = (await req.json().catch(() => null)) as
    | { attId?: unknown; description?: unknown; amount?: unknown }
    | null;
  if (!body) throw invalid("Los datos no son válidos.");

  const attId = toPositiveId(body.attId);

  const description = typeof body.description === "string" ? body.description.trim() : "";
  if (description === "") throw invalid("La descripción es obligatoria.", "INVALID_DESCRIPTION");
  if (description.length > MAX_DESCRIPTION_LENGTH) {
    throw invalid(`La descripción no puede superar ${MAX_DESCRIPTION_LENGTH} caracteres.`, "INVALID_DESCRIPTION");
  }

  const amount = Number(body.amount);
  if (!Number.isFinite(amount) || amount <= 0 || amount > MAX_AMOUNT) {
    throw invalid("El monto debe ser mayor a 0.", "INVALID_AMOUNT");
  }
  const rounded = Math.round(amount * 100) / 100;

  const actorStaffId = await getActorStaffId(req);
  return json(await createIncident(custId, actorStaffId, attId, description, rounded), 201);
}