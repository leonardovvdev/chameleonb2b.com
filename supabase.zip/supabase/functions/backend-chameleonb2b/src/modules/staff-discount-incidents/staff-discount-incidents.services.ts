import { AppError } from "../../shared/http.ts";
import { supabaseAdmin } from "../../shared/supabase.ts";
import { requireUser } from "../auth/auth.services.ts";
import { assertAttendanceOfCustomer } from "../attendance/attendance.services.ts";
import type {
  StaffDiscountIncidentItem,
  StaffDiscountIncidentType,
} from "./staff-discount-incidents.types.ts";

const TABLE = "staff_discount_incidents";

type IncidentDbRow = {
  stff_dscount_ncdnt_id: number;
  att_id: number;
  stff_id: number | null;
  stff_dscount_type: StaffDiscountIncidentType;
  stff_dscount_description: string;
  stff_dscount_amount: number | string;
  created_at?: string | null;
};

/**
 * Staff que está usando el sistema (el que queda anotado como autor de la incidencia).
 * Devuelve null si quien entra es el titular de la cuenta (customer), que no tiene fila en staffs.
 */
export async function getActorStaffId(req: Request): Promise<number | null> {
  const user = await requireUser(req);

  const { data, error } = await supabaseAdmin
    .from("staffs")
    .select("stff_id")
    .eq("stff_auth_id", user.id)
    .maybeSingle();

  if (error) {
    console.error("staff-discount-incidents.getActorStaffId:", error);
    throw new AppError(500, "No se pudo consultar tu cuenta.");
  }
  return (data as { stff_id: number } | null)?.stff_id ?? null;
}

/** Filas de la BD → lo que recibe el frontend (con el nombre de quien la registró). */
async function toItems(rows: IncidentDbRow[]): Promise<StaffDiscountIncidentItem[]> {
  const authorIds = [...new Set(rows.map((r) => r.stff_id).filter((id): id is number => id !== null))];
  const names = new Map<number, string>();

  if (authorIds.length > 0) {
    const { data, error } = await supabaseAdmin
      .from("staffs")
      .select("stff_id, stff_name, stff_lastname")
      .in("stff_id", authorIds);

    if (error) {
      console.error("staff-discount-incidents.toItems:", error);
      throw new AppError(500, "No se pudo obtener quién registró las incidencias.");
    }
    for (const s of (data ?? []) as { stff_id: number; stff_name: string; stff_lastname: string }[]) {
      names.set(s.stff_id, `${s.stff_name} ${s.stff_lastname}`.trim());
    }
  }

  return rows.map((row) => ({
    id: row.stff_dscount_ncdnt_id,
    att_id: row.att_id,
    created_by_staff_id: row.stff_id,
    created_by_name: row.stff_id !== null ? names.get(row.stff_id) ?? null : null,
    type: row.stff_dscount_type,
    description: row.stff_dscount_description,
    amount: Number(row.stff_dscount_amount),
    created_at: row.created_at ?? null,
  }));
}

/** READ: incidencias de un registro de asistencia (las más nuevas primero). */
export async function listIncidentsByAttendance(
  custId: number,
  attId: number,
): Promise<StaffDiscountIncidentItem[]> {
  await assertAttendanceOfCustomer(custId, attId);

  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .select("*")
    .eq("att_id", attId)
    .order("stff_dscount_ncdnt_id", { ascending: false });

  if (error) {
    console.error("staff-discount-incidents.listIncidentsByAttendance:", error);
    throw new AppError(500, "No se pudieron obtener las incidencias.");
  }
  return await toItems((data ?? []) as IncidentDbRow[]);
}

/** CREATE: nueva incidencia de tipo "other" para un registro de asistencia. */
export async function createIncident(
  custId: number,
  actorStaffId: number | null,
  attId: number,
  description: string,
  amount: number,
): Promise<StaffDiscountIncidentItem> {
  await assertAttendanceOfCustomer(custId, attId);

  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .insert({
      att_id: attId,
      stff_id: actorStaffId,
      stff_dscount_type: "other",
      stff_dscount_description: description,
      stff_dscount_amount: amount,
    })
    .select("*")
    .single();

  if (error || !data) {
    console.error("staff-discount-incidents.createIncident:", error);
    throw new AppError(500, "No se pudo crear la incidencia.");
  }
  const [item] = await toItems([data as IncidentDbRow]);
  return item;
}