/** Tipos permitidos para una incidencia con descuento. */
export type StaffDiscountIncidentType =
  | 'delay'
  | 'absence'
  | 'other';

/** Fila tal como la devuelve PostgREST. */
export interface StaffDiscountIncidentRow {
  stff_dscount_ncdnt_id: number;
  att_id: number;
  stff_id: number | null;
  stff_dscount_type: StaffDiscountIncidentType;
  stff_dscount_description: string;
  stff_dscount_amount: number;
}

/** Datos necesarios para crear una incidencia con descuento. */
export interface CreateStaffDiscountIncidentDto {
  att_id: number;
  stff_id?: number | null;
  stff_dscount_type: StaffDiscountIncidentType;
  stff_dscount_description: string;
  stff_dscount_amount: number;
}

/** Datos permitidos para actualizar una incidencia con descuento. */
export interface UpdateStaffDiscountIncidentDto {
  stff_id?: number | null;
  stff_dscount_type?: StaffDiscountIncidentType;
  stff_dscount_description?: string;
  stff_dscount_amount?: number;
}

/** Lo que recibe el frontend (GET / POST /staff-discount-incidents). */
export interface StaffDiscountIncidentItem {
  id: number;
  att_id: number;
  /** Staff que la registró (null si la registró el titular de la cuenta o el staff ya no existe). */
  created_by_staff_id: number | null;
  created_by_name: string | null;
  type: StaffDiscountIncidentType;
  description: string;
  amount: number;
  /** Solo si la tabla tiene una columna created_at. */
  created_at: string | null;
}