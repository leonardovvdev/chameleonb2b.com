export interface StaffDiscountIncident {
  stff_dscount_ncdnt_id: number;
  att_id: number;
  stff_id: number | null;
  stff_dscount_description: string;
  stff_dscount_amount: number;
}
