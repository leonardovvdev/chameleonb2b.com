export interface StaffNonWorkingDay {
  stff_nn_wrkng_day_id: number;
  stff_nn_wrkng_day_type: 'fixed' | 'flexible';
  stff_nn_wrkng_day_monday: boolean | null;
  stff_nn_wrkng_day_tuesday: boolean | null;
  stff_nn_wrkng_day_wednesday: boolean | null;
  stff_nn_wrkng_day_thursday: boolean | null;
  stff_nn_wrkng_day_friday: boolean | null;
  stff_nn_wrkng_day_saturday: boolean | null;
  stff_nn_wrkng_day_sunday: boolean | null;
  stff_nn_wrkng_day_number_days: number | null;
  stff_nn_wrkng_day_active: boolean;
}
