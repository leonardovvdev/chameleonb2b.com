export interface StaffRefreshment {
  stff_rfrshmnth_id: number;
  stff_rfrshmnth_type: 'fixed' | 'flexible' | 'free';
  stff_rfrshmnth_start: string | null;
  stff_rfrshmnth_end: string | null;
  stff_rfrshmnth_minutes: number | null;
  stff_rfrshmnth_active: boolean;
}
