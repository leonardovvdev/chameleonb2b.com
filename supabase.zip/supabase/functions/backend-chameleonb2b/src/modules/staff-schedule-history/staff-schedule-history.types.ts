export interface StaffScheduleHistory {
  stff_schdl_hstry_id: number;

  stff_schdl_id: number;
  stff_cntrt_id: number;

  schdl_hstry_start: string;
  schdl_hstry_end: string | null;
}

export interface StaffScheduleHistoryInsert {
  stff_schdl_id: number;
  stff_cntrt_id: number;

  schdl_hstry_start: string;
  schdl_hstry_end?: string | null;
}

export interface StaffScheduleHistoryUpdate {
  stff_schdl_id?: number;
  stff_cntrt_id?: number;

  schdl_hstry_start?: string;
  schdl_hstry_end?: string | null;
}