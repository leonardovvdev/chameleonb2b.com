-- =========================================================
-- HORARIO personalizado para el personal de cada cliente 
-- =========================================================
CREATE TABLE staff_schedules (
    stff_schdl_id               BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,

    stff_schdl_nombre           TEXT NOT NULL DEFAULT 'general',
    stff_schdl_type             TEXT NOT NULL CHECK (stff_schdl_type IN ('fixed', 'flexible', 'free')),

    stff_schdl_start            TIME,
    stff_schdl_start_tolerance  SMALLINT NOT NULL DEFAULT 0 CHECK (stff_schdl_start_tolerance >= 0),
    stff_schdl_end              TIME,
    stff_schdl_required_minutes INTEGER CHECK (stff_schdl_required_minutes > 0),

    stff_rfrshmnth_id           BIGINT REFERENCES staff_refreshmenths(stff_rfrshmnth_id) ON DELETE SET NULL,
    stff_nn_wrkng_day_id        BIGINT REFERENCES staff_non_working_days(stff_nn_wrkng_day_id) ON DELETE SET NULL,
    cust_id                     BIGINT NOT NULL REFERENCES customers(cust_id) ON DELETE CASCADE,

    stff_schdl_active           BOOLEAN NOT NULL DEFAULT TRUE,

    CONSTRAINT chk_schedule_type CHECK (
        (
            stff_schdl_type = 'fixed'
            AND stff_schdl_start IS NOT NULL
            AND stff_schdl_end IS NOT NULL
            AND stff_schdl_end > stff_schdl_start
            AND stff_schdl_required_minutes IS NULL
        )
        OR
        (
            stff_schdl_type = 'flexible'
            AND stff_schdl_start IS NULL
            AND stff_schdl_end IS NULL
            AND stff_schdl_required_minutes IS NOT NULL
        )
        OR
        (
            stff_schdl_type = 'free'
            AND stff_schdl_start IS NULL
            AND stff_schdl_end IS NULL
            AND stff_schdl_required_minutes IS NULL
        )
    )
);