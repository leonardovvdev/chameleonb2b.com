export interface StaffSchedule {
  stff_schdl_id: number;
  stff_schdl_type: 'fixed' | 'flexible' | 'free';
  stff_schdl_start: string | null;
  stff_schdl_start_tolerance: number;
  stff_schdl_end: string | null;
  stff_schdl_required_minutes: number | null;
  stff_rfrshmnth_id: number | null;
  stff_nn_wrkng_day_id: number | null;
  cust_id: number;
  stff_schdl_active: boolean;
}
