import { endLatestContract } from "../staff-contracts/staff-contracts.services.ts";
import { AppError, json } from "../../shared/http.ts";
import {
  assertCanEndContract,
  createStaff,
  getAccessContext,
  getStaffDetail,
  listOrgChart,
  listStaffs,
  listSupervisors,
  MAX_IMAGE_BYTES,
  renewStaffContract,
  setStaffActive,
  updateStaff,
  uploadStaffPhoto,
} from "./staff.services.ts";

import type {
  CreateStaffInput,
  DiscountInput,
  DiscountUnit,
  NonWorkingDaysInput,
  RefreshmentInput,
  ScheduleInput,
  ScheduleType,
  SalaryType,
  EditStaffInput,
  StaffListFilters,
  StaffStatusFilter,
  UpdateStaffInput,
} from "./staff.types.ts";

const DISCOUNT_UNITS: DiscountUnit[] = ["per_minute", "per_hour", "fixed"];
const MAX_NAME_LENGTH = 200; // VARCHAR(200) en la tabla
const MAX_PAGE_SIZE = 100;
const MAX_SEARCH_LENGTH = 100;

const TIME_REGEX = /^([01]\d|2[0-3]):[0-5]\d$/;
const DATE_REGEX = /^\d{4}-\d{2}-\d{2}$/;
const SCHEDULE_TYPES: ScheduleType[] = ["fixed", "flexible", "free"];
const SALARY_TYPES: SalaryType[] = ["Monthly", "Weekly", "Daily"];

const invalid = (message: string, code = "INVALID_BODY") => new AppError(400, message, code);

/* ───────────────────────── Lectura de datos ───────────────────────── */

type Obj = Record<string, unknown>;

async function readBody(req: Request): Promise<Obj> {
  const body = await req.json().catch(() => null);
  if (!body || typeof body !== "object" || Array.isArray(body)) {
    throw invalid("El cuerpo de la petición no es válido.");
  }
  return body as Obj;
}

/** Lee y valida ?id=123 de la URL. */
function parseId(req: Request): number {
  const raw = new URL(req.url).searchParams.get("id");
  const id = Number(raw);
  if (!raw || !Number.isSafeInteger(id) || id <= 0) {
    throw invalid("El id del personal no es válido.", "INVALID_ID");
  }
  return id;
}

function asObject(value: unknown, label: string): Obj {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw invalid(`Falta ${label}.`);
  }
  return value as Obj;
}

function asPositiveInt(value: unknown, label: string): number {
  const n = Number(value);
  if (value === null || value === "" || !Number.isSafeInteger(n) || n <= 0) {
    throw invalid(`${label} no es válido.`);
  }
  return n;
}

function asOptionalPositiveInt(value: unknown, label: string): number | null {
  return value === null || value === undefined || value === "" ? null : asPositiveInt(value, label);
}

function asTime(value: unknown, label: string): string {
  if (typeof value !== "string" || !TIME_REGEX.test(value)) throw invalid(`${label} no es válida.`);
  return value;
}

function asOptionalDate(value: unknown, label: string): string | null {
  if (value === null || value === undefined || value === "") return null;
  if (typeof value !== "string" || !DATE_REGEX.test(value) || Number.isNaN(Date.parse(value))) {
    throw invalid(`${label} no es válida.`);
  }
  return value;
}

/* ───────────────────────── Validaciones ───────────────────────── */

/** Datos básicos (los comparten crear y editar). */
function parseBasics(body: Obj): UpdateStaffInput {
  const name = typeof body.name === "string" ? body.name.trim() : "";
  const lastname = typeof body.lastname === "string" ? body.lastname.trim() : "";
  const dni = typeof body.dni === "string" ? body.dni.trim() : "";
  const phone = typeof body.phone === "string" ? body.phone.trim() : "";

  if (!name) throw invalid("El nombre es obligatorio.", "NAME_REQUIRED");
  if (!lastname) throw invalid("El apellido es obligatorio.", "LASTNAME_REQUIRED");
  if (name.length > MAX_NAME_LENGTH || lastname.length > MAX_NAME_LENGTH) {
    throw invalid(`El nombre y el apellido no pueden superar los ${MAX_NAME_LENGTH} caracteres.`, "NAME_TOO_LONG");
  }
  if (!/^\d{8}$/.test(dni)) throw invalid("El DNI debe tener exactamente 8 dígitos.", "INVALID_DNI");
  if (phone !== "" && !/^\d{9}$/.test(phone)) {
    throw invalid("El teléfono debe tener exactamente 9 dígitos.", "INVALID_PHONE");
  }

  return {
    name,
    lastname,
    dni,
    phone: phone === "" ? null : phone,
    jobPositionId: asPositiveInt(body.jobPositionId, "El cargo"),
    roleId: asOptionalPositiveInt(body.roleId, "El rol"),
    supervisorId: asOptionalPositiveInt(body.supervisorId, "El jefe directo"),
  };
}

/** Datos básicos + acceso al sistema (editar). */
function parseEditInput(body: Obj): EditStaffInput {
  const basics = parseBasics(body);

  if (typeof body.withAccess !== "boolean") throw invalid("El acceso al sistema no es válido.");
  const withAccess = body.withAccess;

  const password = typeof body.password === "string" ? body.password : "";
  if (withAccess && password !== "" && password.length < 6) {
    throw invalid("La contraseña debe tener al menos 6 caracteres.", "INVALID_PASSWORD");
  }

  return { ...basics, withAccess, password: withAccess && password !== "" ? password : null };
}

function parseSchedule(value: unknown): ScheduleInput {
  const s = asObject(value, "el horario");
  if (!SCHEDULE_TYPES.includes(s.type as ScheduleType)) throw invalid("El tipo de horario no es válido.");
  const type = s.type as ScheduleType;

  if (type === "fixed") {
    const start = asTime(s.start, "La hora de ingreso");
    const end = asTime(s.end, "La hora de salida");
    if (end <= start) throw invalid("La salida debe ser posterior al ingreso.");

    const tolerance = Number(s.toleranceMinutes ?? 0);
    if (!Number.isInteger(tolerance) || tolerance < 0 || tolerance > 1440) {
      throw invalid("La tolerancia no es válida.");
    }
    return { type, start, end, toleranceMinutes: tolerance, requiredMinutes: null };
  }

  if (type === "flexible") {
    const minutes = Number(s.requiredMinutes);
    if (!Number.isInteger(minutes) || minutes < 1 || minutes > 1440) {
      throw invalid("Las horas a cumplir deben estar entre 1 y 24.");
    }
    return { type, start: null, end: null, toleranceMinutes: 0, requiredMinutes: minutes };
  }

  return { type, start: null, end: null, toleranceMinutes: 0, requiredMinutes: null };
}

function parseRefreshment(value: unknown): RefreshmentInput {
  const r = asObject(value, "el refrigerio");
  if (!SCHEDULE_TYPES.includes(r.type as ScheduleType)) throw invalid("El tipo de refrigerio no es válido.");
  const type = r.type as ScheduleType;

  if (type === "fixed") {
    const start = asTime(r.start, "El inicio del refrigerio");
    const end = asTime(r.end, "El fin del refrigerio");
    if (end <= start) throw invalid("El fin del refrigerio debe ser posterior al inicio.");
    return { type, start, end, minutes: null };
  }

  if (type === "flexible") {
    const minutes = Number(r.minutes);
    if (!Number.isInteger(minutes) || minutes < 1 || minutes > 240) {
      throw invalid("El refrigerio debe durar entre 1 y 240 minutos.");
    }
    return { type, start: null, end: null, minutes };
  }

  return { type, start: null, end: null, minutes: null };
}

function parseDiscount(value: unknown): DiscountInput | null {
  if (value === null || value === undefined) return null;
  const d = asObject(value, "los descuentos");

  const money = (v: unknown, label: string): number => {
    const n = Number(v);
    if (v === null || v === "" || !Number.isFinite(n) || n < 0 || n > 9_999_999_999.99) {
      throw invalid(`${label} no es válido.`, "INVALID_DISCOUNT");
    }
    return Math.round(n * 100) / 100;
  };
  const unit = (v: unknown, label: string): DiscountUnit => {
    if (!DISCOUNT_UNITS.includes(v as DiscountUnit)) throw invalid(`${label} no es válido.`, "INVALID_DISCOUNT");
    return v as DiscountUnit;
  };

  return {
    absenceAmount: money(d.absenceAmount, "El descuento por falta"),
    delayType: unit(d.delayType, "El tipo de descuento por tardanza"),
    delayAmount: money(d.delayAmount, "El descuento por tardanza"),
    refreshmentDelayType: unit(d.refreshmentDelayType, "El tipo de descuento por demora"),
    refreshmentDelayAmount: money(d.refreshmentDelayAmount, "El descuento por demora"),
  };
}

function parseNonWorkingDays(value: unknown): NonWorkingDaysInput {
  if (value === null || value === undefined) return null;
  const d = asObject(value, "los días no laborables");

  if (d.type === "fixed") {
    const days = d.days;
    if (!Array.isArray(days) || days.length !== 7 || !days.every((x) => typeof x === "boolean")) {
      throw invalid("Los días no laborables no son válidos.");
    }
    if (!days.some(Boolean)) throw invalid("Selecciona al menos un día no laborable.");
    return { type: "fixed", days: days as boolean[] };
  }

  if (d.type === "flexible") {
    const numberDays = Number(d.numberDays);
    if (!Number.isInteger(numberDays) || numberDays < 1 || numberDays > 6) {
      throw invalid("Los días no laborables a la semana deben estar entre 1 y 6.");
    }
    return { type: "flexible", numberDays };
  }

  throw invalid("El tipo de días no laborables no es válido.");
}

/**
 * Crear y editar reciben lo mismo. Al editar (`passwordOptional`) la contraseña puede ir vacía
 * para conservar la actual (updateStaff exige una solo si aún no tiene usuario de acceso).
 */
function parseCreateInput(body: Obj, passwordOptional = false): CreateStaffInput {
  const basics = parseBasics(body);

  const withAccess = body.withAccess === true;
  const password = typeof body.password === "string" ? body.password : "";
  if (withAccess && password.length < 6 && !(passwordOptional && password === "")) {
    throw invalid("La contraseña debe tener al menos 6 caracteres.", "INVALID_PASSWORD");
  }

  const salary = asObject(body.salary, "el sueldo");
  if (!SALARY_TYPES.includes(salary.type as SalaryType)) throw invalid("La frecuencia de pago no es válida.");
  const amount = Number(salary.amount);
  if (!Number.isFinite(amount) || amount <= 0 || amount > 9_999_999_999.99) {
    throw invalid("El sueldo no es válido.", "INVALID_SALARY");
  }

  const contract = asObject(body.contract, "el contrato");
  const startDate = asOptionalDate(contract.startDate, "La fecha de inicio");
  const endDate = asOptionalDate(contract.endDate, "La fecha de fin");
  if (startDate && endDate && endDate < startDate) {
    throw invalid("La fecha final no puede ser anterior a la inicial.");
  }

  return {
    ...basics,
    withAccess,
    password: withAccess && password !== "" ? password : null,
    schedule: parseSchedule(body.schedule),
    refreshment: parseRefreshment(body.refreshment),
    contract: { startDate, endDate },
    discount: parseDiscount(body.discount),
    nonWorkingDays: parseNonWorkingDays(body.nonWorkingDays),
    salary: { type: salary.type as SalaryType, amount: Math.round(amount * 100) / 100 },
  };
}

function parseListFilters(req: Request): StaffListFilters {
  const params = new URL(req.url).searchParams;

  const page = Math.max(1, Math.floor(Number(params.get("page"))) || 1);
  const pageSize = Math.min(MAX_PAGE_SIZE, Math.max(1, Math.floor(Number(params.get("pageSize"))) || 10));

  const optionalId = (key: string): number | null => {
    const raw = params.get(key);
    if (!raw) return null;
    const n = Number(raw);
    if (!Number.isSafeInteger(n) || n <= 0) throw invalid("Los filtros no son válidos.", "INVALID_FILTER");
    return n;
  };

  const estado = params.get("estado") ?? "";
  if (estado !== "" && estado !== "ACTIVO" && estado !== "INACTIVO") {
    throw invalid("El filtro de estado no es válido.", "INVALID_FILTER");
  }

  return {
    page,
    pageSize,
    search: (params.get("search") ?? "").trim().slice(0, MAX_SEARCH_LENGTH),
    cargoId: optionalId("cargoId"),
    rolId: optionalId("rolId"),
    estado: estado as StaffStatusFilter,
  };
}

/* ───────────────────────── Handlers ───────────────────────── */

/** GET /staffs?page=1&pageSize=10&search=&cargoId=&rolId=&estado= → { items, count } */
export async function listStaff(req: Request): Promise<Response> {
  const { custId, bucketName } = await getAccessContext(req);
  const result = await listStaffs(custId, bucketName, parseListFilters(req));
  return json(result);
}

/** GET /staffs/supervisors → { items } */
export async function getSupervisors(req: Request): Promise<Response> {
  const { custId, bucketName } = await getAccessContext(req);
  return json({ items: await listSupervisors(custId, bucketName) });
}

/** GET /staffs/org-chart → { items } */
export async function getOrgChart(req: Request): Promise<Response> {
  const { custId, bucketName } = await getAccessContext(req);
  return json({ items: await listOrgChart(custId, bucketName) });
}

/** POST /staffs → crea el personal con su horario, refrigerio, días no laborables, contrato y sueldo. */
export async function createStaffHandler(req: Request): Promise<Response> {
  const { custId } = await getAccessContext(req);
  const input = parseCreateInput(await readBody(req));
  return json(await createStaff(custId, input), 201);
}

/** GET /staffs/detail?id=123 → todo lo del personal para editarlo (misma forma que POST /staffs). */
export async function getStaffDetailHandler(req: Request): Promise<Response> {
  const { custId, bucketName } = await getAccessContext(req);
  const id = parseId(req);
  return json(await getStaffDetail(id, custId, bucketName));
}

/** PUT /staffs/contract?id=123 → edita todo, ACTIVA al personal y crea un nuevo contrato. */
export async function renewStaffContractHandler(req: Request): Promise<Response> {
  const { custId } = await getAccessContext(req);
  const id = parseId(req);
  const input = parseCreateInput(await readBody(req), true);
  return json(await renewStaffContract(id, custId, input));
}

/** PATCH /staffs?id=123 → edita los datos básicos y el acceso al sistema. */
export async function updateStaffHandler(req: Request): Promise<Response> {
  const { custId } = await getAccessContext(req);
  const id = parseId(req);
  const input = parseEditInput(await readBody(req));
  await updateStaff(id, custId, input);
  return json({ id });
}

/** PATCH /staffs/active?id=123  body { active: boolean } */
export async function setActiveHandler(req: Request): Promise<Response> {
  const id = parseId(req);
  const body = await readBody(req);
  if (typeof body.active !== "boolean") throw invalid("El estado no es válido.");

  // Terminar contrato (active = false): solo el customer o un staff con rol Administrador.
  const custId = body.active ? (await getAccessContext(req)).custId : await assertCanEndContract(req);
  await setStaffActive(id, custId, body.active); // valida que el personal sea del customer

  if (!body.active) {
    try {
      await endLatestContract(id);
    } catch (err) {
      // Si no se pudo cerrar el contrato, se deja al personal como estaba.
      await setStaffActive(id, custId, true).catch((e) =>
        console.error("staffs.setActiveHandler(rollback):", e)
      );
      throw err;
    }
  }
  return json({ id, active: body.active });
}

/** POST /staffs/photo?id=123  (multipart/form-data con el campo "file") */
export async function uploadPhotoHandler(req: Request): Promise<Response> {
  const { custId, bucketName } = await getAccessContext(req);
  const id = parseId(req);

  const declared = Number(req.headers.get("content-length") ?? 0);
  if (declared > MAX_IMAGE_BYTES + 1024 * 100) {
    throw new AppError(400, "La imagen no puede pesar más de 5 MB.", "IMAGE_TOO_LARGE");
  }

  const form = await req.formData().catch(() => null);
  const file = form?.get("file");
  if (!(file instanceof File)) throw invalid("No se recibió ninguna imagen.", "FILE_REQUIRED");

  return json(await uploadStaffPhoto(id, custId, bucketName, file));
}