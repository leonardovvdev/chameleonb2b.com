import { AppError } from "../../shared/http.ts";
import { supabaseAdmin } from "../../shared/supabase.ts";
import { requireUser } from "../auth/auth.services.ts";
import { createSignedUrls } from "../buckets/buckets.controller.ts";
import { findByAuthId, findByCustId } from "../customers/customers.services.ts";
import {
  endContractById,
  getLatestContract,
  insertContract,
} from "../staff-contracts/staff-contracts.services.ts";
import type {
  AccessContext,
  CreateStaffInput,
  DiscountInput,
  EditStaffInput,
  OrgChartStaff,
  OrgChartStaffRow,
  ScheduleType,
  StaffAccessRow,
  StaffDetail,
  StaffDetailRow,
  StaffListFilters,
  StaffListItem,
  StaffListResult,
  StaffListRow,
  SupervisorItem,
  UpdateStaffInput,
} from "./staff.types.ts";

const TABLE = "staffs";

/** Carpeta dentro del bucket del customer donde están las fotos del personal. */
const STAFF_IMAGES_FOLDER = "gestion_empresarial/imagen_staffs";

/** Columnas de la tabla con el nombre que usa el frontend. */
const ORG_CHART_COLUMNS =
  "id:stff_id, supervisor_id:stff_supervisor_id, name:stff_name, lastname:stff_lastname, img:stff_link_img, job_position:customer_job_positions(name:cust_jb_pstn_name)";

const LIST_COLUMNS = `
  stff_id, stff_name, stff_lastname, stff_dni, stff_phone, stff_link_img,
  stff_active, stff_access_system, stff_supervisor_id, cust_jb_pstn_id, cust_role_id,
  job_position:customer_job_positions(name:cust_jb_pstn_name),
  role:customer_roles(name:cust_role_name)
`;

/** Relación muchos-a-uno: llega como objeto (se acepta arreglo por seguridad). */
function embeddedName(value: { name: string | null } | { name: string | null }[] | null): string | null {
  const one = Array.isArray(value) ? value[0] : value;
  return one?.name ?? null;
}

const imagePath = (link: string) => `${STAFF_IMAGES_FOLDER}/${link}`;

/** URLs firmadas de varias fotos en una sola llamada: nombre de archivo → URL. */
export async function signedImageUrls(bucketName: string, links: (string | null)[]): Promise<Map<string, string>> {
  const unique = [...new Set(links.filter((l): l is string => !!l))];
  const byPath = await createSignedUrls(bucketName, unique.map(imagePath));
  const byLink = new Map<string, string>();
  for (const link of unique) {
    const url = byPath.get(imagePath(link));
    if (url) byLink.set(link, url);
  }
  return byLink;
}

/* ───────────────────────── Acceso ───────────────────────── */

/** Staff ligado a un usuario de Supabase Auth, o null si no existe. */
async function findStaffByAuthId(authId: string): Promise<StaffAccessRow | null> {
  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .select("stff_id, cust_id, stff_active, stff_access_system")
    .eq("stff_auth_id", authId)
    .maybeSingle();

  if (error) {
    console.error("staffs.findStaffByAuthId:", error);
    throw new AppError(500, "No se pudo consultar tu cuenta.");
  }
  return (data as StaffAccessRow | null) ?? null;
}

/**
 * Quién puede entrar y de qué cliente se leen los datos (siempre sale del JWT):
 *   - el customer (cust_auth_id) si su cuenta está activa;
 *   - un staff (stff_auth_id) solo si stff_active Y stff_access_system son true
 *     y el customer al que pertenece está activo.
 */
export async function getAccessContext(req: Request): Promise<AccessContext> {
  const user = await requireUser(req);

  // 1) ¿Es el customer?
  const customer = await findByAuthId(user.id);
  if (customer) {
    if (!customer.cust_is_active) {
      throw new AppError(403, "Tu cuenta está desactivada. Contacta a soporte.");
    }
    return { custId: customer.cust_id, bucketName: String(customer.cust_name_bucket) };
  }

  // 2) ¿Es un staff?
  const staff = await findStaffByAuthId(user.id);
  if (!staff) {
    throw new AppError(
      404,
      "Esta cuenta no está registrada. Crea tu cuenta con Google primero.",
      "CUSTOMER_NOT_FOUND",
    );
  }
  if (!staff.stff_active) {
    throw new AppError(403, "Tu cuenta está desactivada. Contacta a tu administrador.", "STAFF_INACTIVE");
  }
  if (!staff.stff_access_system) {
    throw new AppError(403, "No tienes acceso al sistema.", "STAFF_NO_ACCESS");
  }

  const owner = await findByCustId(staff.cust_id);
  if (!owner || !owner.cust_is_active) {
    throw new AppError(403, "La cuenta de tu empresa está desactivada.", "CUSTOMER_INACTIVE");
  }
  return { custId: owner.cust_id, bucketName: String(owner.cust_name_bucket) };
}

/* ───────────────────────── Terminar contrato ───────────────────────── */

const ADMIN_ROLE = "administrador";

const normalizeRole = (name: string) =>
  name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim().toLowerCase();

/**
 * Quién puede terminar un contrato (desactivar al personal):
 *   - el customer (titular de la cuenta), o
 *   - un staff activo, con acceso al sistema y rol "Administrador".
 * Devuelve el cust_id al que pertenece quien hace la petición.
 */
export async function assertCanEndContract(req: Request): Promise<number> {
  const user = await requireUser(req);

  const customer = await findByAuthId(user.id);
  if (customer) {
    if (!customer.cust_is_active) {
      throw new AppError(403, "Tu cuenta está desactivada. Contacta a soporte.");
    }
    return customer.cust_id;
  }

  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .select("cust_id, stff_active, stff_access_system, role:customer_roles(name:cust_role_name)")
    .eq("stff_auth_id", user.id)
    .maybeSingle();

  if (error) {
    console.error("staffs.assertCanEndContract:", error);
    throw new AppError(500, "No se pudo verificar tus permisos.");
  }
  if (!data) {
    throw new AppError(
      404,
      "Esta cuenta no está registrada. Crea tu cuenta con Google primero.",
      "CUSTOMER_NOT_FOUND",
    );
  }

  const row = data as unknown as {
    cust_id: number;
    stff_active: boolean;
    stff_access_system: boolean;
    role: { name: string | null } | { name: string | null }[] | null;
  };

  if (!row.stff_active || !row.stff_access_system) {
    throw new AppError(403, "No tienes acceso al sistema.", "STAFF_NO_ACCESS");
  }

  const roleName = embeddedName(row.role);
  if (!roleName || normalizeRole(roleName) !== ADMIN_ROLE) {
    throw new AppError(
      403,
      "Solo un Administrador o el titular de la cuenta puede terminar un contrato.",
      "NOT_ALLOWED",
    );
  }

  const owner = await findByCustId(row.cust_id);
  if (!owner || !owner.cust_is_active) {
    throw new AppError(403, "La cuenta de tu empresa está desactivada.", "CUSTOMER_INACTIVE");
  }
  return owner.cust_id;
}

/* ───────────────────────── Organigrama ───────────────────────── */

/** READ: personal activo del customer con su cargo y la URL de su foto. */
export async function listOrgChart(custId: number, bucketName: string): Promise<OrgChartStaff[]> {
  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .select(ORG_CHART_COLUMNS)
    .eq("cust_id", custId)
    .eq("stff_active", true)
    .order("stff_id", { ascending: true });

  if (error) {
    console.error("staffs.listOrgChart:", error);
    throw new AppError(500, "No se pudo obtener el organigrama.");
  }

  const rows = (data ?? []) as unknown as OrgChartStaffRow[];
  const urls = await signedImageUrls(bucketName, rows.map((r) => r.img));

  return rows.map((row) => ({
    id: row.id,
    supervisor_id: row.supervisor_id,
    name: row.name,
    lastname: row.lastname,
    img_url: row.img ? urls.get(row.img) ?? null : null,
    job_position: embeddedName(row.job_position),
  }));
}

/* ───────────────────────── Lista paginada ───────────────────────── */

/** Quita lo que rompería la sintaxis de `.or()` de PostgREST y los comodines de ilike. */
export const sanitizeSearchWord = (word: string) => word.replace(/[,()%*_\\"']/g, "");

/** READ: una página del personal del customer, con filtros. */
export async function listStaffs(
  custId: number,
  bucketName: string,
  filters: StaffListFilters,
): Promise<StaffListResult> {
  let query = supabaseAdmin
    .from(TABLE)
    .select(LIST_COLUMNS, { count: "exact" })
    .eq("cust_id", custId);

  // Cada palabra debe aparecer en el nombre, el apellido o el DNI.
  const words = filters.search.split(/\s+/).map(sanitizeSearchWord).filter(Boolean);
  for (const word of words) {
    query = query.or(
      `stff_name.ilike.%${word}%,stff_lastname.ilike.%${word}%,stff_dni.ilike.%${word}%`,
    );
  }

  if (filters.cargoId !== null) query = query.eq("cust_jb_pstn_id", filters.cargoId);
  if (filters.rolId !== null) query = query.eq("cust_role_id", filters.rolId);
  if (filters.estado === "ACTIVO") query = query.eq("stff_active", true);
  if (filters.estado === "INACTIVO") query = query.eq("stff_active", false);

  const from = (filters.page - 1) * filters.pageSize;
  const to = from + filters.pageSize - 1;

  const { data, error, count } = await query
    .order("stff_name", { ascending: true })
    .order("stff_lastname", { ascending: true })
    .order("stff_id", { ascending: true })
    .range(from, to);

  if (error) {
    console.error("staffs.listStaffs:", error);
    throw new AppError(500, "No se pudo obtener la lista de personal.");
  }

  const rows = (data ?? []) as unknown as StaffListRow[];
  const urls = await signedImageUrls(bucketName, rows.map((r) => r.stff_link_img));

  const items: StaffListItem[] = rows.map((row) => ({
    stff_id: row.stff_id,
    stff_name: row.stff_name,
    stff_lastname: row.stff_lastname,
    stff_dni: row.stff_dni,
    stff_phone: row.stff_phone,
    stff_link_img: row.stff_link_img,
    stff_active: row.stff_active,
    stff_access_system: row.stff_access_system,
    stff_supervisor_id: row.stff_supervisor_id,
    cust_jb_pstn_id: row.cust_jb_pstn_id,
    cust_role_id: row.cust_role_id,
    job_position_name: embeddedName(row.job_position),
    role_name: embeddedName(row.role),
    img_url: row.stff_link_img ? urls.get(row.stff_link_img) ?? null : null,
  }));

  return { items, count: count ?? 0 };
}

/* ───────────────────────── Supervisores ───────────────────────── */

/** READ: todo el personal del customer, del que tiene más subordinados al que no tiene ninguno. */
export async function listSupervisors(custId: number, bucketName: string): Promise<SupervisorItem[]> {
  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .select(
      "id:stff_id, supervisor_id:stff_supervisor_id, name:stff_name, lastname:stff_lastname, img:stff_link_img, job_position:customer_job_positions(name:cust_jb_pstn_name)",
    )
    .eq("cust_id", custId);

  if (error) {
    console.error("staffs.listSupervisors:", error);
    throw new AppError(500, "No se pudo obtener la lista de supervisores.");
  }

  const rows = (data ?? []) as unknown as OrgChartStaffRow[];

  const subordinates = new Map<number, number>();
  for (const row of rows) {
    if (row.supervisor_id !== null) {
      subordinates.set(row.supervisor_id, (subordinates.get(row.supervisor_id) ?? 0) + 1);
    }
  }

  const urls = await signedImageUrls(bucketName, rows.map((r) => r.img));

  return rows
    .map((row) => ({
      id: row.id,
      name: row.name,
      lastname: row.lastname,
      img_url: row.img ? urls.get(row.img) ?? null : null,
      job_position: embeddedName(row.job_position),
      subordinates: subordinates.get(row.id) ?? 0,
    }))
    .sort(
      (a, b) =>
        b.subordinates - a.subordinates ||
        `${a.name} ${a.lastname}`.localeCompare(`${b.name} ${b.lastname}`, "es"),
    );
}

/* ───────────────────────── Validaciones de pertenencia ───────────────────────── */

/** Comprueba que la fila exista Y sea de este customer (los ids llegan del cliente). */
async function assertOwned(
  table: string,
  idColumn: string,
  id: number,
  custId: number,
  message: string,
): Promise<void> {
  const { data, error } = await supabaseAdmin
    .from(table)
    .select(idColumn)
    .eq(idColumn, id)
    .eq("cust_id", custId)
    .maybeSingle();

  if (error) {
    console.error(`staffs.assertOwned(${table}):`, error);
    throw new AppError(500, "No se pudo validar la información enviada.");
  }
  if (!data) throw new AppError(400, message, "INVALID_REFERENCE");
}

/** Valida cargo, rol y jefe. `staffId` = el personal que se edita (null al crear). */
async function assertReferences(
  custId: number,
  input: UpdateStaffInput,
  staffId: number | null,
): Promise<void> {
  await assertOwned("customer_job_positions", "cust_jb_pstn_id", input.jobPositionId, custId, "El cargo no existe.");

  if (input.roleId !== null) {
    await assertOwned("customer_roles", "cust_role_id", input.roleId, custId, "El rol no existe.");
  }

  if (input.supervisorId === null) return;

  if (staffId !== null && input.supervisorId === staffId) {
    throw new AppError(400, "Una persona no puede ser su propio jefe.", "INVALID_SUPERVISOR");
  }
  await assertOwned("staffs", "stff_id", input.supervisorId, custId, "El jefe directo no existe.");

  // Al editar: el nuevo jefe no puede ser (directa o indirectamente) un subordinado de esta persona.
  if (staffId !== null) {
    const { data, error } = await supabaseAdmin
      .from(TABLE)
      .select("stff_id, stff_supervisor_id")
      .eq("cust_id", custId);

    if (error) {
      console.error("staffs.assertReferences:", error);
      throw new AppError(500, "No se pudo validar el jefe directo.");
    }

    const parentOf = new Map<number, number | null>(
      (data ?? []).map((r: { stff_id: number; stff_supervisor_id: number | null }) => [
        r.stff_id,
        r.stff_supervisor_id,
      ]),
    );

    const seen = new Set<number>();
    for (
      let current: number | null | undefined = input.supervisorId;
      current != null && !seen.has(current);
      current = parentOf.get(current)
    ) {
      if (current === staffId) {
        throw new AppError(
          400,
          "Ese jefe es subordinado de esta persona: se crearía un ciclo.",
          "SUPERVISOR_CYCLE",
        );
      }
      seen.add(current);
    }
  }
}

/* ───────────────────────── Editar / activar ───────────────────────── */

const accessError = (error: { message?: string } | null) => {
  const duplicated = /already|registered|exists/i.test(error?.message ?? "");
  return new AppError(
    duplicated ? 409 : 500,
    duplicated ? "Ya existe un usuario con acceso para ese DNI." : "No se pudo guardar el acceso al sistema.",
    duplicated ? "ACCESS_DUPLICATED" : undefined,
  );
};

/**
 * UPDATE: datos básicos y acceso al sistema. Solo si pertenece al customer.
 *   - Con acceso: el correo siempre es DNI@codigo_del_sistema.com (se actualiza si cambia el DNI).
 *   - Sin acceso: solo se apaga stff_access_system (getAccessContext ya bloquea el ingreso);
 *     el usuario de Auth se conserva por si se vuelve a activar.
 */
export async function updateStaff(id: number, custId: number, input: EditStaffInput): Promise<void> {
  await assertReferences(custId, input, id);

  const { data: current, error: readError } = await supabaseAdmin
    .from(TABLE)
    .select("stff_auth_id")
    .eq("stff_id", id)
    .eq("cust_id", custId)
    .maybeSingle();

  if (readError) {
    console.error("staffs.updateStaff(read):", readError);
    throw new AppError(500, "No se pudo consultar al personal.");
  }
  if (!current) throw new AppError(404, "El personal no existe.", "NOT_FOUND");

  let authId = (current as { stff_auth_id: string | null }).stff_auth_id;
  let createdUserId: string | null = null;

  if (input.withAccess) {
    const customer = await findByCustId(custId);
    if (!customer) throw new AppError(404, "No se encontró la cuenta del cliente.", "CUSTOMER_NOT_FOUND");
    const email = `${input.dni}@${customer.cust_code_system}.com`;

    if (authId) {
      const { error } = await supabaseAdmin.auth.admin.updateUserById(authId, {
        email,
        email_confirm: true,
        ...(input.password ? { password: input.password } : {}),
      });
      if (error) {
        console.error("staffs.updateStaff(auth update):", error);
        throw accessError(error);
      }
    } else {
      if (!input.password) {
        throw new AppError(400, "La contraseña debe tener al menos 6 caracteres.", "INVALID_PASSWORD");
      }
      const { data: created, error } = await supabaseAdmin.auth.admin.createUser({
        email,
        password: input.password,
        email_confirm: true,
      });
      if (error || !created.user) {
        console.error("staffs.updateStaff(auth create):", error);
        throw accessError(error);
      }
      authId = created.user.id;
      createdUserId = created.user.id;
    }
  }

  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .update({
      stff_name: input.name,
      stff_lastname: input.lastname,
      stff_dni: input.dni,
      stff_phone: input.phone,
      cust_jb_pstn_id: input.jobPositionId,
      cust_role_id: input.roleId,
      stff_supervisor_id: input.supervisorId,
      stff_auth_id: authId,
      stff_access_system: input.withAccess,
    })
    .eq("stff_id", id)
    .eq("cust_id", custId)
    .select("stff_id")
    .maybeSingle();

  if (error || !data) {
    // Si se creó un usuario en este intento, se deshace para no dejar uno huérfano.
    if (createdUserId) await supabaseAdmin.auth.admin.deleteUser(createdUserId).catch(() => {});
  }
  if (error) {
    console.error("staffs.updateStaff:", error);
    throw new AppError(500, "No se pudo actualizar al personal.");
  }
  if (!data) throw new AppError(404, "El personal no existe.", "NOT_FOUND");
}

/** UPDATE: activa o desactiva al personal. */
export async function setStaffActive(id: number, custId: number, active: boolean): Promise<void> {
  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .update({ stff_active: active })
    .eq("stff_id", id)
    .eq("cust_id", custId)
    .select("stff_id")
    .maybeSingle();

  if (error) {
    console.error("staffs.setStaffActive:", error);
    throw new AppError(500, "No se pudo cambiar el estado del personal.");
  }
  if (!data) throw new AppError(404, "El personal no existe.", "NOT_FOUND");
}

/* ───────────────────────── Crear ───────────────────────── */

const DAY_COLUMNS = [
  "stff_nn_wrkng_day_mondey", // (sic) así se llama la columna en la tabla
  "stff_nn_wrkng_day_tuesday",
  "stff_nn_wrkng_day_wednesday",
  "stff_nn_wrkng_day_thursday",
  "stff_nn_wrkng_day_friday",
  "stff_nn_wrkng_day_saturday",
  "stff_nn_wrkng_day_sunday",
] as const;

/** Inserta una fila y devuelve su id. Lanza 500 con el mensaje dado si falla. */
async function insertReturningId(
  table: string,
  idColumn: string,
  row: Record<string, unknown>,
  errorMessage: string,
): Promise<number> {
  const { data, error } = await supabaseAdmin.from(table).insert(row).select(idColumn).single();
  if (error || !data) {
    console.error(`staffs.insert(${table}):`, error);
    throw new AppError(500, errorMessage);
  }
  return Number((data as unknown as Record<string, unknown>)[idColumn]);
}

type Undo = () => PromiseLike<unknown>;

/**
 * Crea refrigerio → días no laborables → horario (sin tocar al personal).
 * Cada paso agrega su "deshacer" a `undo`. Devuelve el id del horario.
 * Lo usan crear y editar el personal.
 */
async function insertSchedule(custId: number, input: CreateStaffInput, undo: Undo[]): Promise<number> {
    // 1) Refrigerio
    const { refreshment } = input;
    const refreshmentId = await insertReturningId(
      "staff_refreshmenths",
      "stff_rfrshmnth_id",
      {
        stff_rfrshmnth_type: refreshment.type,
        stff_rfrshmnth_start: refreshment.type === "fixed" ? refreshment.start : null,
        stff_rfrshmnth_end: refreshment.type === "fixed" ? refreshment.end : null,
        stff_rfrshmnth_minutes: refreshment.type === "flexible" ? refreshment.minutes : null,
      },
      "No se pudo guardar el refrigerio.",
    );
    undo.push(() =>
      supabaseAdmin.from("staff_refreshmenths").delete().eq("stff_rfrshmnth_id", refreshmentId)
    );

    // 2) Días no laborables (opcional)
    let nonWorkingId: number | null = null;
    const nwd = input.nonWorkingDays;
    if (nwd) {
      const row: Record<string, unknown> = {
        stff_nn_wrkng_day_type: nwd.type,
        stff_nn_wrkng_day_number_days: nwd.type === "flexible" ? nwd.numberDays : null,
      };
      DAY_COLUMNS.forEach((column, i) => {
        row[column] = nwd.type === "fixed" ? nwd.days[i] : null;
      });

      nonWorkingId = await insertReturningId(
        "staff_non_working_days",
        "stff_nn_wrkng_day_id",
        row,
        "No se pudieron guardar los días no laborables.",
      );
      const id = nonWorkingId;
      undo.push(() => supabaseAdmin.from("staff_non_working_days").delete().eq("stff_nn_wrkng_day_id", id));
    }

    // 3) Horario
    const { schedule } = input;
    const scheduleId = await insertReturningId(
      "staff_schedules",
      "stff_schdl_id",
      {
        cust_id: custId,
        stff_schdl_type: schedule.type,
        stff_schdl_start: schedule.type === "fixed" ? schedule.start : null,
        stff_schdl_end: schedule.type === "fixed" ? schedule.end : null,
        stff_schdl_start_tolerance: schedule.type === "fixed" ? schedule.toleranceMinutes : 0,
        stff_schdl_required_minutes: schedule.type === "flexible" ? schedule.requiredMinutes : null,
        stff_rfrshmnth_id: refreshmentId,
        stff_nn_wrkng_day_id: nonWorkingId,
      },
      "No se pudo guardar el horario.",
    );
    undo.push(() => supabaseAdmin.from("staff_schedules").delete().eq("stff_schdl_id", scheduleId));

  return scheduleId;
}

const salaryRow = (staffId: number, salary: CreateStaffInput["salary"]) => ({
  stff_id: staffId,
  stff_slr_type: salary.type,
  stff_slr_amount: salary.amount,
});

const discountRow = (staffId: number, d: DiscountInput) => ({
  stff_id: staffId,
  stff_dscnt_rls_absence_amount: d.absenceAmount,
  stff_dscnt_rls_delay_type: d.delayType,
  stff_dscnt_rls_delay_amount: d.delayAmount,
  stff_dscnt_rls_refreshment_delay_type: d.refreshmentDelayType,
  stff_dscnt_rls_refreshment_delay_amount: d.refreshmentDelayAmount,
});

/**
 * CREATE: crea el personal con todo lo que lo rodea.
 *   [usuario de acceso] → refrigerio → días no laborables → horario → staff → contrato → sueldo
 * Si algún paso falla, se deshace lo creado antes (en orden inverso).
 */
export async function createStaff(custId: number, input: CreateStaffInput): Promise<{ stff_id: number }> {
  await assertReferences(custId, input, null);

  const undo: Undo[] = [];

  try {
    // 0) Usuario de acceso: DNI@codigo_del_sistema.com
    let authId: string | null = null;
    if (input.withAccess) {
      const customer = await findByCustId(custId);
      if (!customer) throw new AppError(404, "No se encontró la cuenta del cliente.", "CUSTOMER_NOT_FOUND");

      const { data, error } = await supabaseAdmin.auth.admin.createUser({
        email: `${input.dni}@${customer.cust_code_system}.com`,
        password: input.password!,
        email_confirm: true,
      });
      if (error || !data.user) {
        console.error("staffs.createStaff(auth):", error);
        const duplicated = /already|registered|exists/i.test(error?.message ?? "");
        throw new AppError(
          duplicated ? 409 : 500,
          duplicated
            ? "Ya existe un usuario con acceso para ese DNI."
            : "No se pudo crear el acceso al sistema.",
          duplicated ? "ACCESS_DUPLICATED" : undefined,
        );
      }
      authId = data.user.id;
      const userId = authId;
      undo.push(() => supabaseAdmin.auth.admin.deleteUser(userId));
    }

    // 1-3) Refrigerio → días no laborables → horario
    const scheduleId = await insertSchedule(custId, input, undo);

    // 4) Personal
    const staffId = await insertReturningId(
      TABLE,
      "stff_id",
      {
        cust_id: custId,
        cust_role_id: input.roleId,
        cust_jb_pstn_id: input.jobPositionId,
        stff_supervisor_id: input.supervisorId,
        stff_schdl_id: scheduleId,
        stff_auth_id: authId,
        stff_name: input.name,
        stff_lastname: input.lastname,
        stff_dni: input.dni,
        stff_phone: input.phone,
        stff_access_system: input.withAccess,
      },
      "No se pudo crear al personal.",
    );
    undo.push(() => supabaseAdmin.from(TABLE).delete().eq("stff_id", staffId));

    // 5) Contrato
    await insertContract(staffId, input.contract); // null = desde su primer registro / indefinido
    undo.push(() => supabaseAdmin.from("staff_contracts").delete().eq("stff_id", staffId));

    // 6) Sueldo
    await insertReturningId(
      "staff_salaries",
      "stff_slr_id",
      salaryRow(staffId, input.salary),
      "No se pudo guardar el sueldo.",
    );

    // 7) Descuentos propios (opcional). Sin undo: si algo falla, borrar el staff lo elimina en cascada.
    if (input.discount) {
      await insertReturningId(
        "staff_discount_rules",
        "stff_dscnt_rls_id",
        discountRow(staffId, input.discount),
        "No se pudieron guardar los descuentos.",
      );
    }

    return { stff_id: staffId };
  } catch (err) {
    for (const step of undo.reverse()) {
      try {
        await step();
      } catch (undoErr) {
        console.error("staffs.createStaff rollback:", undoErr);
      }
    }
    throw err;
  }
}

/* ───────────────────────── Detalle (para editar) ───────────────────────── */

type Row = Record<string, unknown>;

/** READ: la fila más reciente (por `orderColumn`) con `filterColumn = value`, o null. */
async function readOneRow(
  table: string,
  filterColumn: string,
  value: number,
  orderColumn: string,
): Promise<Row | null> {
  const { data, error } = await supabaseAdmin
    .from(table)
    .select("*")
    .eq(filterColumn, value)
    .order(orderColumn, { ascending: false })
    .limit(1)
    .maybeSingle();

  if (error) {
    console.error(`staffs.readOneRow(${table}):`, error);
    throw new AppError(500, "No se pudieron consultar los datos del personal.");
  }
  return (data as Row | null) ?? null;
}

/** "HH:MM:SS" (columna TIME) → "HH:MM". */
const hhmm = (value: unknown): string | null => (typeof value === "string" ? value.slice(0, 5) : null);
const numberOrNull = (value: unknown): number | null => (value === null || value === undefined ? null : Number(value));

/**
 * READ: todo lo que se llena al crear (datos, acceso, horario, refrigerio, días no laborables,
 * contrato más reciente, sueldo y descuentos) para poder editarlo. Misma forma que POST /staffs.
 */
export async function getStaffDetail(id: number, custId: number, bucketName: string): Promise<StaffDetail> {
  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .select(
      "stff_id, stff_name, stff_lastname, stff_dni, stff_phone, stff_link_img, stff_supervisor_id, cust_jb_pstn_id, cust_role_id, stff_access_system, stff_schdl_id",
    )
    .eq("stff_id", id)
    .eq("cust_id", custId)
    .maybeSingle();

  if (error) {
    console.error("staffs.getStaffDetail:", error);
    throw new AppError(500, "No se pudo consultar al personal.");
  }
  if (!data) throw new AppError(404, "El personal no existe.", "NOT_FOUND");
  const staff = data as StaffDetailRow;

  const [schedule, contract, salary, discount, urls] = await Promise.all([
    staff.stff_schdl_id ? readOneRow("staff_schedules", "stff_schdl_id", staff.stff_schdl_id, "stff_schdl_id") : null,
    getLatestContract(id),
    readOneRow("staff_salaries", "stff_id", id, "stff_slr_id"),
    readOneRow("staff_discount_rules", "stff_id", id, "stff_dscnt_rls_id"),
    signedImageUrls(bucketName, [staff.stff_link_img]),
  ]);

  const refreshmentId = numberOrNull(schedule?.stff_rfrshmnth_id);
  const nonWorkingId = numberOrNull(schedule?.stff_nn_wrkng_day_id);
  const [refreshmentRow, nonWorkingRow] = await Promise.all([
    refreshmentId ? readOneRow("staff_refreshmenths", "stff_rfrshmnth_id", refreshmentId, "stff_rfrshmnth_id") : null,
    nonWorkingId ? readOneRow("staff_non_working_days", "stff_nn_wrkng_day_id", nonWorkingId, "stff_nn_wrkng_day_id") : null,
  ]);

  const nonWorkingType = nonWorkingRow?.stff_nn_wrkng_day_type;

  return {
    name: staff.stff_name,
    lastname: staff.stff_lastname,
    dni: staff.stff_dni,
    phone: staff.stff_phone,
    jobPositionId: staff.cust_jb_pstn_id,
    roleId: staff.cust_role_id,
    supervisorId: staff.stff_supervisor_id,
    withAccess: staff.stff_access_system,
    password: null, // la contraseña nunca sale del servidor

    schedule: {
      type: (schedule?.stff_schdl_type ?? "free") as ScheduleType,
      start: hhmm(schedule?.stff_schdl_start),
      end: hhmm(schedule?.stff_schdl_end),
      toleranceMinutes: Number(schedule?.stff_schdl_start_tolerance ?? 0),
      requiredMinutes: numberOrNull(schedule?.stff_schdl_required_minutes),
    },

    refreshment: {
      type: (refreshmentRow?.stff_rfrshmnth_type ?? "free") as ScheduleType,
      start: hhmm(refreshmentRow?.stff_rfrshmnth_start),
      end: hhmm(refreshmentRow?.stff_rfrshmnth_end),
      minutes: numberOrNull(refreshmentRow?.stff_rfrshmnth_minutes),
    },

    nonWorkingDays:
      nonWorkingRow && nonWorkingType === "fixed"
        ? { type: "fixed", days: DAY_COLUMNS.map((column) => nonWorkingRow[column] === true) }
        : nonWorkingRow && nonWorkingType === "flexible"
          ? { type: "flexible", numberDays: Number(nonWorkingRow.stff_nn_wrkng_day_number_days ?? 1) }
          : null,

    salary: {
      type: (salary?.stff_slr_type ?? "Monthly") as CreateStaffInput["salary"]["type"],
      amount: Number(salary?.stff_slr_amount ?? 0),
    },

    contract: {
      startDate: contract?.cntrt_start_date ?? null,
      endDate: contract?.cntrt_end_date ?? null,
    },

    discount: discount
      ? {
          absenceAmount: Number(discount.stff_dscnt_rls_absence_amount),
          delayType: discount.stff_dscnt_rls_delay_type as DiscountInput["delayType"],
          delayAmount: Number(discount.stff_dscnt_rls_delay_amount),
          refreshmentDelayType: discount.stff_dscnt_rls_refreshment_delay_type as DiscountInput["refreshmentDelayType"],
          refreshmentDelayAmount: Number(discount.stff_dscnt_rls_refreshment_delay_amount),
        }
      : null,

    img_url: staff.stff_link_img ? urls.get(staff.stff_link_img) ?? null : null,
  };
}

/* ───────────────────────── Editar + activar + nuevo contrato ───────────────────────── */

/** Actualiza la última fila del personal en `table`; si no tiene ninguna, la inserta. */
async function updateLatestOrInsert(
  table: string,
  idColumn: string,
  staffId: number,
  row: Record<string, unknown>,
  errorMessage: string,
): Promise<void> {
  const latest = await readOneRow(table, "stff_id", staffId, idColumn);
  if (!latest) {
    await insertReturningId(table, idColumn, row, errorMessage);
    return;
  }

  const { error } = await supabaseAdmin.from(table).update(row).eq(idColumn, latest[idColumn] as number);
  if (error) {
    console.error(`staffs.updateLatestOrInsert(${table}):`, error);
    throw new AppError(500, errorMessage);
  }
}

/** Borra el horario anterior (y su refrigerio y días no laborables) si ya nadie lo usa. No lanza errores. */
async function removeOldSchedule(scheduleId: number): Promise<void> {
  try {
    const { count } = await supabaseAdmin
      .from(TABLE)
      .select("stff_id", { count: "exact", head: true })
      .eq("stff_schdl_id", scheduleId);
    if (count) return; // otro personal lo sigue usando

    const old = await readOneRow("staff_schedules", "stff_schdl_id", scheduleId, "stff_schdl_id");
    if (!old) return;

    await supabaseAdmin.from("staff_schedules").delete().eq("stff_schdl_id", scheduleId);
    if (old.stff_rfrshmnth_id) {
      await supabaseAdmin.from("staff_refreshmenths").delete().eq("stff_rfrshmnth_id", old.stff_rfrshmnth_id as number);
    }
    if (old.stff_nn_wrkng_day_id) {
      await supabaseAdmin.from("staff_non_working_days").delete().eq("stff_nn_wrkng_day_id", old.stff_nn_wrkng_day_id as number);
    }
  } catch (err) {
    console.error("staffs.removeOldSchedule:", err);
  }
}

/**
 * UPDATE: edita al personal con los mismos datos que se piden al crearlo y, al final:
 *   - lo ACTIVA, y
 *   - crea un NUEVO registro en staff_contracts.
 *
 *   horario nuevo → datos y acceso (updateStaff) → apunta al horario y activa
 *   → contrato → sueldo → descuentos
 * Si algún paso falla se deshace lo anterior (en orden inverso).
 */
export async function renewStaffContract(
  id: number,
  custId: number,
  input: CreateStaffInput,
): Promise<{ stff_id: number }> {
  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .select(
      "stff_name, stff_lastname, stff_dni, stff_phone, cust_jb_pstn_id, cust_role_id, stff_supervisor_id, stff_access_system, stff_schdl_id, stff_active",
    )
    .eq("stff_id", id)
    .eq("cust_id", custId)
    .maybeSingle();

  if (error) {
    console.error("staffs.renewStaffContract(read):", error);
    throw new AppError(500, "No se pudo consultar al personal.");
  }
  if (!data) throw new AppError(404, "El personal no existe.", "NOT_FOUND");
  const before = data as Row;

  const undo: Undo[] = [];

  try {
    // 1) Horario nuevo (refrigerio + días no laborables + horario)
    const scheduleId = await insertSchedule(custId, input, undo);

    // 2) Datos básicos y acceso: reutiliza updateStaff (valida cargo/rol/jefe y maneja el usuario de acceso).
    //    El usuario de Auth no se revierte (mismo criterio que updateStaff: se conserva).
    undo.push(() =>
      supabaseAdmin
        .from(TABLE)
        .update({
          stff_name: before.stff_name,
          stff_lastname: before.stff_lastname,
          stff_dni: before.stff_dni,
          stff_phone: before.stff_phone,
          cust_jb_pstn_id: before.cust_jb_pstn_id,
          cust_role_id: before.cust_role_id,
          stff_supervisor_id: before.stff_supervisor_id,
          stff_access_system: before.stff_access_system,
          stff_schdl_id: before.stff_schdl_id,
          stff_active: before.stff_active,
        })
        .eq("stff_id", id)
        .eq("cust_id", custId)
    );
    await updateStaff(id, custId, input);

    // 3) Apunta al horario nuevo y lo activa
    const { error: scheduleError } = await supabaseAdmin
      .from(TABLE)
      .update({ stff_schdl_id: scheduleId })
      .eq("stff_id", id)
      .eq("cust_id", custId);
    if (scheduleError) {
      console.error("staffs.renewStaffContract(schedule):", scheduleError);
      throw new AppError(500, "No se pudo asignar el nuevo horario.");
    }
    await setStaffActive(id, custId, true);

    // 4) Nuevo contrato
    const previousContract = await getLatestContract(id);
    const contractId = await insertContract(id, input.contract);
    undo.push(() => supabaseAdmin.from("staff_contracts").delete().eq("stff_cntrt_id", contractId));

    // Si estaba activo, su contrato anterior seguía abierto: se cierra para no dejar dos vigentes.
    if (before.stff_active === true && previousContract && previousContract.cntrt_end_date === null) {
      await endContractById(previousContract.stff_cntrt_id).catch((err) =>
        console.error("staffs.renewStaffContract(end previous):", err)
      );
    }

    // 5) Sueldo y descuentos
    await updateLatestOrInsert("staff_salaries", "stff_slr_id", id, salaryRow(id, input.salary), "No se pudo guardar el sueldo.");

    if (input.discount) {
      await updateLatestOrInsert(
        "staff_discount_rules",
        "stff_dscnt_rls_id",
        id,
        discountRow(id, input.discount),
        "No se pudieron guardar los descuentos.",
      );
    } else {
      // Sin descuento propio: vuelve a aplicar el general.
      const { error: deleteError } = await supabaseAdmin.from("staff_discount_rules").delete().eq("stff_id", id);
      if (deleteError) {
        console.error("staffs.renewStaffContract(discount):", deleteError);
        throw new AppError(500, "No se pudieron guardar los descuentos.");
      }
    }

    // 6) El horario anterior ya no se usa
    const previousScheduleId = numberOrNull(before.stff_schdl_id);
    if (previousScheduleId && previousScheduleId !== scheduleId) await removeOldSchedule(previousScheduleId);

    return { stff_id: id };
  } catch (err) {
    for (const step of undo.reverse()) {
      try {
        await step();
      } catch (undoErr) {
        console.error("staffs.renewStaffContract rollback:", undoErr);
      }
    }
    throw err;
  }
}

/* ───────────────────────── Foto ───────────────────────── */

const IMAGE_EXTENSIONS: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
  "image/gif": "gif",
};

export const MAX_IMAGE_BYTES = 5 * 1024 * 1024;

/** UPDATE: sube la foto al bucket del customer y la deja como foto del personal. */
export async function uploadStaffPhoto(
  id: number,
  custId: number,
  bucketName: string,
  file: File,
): Promise<{ stff_link_img: string; img_url: string | null }> {
  const extension = IMAGE_EXTENSIONS[file.type];
  if (!extension) {
    throw new AppError(400, "Formato no permitido. Usa JPG, PNG, WEBP o GIF.", "INVALID_IMAGE");
  }
  if (file.size > MAX_IMAGE_BYTES) {
    throw new AppError(400, "La imagen no puede pesar más de 5 MB.", "IMAGE_TOO_LARGE");
  }

  const { data: current, error: readError } = await supabaseAdmin
    .from(TABLE)
    .select("stff_link_img")
    .eq("stff_id", id)
    .eq("cust_id", custId)
    .maybeSingle();

  if (readError) {
    console.error("staffs.uploadStaffPhoto(read):", readError);
    throw new AppError(500, "No se pudo consultar al personal.");
  }
  if (!current) throw new AppError(404, "El personal no existe.", "NOT_FOUND");

  const previous = (current as { stff_link_img: string | null }).stff_link_img;
  const fileName = `${id}-${Date.now()}.${extension}`;

  const { error: uploadError } = await supabaseAdmin.storage
    .from(bucketName)
    .upload(imagePath(fileName), await file.arrayBuffer(), { contentType: file.type, upsert: true });

  if (uploadError) {
    console.error("staffs.uploadStaffPhoto(upload):", uploadError);
    throw new AppError(500, "No se pudo subir la imagen.");
  }

  const { error: updateError } = await supabaseAdmin
    .from(TABLE)
    .update({ stff_link_img: fileName })
    .eq("stff_id", id)
    .eq("cust_id", custId);

  if (updateError) {
    console.error("staffs.uploadStaffPhoto(update):", updateError);
    await supabaseAdmin.storage.from(bucketName).remove([imagePath(fileName)]);
    throw new AppError(500, "No se pudo guardar la imagen.");
  }

  // La foto anterior ya no se usa: se borra (si falla no importa).
  if (previous) {
    await supabaseAdmin.storage.from(bucketName).remove([imagePath(previous)]).catch(() => {});
  }

  const urls = await signedImageUrls(bucketName, [fileName]);
  return { stff_link_img: fileName, img_url: urls.get(fileName) ?? null };
}