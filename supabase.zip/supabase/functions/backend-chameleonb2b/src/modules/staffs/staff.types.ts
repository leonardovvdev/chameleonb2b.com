/** A qué customer pertenece quien hace la petición (siempre sale del JWT). */
export interface AccessContext {
  custId: number;
  bucketName: string;
}

export type DiscountUnit = "per_minute" | "per_hour" | "fixed";
export interface DiscountInput {
  absenceAmount: number;
  delayType: DiscountUnit;
  delayAmount: number;
  refreshmentDelayType: DiscountUnit;
  refreshmentDelayAmount: number;
}
/** Columnas de `staffs` que se leen para validar el acceso de un staff. */
export interface StaffAccessRow {
  stff_id: number;
  cust_id: number;
  stff_active: boolean;
  stff_access_system: boolean;
}

/* ───────────────────────── Organigrama ───────────────────────── */

/** Fila de `staffs` con los alias del select del organigrama. */
export interface OrgChartStaffRow {
  id: number;
  supervisor_id: number | null;
  name: string;
  lastname: string;
  img: string | null;
  // Relación muchos-a-uno: llega como objeto (se acepta arreglo por seguridad).
  job_position: { name: string | null } | { name: string | null }[] | null;
}

/** Persona del organigrama tal como se devuelve al frontend. */
export interface OrgChartStaff {
  id: number;
  supervisor_id: number | null;
  name: string;
  lastname: string;
  img_url: string | null;
  job_position: string | null;
}

/* ───────────────────────── Lista de personal ───────────────────────── */

export type StaffStatusFilter = "" | "ACTIVO" | "INACTIVO";

export interface StaffListFilters {
  page: number;
  pageSize: number;
  search: string;
  cargoId: number | null;
  rolId: number | null;
  estado: StaffStatusFilter;
}

type Embedded = { name: string | null } | { name: string | null }[] | null;

/** Fila de `staffs` tal como sale del select de la lista. */
export interface StaffListRow {
  stff_id: number;
  stff_name: string;
  stff_lastname: string;
  stff_dni: string;
  stff_phone: string | null;
  stff_link_img: string | null;
  stff_active: boolean;
  stff_access_system: boolean;
  stff_supervisor_id: number | null;
  cust_jb_pstn_id: number;
  cust_role_id: number | null;
  job_position: Embedded;
  role: Embedded;
}

/** Persona de la lista tal como se devuelve al frontend. */
export interface StaffListItem {
  stff_id: number;
  stff_name: string;
  stff_lastname: string;
  stff_dni: string;
  stff_phone: string | null;
  stff_link_img: string | null;
  stff_active: boolean;
  stff_access_system: boolean;
  stff_supervisor_id: number | null;
  cust_jb_pstn_id: number;
  cust_role_id: number | null;
  job_position_name: string | null;
  role_name: string | null;
  /** URL firmada (temporal) de la foto, o null si no tiene. */
  img_url: string | null;
}

export interface StaffListResult {
  items: StaffListItem[];
  count: number;
}

/** Candidato a jefe directo. */
export interface SupervisorItem {
  id: number;
  name: string;
  lastname: string;
  img_url: string | null;
  job_position: string | null;
  /** Personal que lo tiene como jefe directo. */
  subordinates: number;
}

/* ───────────────────────── Crear / editar ───────────────────────── */

export interface UpdateStaffInput {
  name: string;
  lastname: string;
  dni: string;
  phone: string | null;
  jobPositionId: number;
  roleId: number | null;
  supervisorId: number | null;
}

/** PATCH /staffs: datos básicos + acceso al sistema. */
export interface EditStaffInput extends UpdateStaffInput {
  withAccess: boolean;
  /** Obligatoria solo si se activa el acceso y la persona aún no tiene usuario; opcional para cambiarla. */
  password: string | null;
}

export type ScheduleType = "fixed" | "flexible" | "free";

export interface ScheduleInput {
  type: ScheduleType;
  /** "HH:MM" (solo fixed) */
  start: string | null;
  end: string | null;
  toleranceMinutes: number;
  /** Minutos a cumplir (solo flexible) */
  requiredMinutes: number | null;
}

export interface RefreshmentInput {
  type: ScheduleType;
  start: string | null;
  end: string | null;
  minutes: number | null;
}

/** null = sin días no laborables. */
export type NonWorkingDaysInput =
  | { type: "fixed"; days: boolean[] } // 7 posiciones: lunes … domingo
  | { type: "flexible"; numberDays: number }
  | null;

export type SalaryType = "Monthly" | "Weekly" | "Daily";

export interface CreateStaffInput extends UpdateStaffInput {
  withAccess: boolean;
  password: string | null;
  schedule: ScheduleInput;
  refreshment: RefreshmentInput;
  contract: { startDate: string | null; endDate: string | null };
  nonWorkingDays: NonWorkingDaysInput;
  salary: { type: SalaryType; amount: number };
  discount: DiscountInput | null;
}

/* ───────────────────────── Detalle (para editar) ───────────────────────── */

/** Columnas de `staffs` que se leen para armar el detalle. */
export interface StaffDetailRow {
  stff_id: number;
  stff_name: string;
  stff_lastname: string;
  stff_dni: string;
  stff_phone: string | null;
  stff_link_img: string | null;
  stff_supervisor_id: number | null;
  cust_jb_pstn_id: number;
  cust_role_id: number | null;
  stff_access_system: boolean;
  stff_schdl_id: number | null;
}

/**
 * GET /staffs/detail: misma forma que recibe POST /staffs (y PUT /staffs/contract),
 * más la foto. La contraseña nunca se devuelve.
 */
export type StaffDetail = Omit<CreateStaffInput, "password"> & {
  password: null;
  /** URL firmada (temporal) de la foto, o null si no tiene. */
  img_url: string | null;
};