import { AppError, json } from "../../shared/http.ts";
import { getAccessContext } from "../auth/auth.services.ts";
import {
  createStaff,
  getOrgChart,
  getStaffDetail,
  getSupervisors,
  listStaffs,
  setStaffActive,
  updateStaff,
  updateStaffContract,
  uploadStaffPhoto,
} from "./staffs.services.ts";

const MAX_IMAGE_BYTES = 5 * 1024 * 1024;

/** Lee y valida ?id=123 de la URL. */
function parseId(req: Request): number {
  const raw = new URL(req.url).searchParams.get("id");
  const id = Number(raw);
  if (!raw || !Number.isSafeInteger(id) || id <= 0) {
    throw new AppError(400, "El id del personal no es válido.", "INVALID_ID");
  }
  return id;
}

const readBody = async (req: Request): Promise<unknown> => {
  const body = await req.json().catch(() => null);
  if (body === null) throw new AppError(400, "El cuerpo de la petición no es válido.", "INVALID_BODY");
  return body;
};

/** GET /staffs?page&pageSize&search&cargoId&rolId&estado → { items, count } */
export async function listStaffsHandler(req: Request): Promise<Response> {
  const ctx = await getAccessContext(req);
  return json(await listStaffs(ctx, new URL(req.url).searchParams));
}

/** GET /staffs/supervisors → { items } */
export async function getSupervisorsHandler(req: Request): Promise<Response> {
  return json(await getSupervisors(await getAccessContext(req)));
}

/** GET /staffs/org-chart → { items: [{ id, supervisor_id, name, lastname, img_url, job_position }] } */
export async function getOrgChartHandler(req: Request): Promise<Response> {
  return json(await getOrgChart(await getAccessContext(req)));
}

/** GET /staffs/detail?id= → misma forma que POST /staffs + img_url */
export async function getStaffDetailHandler(req: Request): Promise<Response> {
  const ctx = await getAccessContext(req);
  return json(await getStaffDetail(ctx, parseId(req)));
}

/** POST /staffs → { stff_id } */
export async function createStaffHandler(req: Request): Promise<Response> {
  const ctx = await getAccessContext(req);
  return json(await createStaff(ctx, await readBody(req)), 201);
}

/** PATCH /staffs?id= → { id } */
export async function updateStaffHandler(req: Request): Promise<Response> {
  const ctx = await getAccessContext(req);
  return json(await updateStaff(ctx, parseId(req), await readBody(req)));
}

/** PUT /staffs/contract?id= → { stff_id } (actualiza, activa y crea contrato nuevo) */
export async function updateStaffContractHandler(req: Request): Promise<Response> {
  const ctx = await getAccessContext(req);
  return json(await updateStaffContract(ctx, parseId(req), await readBody(req)));
}

/** PATCH /staffs/active?id= body { active } → { id, active } */
export async function setStaffActiveHandler(req: Request): Promise<Response> {
  const ctx = await getAccessContext(req);
  const body = (await readBody(req)) as { active?: unknown };
  return json(await setStaffActive(ctx, parseId(req), body.active));
}

/** POST /staffs/photo?id= (multipart: file) → { stff_link_img, img_url } */
export async function uploadStaffPhotoHandler(req: Request): Promise<Response> {
  const ctx = await getAccessContext(req);
  const id = parseId(req);

  const declared = Number(req.headers.get("content-length") ?? 0);
  if (declared > MAX_IMAGE_BYTES + 1024 * 100) {
    throw new AppError(400, "La imagen no puede pesar más de 5 MB.", "IMAGE_TOO_LARGE");
  }
  const form = await req.formData().catch(() => null);
  if (!form) throw new AppError(400, "El cuerpo de la petición no es válido.", "INVALID_BODY");

  const file = form.get("file");
  if (!(file instanceof File) || file.size === 0) {
    throw new AppError(400, "Debes seleccionar una imagen.", "FILE_REQUIRED");
  }
  return json(await uploadStaffPhoto(ctx, id, file), 201);
}