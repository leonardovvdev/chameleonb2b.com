import { AppError } from "../../shared/http.ts";
import { supabaseAdmin } from "../../shared/supabase.ts";
import { random11Digits } from "../../shared/random.ts";
import { convertImageToWebp } from "../../shared/convert-img-to-webp.ts";
import { validateNewPassword } from "../auth/auth.services.ts";
import type { AccessContext } from "../auth/auth.services.ts";
import { createSignedUrls } from "../buckets/buckets.services.ts";

/** Fotos del personal dentro del bucket del customer (solo se guarda el nombre del archivo). */
const STAFF_IMG_FOLDER = "gestion_empresarial/staffs_img";
const MAX_IMAGE_BYTES = 5 * 1024 * 1024;
const IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp", "image/gif"];

/* ───────────────────────── Utilidades de validación ───────────────────────── */

type Obj = Record<string, unknown>;

function fail(message: string, error: unknown): never {
  console.error(`staffs: ${message}`, error);
  throw new AppError(500, message);
}
const bad = (message: string, code = "INVALID_DATA") => new AppError(400, message, code);

const obj = (v: unknown, label: string): Obj => {
  if (typeof v !== "object" || v === null || Array.isArray(v)) throw bad(`${label} no es válido.`);
  return v as Obj;
};
const text = (v: unknown) => (typeof v === "string" ? v.trim() : "");

const idOrNull = (v: unknown, label: string): number | null => {
  if (v === null || v === undefined || v === "") return null;
  const n = Number(v);
  if (!Number.isSafeInteger(n) || n <= 0) throw bad(`${label} no es válido.`);
  return n;
};
const posInt = (v: unknown, label: string): number => {
  const n = Number(v);
  if (!Number.isSafeInteger(n) || n <= 0) throw bad(`${label} no es válido.`);
  return n;
};
const nonNegInt = (v: unknown, label: string): number => {
  const n = Number(v ?? 0);
  if (!Number.isSafeInteger(n) || n < 0 || n > 32767) throw bad(`${label} no es válido.`);
  return n;
};
const oneOf = <T extends string>(v: unknown, list: readonly T[], label: string): T => {
  if (typeof v === "string" && (list as readonly string[]).includes(v)) return v as T;
  throw bad(`${label} no es válido.`);
};
const time = (v: unknown, label: string): string => {
  const t = text(v).slice(0, 5); // acepta "08:00" y "08:00:00"
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(t)) throw bad(`${label} no es válida.`);
  return t;
};
const dateOrNull = (v: unknown, label: string): string | null => {
  if (v === null || v === undefined || v === "") return null;
  const d = text(v).slice(0, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(d)) throw bad(`${label} no es válida.`);
  return d;
};
const one = <T>(v: T | T[] | null | undefined): T | null => (Array.isArray(v) ? (v[0] ?? null) : (v ?? null));

/* ───────────────────────── Datos del personal ───────────────────────── */

interface StaffInput {
  name: string;
  lastname: string;
  dni: string;
  phone: string | null;
  jobPositionId: number;
  roleId: number | null;
  supervisorId: number | null;
  withAccess: boolean;
  password: string | null;
}

function parseStaff(raw: unknown): StaffInput {
  const b = obj(raw, "Los datos");
  const name = text(b.name);
  const lastname = text(b.lastname);
  const dni = text(b.dni);
  const phone = text(b.phone);

  if (!name || name.length > 200) throw bad("Ingresa los nombres (máximo 200 caracteres).");
  if (!lastname || lastname.length > 200) throw bad("Ingresa los apellidos (máximo 200 caracteres).");
  if (!/^\d{8}$/.test(dni)) throw bad("El DNI debe tener 8 dígitos.");
  if (phone && !/^\d{9}$/.test(phone)) throw bad("El teléfono debe tener 9 dígitos.");

  const jobPositionId = idOrNull(b.jobPositionId, "El cargo");
  if (jobPositionId === null) throw bad("Elige el cargo.");

  const password = typeof b.password === "string" && b.password !== "" ? b.password : null;
  if (password) validateNewPassword(password, password); // mismas reglas de clave que auth

  return {
    name,
    lastname,
    dni,
    phone: phone || null,
    jobPositionId,
    roleId: idOrNull(b.roleId, "El rol"),
    supervisorId: idOrNull(b.supervisorId, "El jefe directo"),
    withAccess: b.withAccess === true,
    password,
  };
}

/**
 * Horario, refrigerio, días no laborables, sueldo, vigencia y descuentos.
 * Devuelve solo lo que lee la función SQL staff_add_contract.
 * OJO: `salary.type` y `discount` (montos) llegan en el payload pero hoy no hay columnas donde guardarlos.
 */
function parseContract(raw: unknown): Obj {
  const b = obj(raw, "Los datos");

  const s = obj(b.schedule, "El horario");
  const sType = oneOf(s.type, ["fixed", "flexible", "free"] as const, "El tipo de horario");
  const schedule =
    sType === "fixed"
      ? {
          type: sType,
          start: time(s.start, "La hora de entrada"),
          end: time(s.end, "La hora de salida"),
          toleranceMinutes: nonNegInt(s.toleranceMinutes, "La tolerancia"),
          requiredMinutes: null,
        }
      : sType === "flexible"
        ? { type: sType, start: null, end: null, toleranceMinutes: 0, requiredMinutes: posInt(s.requiredMinutes, "Las horas de trabajo") }
        : { type: sType, start: null, end: null, toleranceMinutes: 0, requiredMinutes: null };

  const r = obj(b.refreshment, "El refrigerio");
  const rType = oneOf(r.type, ["fixed", "flexible", "free"] as const, "El tipo de refrigerio");
  const refreshment =
    rType === "fixed"
      ? { type: rType, start: time(r.start, "La hora de inicio del refrigerio"), end: time(r.end, "La hora de fin del refrigerio"), minutes: null }
      : rType === "flexible"
        ? { type: rType, start: null, end: null, minutes: posInt(r.minutes, "Los minutos de refrigerio") }
        : { type: rType, start: null, end: null, minutes: null };

  let nonWorkingDays: Obj | null = null;
  if (b.nonWorkingDays !== null && b.nonWorkingDays !== undefined) {
    const n = obj(b.nonWorkingDays, "Los días no laborables");
    const nType = oneOf(n.type, ["fixed", "flexible"] as const, "El tipo de días no laborables");
    if (nType === "fixed") {
      if (!Array.isArray(n.days) || n.days.length !== 7) throw bad("Los días no laborables no son válidos.");
      nonWorkingDays = { type: nType, days: n.days.map((d) => d === true) };
    } else {
      nonWorkingDays = { type: nType, numberDays: posInt(n.numberDays, "La cantidad de días no laborables") };
    }
  }

  const amount = Number(obj(b.salary, "El sueldo").amount);
  if (!(amount > 0) || amount >= 1e10) throw bad("Ingresa un sueldo válido.");

  const c = obj(b.contract ?? {}, "La vigencia");
  const startDate = dateOrNull(c.startDate, "La fecha de inicio");
  const endDate = dateOrNull(c.endDate, "La fecha de fin");
  if (startDate && endDate && endDate < startDate) {
    throw bad("La fecha de fin no puede ser anterior a la de inicio.");
  }

  const f = obj(b.discountFlags ?? {}, "Los descuentos");

  return {
    schedule,
    refreshment,
    nonWorkingDays,
    salary: { amount },
    contract: { startDate, endDate },
    discountFlags: {
      absence: f.absence !== false,
      delay: f.delay !== false,
      refreshmentDelay: f.refreshmentDelay !== false,
    },
  };
}

/** Errores de la función SQL → mensaje que ve el usuario. */
function rpcError(error: { code?: string; message?: string }): AppError {
  console.error("staffs.staff_add_contract:", error);
  if (error.message?.includes("STAFF_NOT_FOUND")) return new AppError(404, "El personal no existe.", "NOT_FOUND");
  if (error.code === "23514") return bad("Revisa el horario, el refrigerio, los días no laborables y las fechas del contrato.");
  return new AppError(500, "No se pudo guardar el contrato del personal.");
}

/* ───────────────────────── Validaciones contra la BD ───────────────────────── */

async function assertOwned(table: string, idCol: string, id: number | null, custId: number, label: string) {
  if (id === null) return;
  const { data, error } = await supabaseAdmin
    .from(table)
    .select(idCol)
    .eq(idCol, id)
    .eq("cust_id", custId)
    .maybeSingle();
  if (error) fail("No se pudieron validar los datos enviados.", error);
  if (!data) throw bad(`${label} no existe.`, "NOT_FOUND");
}

const assertRelations = (custId: number, i: StaffInput) =>
  Promise.all([
    assertOwned("customer_job_positions", "cust_jb_pstn_id", i.jobPositionId, custId, "El cargo"),
    assertOwned("customer_roles", "cust_role_id", i.roleId, custId, "El rol"),
    assertOwned("staffs", "stff_id", i.supervisorId, custId, "El jefe directo"),
  ]);

/** Un jefe no puede ser la misma persona ni alguien que dependa de ella. */
async function assertNoCycle(staffId: number, supervisorId: number | null, custId: number) {
  if (supervisorId === null) return;
  if (supervisorId === staffId) throw bad("Una persona no puede ser su propio jefe directo.");

  let current: number | null = supervisorId;
  for (let i = 0; i < 100 && current !== null; i++) {
    const { data, error } = await supabaseAdmin
      .from("staffs")
      .select("stff_supervisor_id")
      .eq("stff_id", current)
      .eq("cust_id", custId)
      .maybeSingle();
    if (error) fail("No se pudo validar el jefe directo.", error);
    current = (data?.stff_supervisor_id as number | null | undefined) ?? null;
    if (current === staffId) throw bad("Ese jefe directo depende de esta persona. Elige a otro.");
  }
}

/* ───────────────────────── Acceso al sistema (correo = DNI@codigo.com) ───────────────────────── */

const accessEmail = (dni: string, codeSystem: number) => `${dni}@${codeSystem}.com`;

function accessError(error: { code?: string } | null): never {
  if (error?.code === "email_exists") {
    throw new AppError(409, "Ya existe una persona con acceso al sistema con ese DNI.", "ACCESS_EXISTS");
  }
  return fail("No se pudo guardar el acceso al sistema.", error);
}

async function createAccessUser(dni: string, codeSystem: number, password: string): Promise<string> {
  const { data, error } = await supabaseAdmin.auth.admin.createUser({
    email: accessEmail(dni, codeSystem),
    password,
    email_confirm: true,
  });
  if (error || !data.user) accessError(error);
  return data.user!.id;
}

/* ───────────────────────── Crear / editar ───────────────────────── */

export async function createStaff(ctx: AccessContext, raw: unknown): Promise<{ stff_id: number }> {
  const input = parseStaff(raw);
  const contract = parseContract(raw);
  await assertRelations(ctx.custId, input);
  if (input.withAccess && !input.password) throw bad("Ingresa una contraseña para el acceso al sistema.");

  const authId = input.withAccess ? await createAccessUser(input.dni, ctx.codeSystem, input.password!) : null;
  const undo = async (staffId?: number) => {
    if (staffId) await supabaseAdmin.from("staffs").delete().eq("stff_id", staffId);
    if (authId) await supabaseAdmin.auth.admin.deleteUser(authId);
  };

  const { data, error } = await supabaseAdmin
    .from("staffs")
    .insert({
      cust_id: ctx.custId,
      cust_role_id: input.roleId,
      cust_jb_pstn_id: input.jobPositionId,
      stff_supervisor_id: input.supervisorId,
      stff_auth_id: authId,
      stff_name: input.name,
      stff_lastname: input.lastname,
      stff_dni: input.dni,
      stff_phone: input.phone,
      stff_access_system: input.withAccess,
    })
    .select("stff_id")
    .single();

  if (error || !data) {
    await undo();
    fail("No se pudo crear al personal.", error);
  }

  // Horario + refrigerio + días + contrato + historial : todo o nada (una transacción en SQL).
  const { error: rpc } = await supabaseAdmin.rpc("staff_add_contract", {
    p_cust_id: ctx.custId,
    p_stff_id: data!.stff_id,
    p_data: contract,
  });
  if (rpc) {
    await undo(data!.stff_id);
    throw rpcError(rpc);
  }
  return { stff_id: data!.stff_id as number };
}

async function saveStaff(ctx: AccessContext, id: number, input: StaffInput, activate: boolean) {
  const { data: current, error } = await supabaseAdmin
    .from("staffs")
    .select("stff_auth_id, stff_dni")
    .eq("stff_id", id)
    .eq("cust_id", ctx.custId)
    .maybeSingle();
  if (error) fail("No se pudo consultar al personal.", error);
  if (!current) throw new AppError(404, "El personal no existe.", "NOT_FOUND");

  await assertRelations(ctx.custId, input);
  await assertNoCycle(id, input.supervisorId, ctx.custId);

  let authId = current.stff_auth_id as string | null;
  if (input.withAccess) {
    if (!authId) {
      if (!input.password) throw bad("Ingresa una contraseña para activar el acceso al sistema.");
      authId = await createAccessUser(input.dni, ctx.codeSystem, input.password);
    } else {
      const attrs: { email?: string; password?: string } = {};
      if (input.dni !== current.stff_dni) attrs.email = accessEmail(input.dni, ctx.codeSystem);
      if (input.password) attrs.password = input.password;
      if (Object.keys(attrs).length > 0) {
        const { error: e } = await supabaseAdmin.auth.admin.updateUserById(authId, { ...attrs, email_confirm: true });
        if (e) accessError(e);
      }
    }
  }

  const { error: upErr } = await supabaseAdmin
    .from("staffs")
    .update({
      cust_role_id: input.roleId,
      cust_jb_pstn_id: input.jobPositionId,
      stff_supervisor_id: input.supervisorId,
      stff_auth_id: authId,
      stff_name: input.name,
      stff_lastname: input.lastname,
      stff_dni: input.dni,
      stff_phone: input.phone,
      stff_access_system: input.withAccess,
      ...(activate ? { stff_active: true } : {}),
    })
    .eq("stff_id", id)
    .eq("cust_id", ctx.custId);
  if (upErr) fail("No se pudo guardar al personal.", upErr);
}

/** PATCH /staffs?id= → solo datos personales, cargo, rol, jefe y acceso. */
export async function updateStaff(ctx: AccessContext, id: number, raw: unknown): Promise<{ id: number }> {
  await saveStaff(ctx, id, parseStaff(raw), false);
  return { id };
}

/** PUT /staffs/contract?id= → actualiza al personal, lo ACTIVA y crea un contrato nuevo. */
export async function updateStaffContract(ctx: AccessContext, id: number, raw: unknown): Promise<{ stff_id: number }> {
  const input = parseStaff(raw);
  const contract = parseContract(raw);

  await saveStaff(ctx, id, input, true);
  const { error } = await supabaseAdmin.rpc("staff_add_contract", {
    p_cust_id: ctx.custId,
    p_stff_id: id,
    p_data: contract,
  });
  if (error) throw rpcError(error);
  return { stff_id: id };
}

export async function setStaffActive(ctx: AccessContext, id: number, active: unknown) {
  if (typeof active !== "boolean") throw bad("El estado no es válido.");
  const { data, error } = await supabaseAdmin
    .from("staffs")
    .update({ stff_active: active })
    .eq("stff_id", id)
    .eq("cust_id", ctx.custId)
    .select("stff_id")
    .maybeSingle();
  if (error) fail("No se pudo actualizar el estado.", error);
  if (!data) throw new AppError(404, "El personal no existe.", "NOT_FOUND");
  return { id, active };
}

/* ───────────────────────── Lista y supervisores ───────────────────────── */

const imgPath = (link: string | null) => (link ? `${STAFF_IMG_FOLDER}/${link}` : null);

export async function listStaffs(ctx: AccessContext, q: URLSearchParams) {
  const page = Math.max(1, Math.floor(Number(q.get("page")) || 1));
  const pageSize = Math.min(100, Math.max(1, Math.floor(Number(q.get("pageSize")) || 10)));
  const cargoId = idOrNull(q.get("cargoId"), "El cargo");
  const rolId = idOrNull(q.get("rolId"), "El rol");
  const estado = q.get("estado");

  let query = supabaseAdmin
    .from("staffs")
    .select(
      `stff_id, stff_name, stff_lastname, stff_dni, stff_phone, stff_link_img, stff_active,
       stff_access_system, stff_supervisor_id, cust_jb_pstn_id, cust_role_id,
       customer_job_positions(cust_jb_pstn_name), customer_roles(cust_role_name)`,
      { count: "exact" },
    )
    .eq("cust_id", ctx.custId);

  if (cargoId !== null) query = query.eq("cust_jb_pstn_id", cargoId);
  if (rolId !== null) query = query.eq("cust_role_id", rolId);
  if (estado === "ACTIVO") query = query.eq("stff_active", true);
  if (estado === "INACTIVO") query = query.eq("stff_active", false);

  // Cada palabra debe aparecer en nombre, apellido o DNI (se quitan los símbolos del filtro de PostgREST).
  const words = (q.get("search") ?? "").replace(/[,()%*\\"']/g, " ").split(/\s+/).filter(Boolean).slice(0, 5);
  for (const w of words) {
    query = query.or(`stff_name.ilike.%${w}%,stff_lastname.ilike.%${w}%,stff_dni.ilike.%${w}%`);
  }

  const { data, count, error } = await query
    .order("stff_lastname")
    .order("stff_name")
    .order("stff_id")
    .range((page - 1) * pageSize, page * pageSize - 1);
  if (error) fail("No se pudo cargar la lista de personal.", error);

  const rows = data ?? [];
  const urls = await createSignedUrls(
    ctx.bucketName,
    rows.map((r) => imgPath(r.stff_link_img)).filter((p): p is string => p !== null),
  );

  return {
    count: count ?? 0,
    items: rows.map((r) => ({
      stff_id: r.stff_id,
      stff_name: r.stff_name,
      stff_lastname: r.stff_lastname,
      stff_dni: r.stff_dni,
      stff_phone: r.stff_phone,
      stff_link_img: r.stff_link_img,
      stff_active: r.stff_active,
      stff_access_system: r.stff_access_system,
      stff_supervisor_id: r.stff_supervisor_id,
      cust_jb_pstn_id: r.cust_jb_pstn_id,
      cust_role_id: r.cust_role_id,
      job_position_name: one(r.customer_job_positions)?.cust_jb_pstn_name ?? null,
      role_name: one(r.customer_roles)?.cust_role_name ?? null,
      img_url: urls.get(imgPath(r.stff_link_img) ?? "") ?? null,
    })),
  };
}

/** Candidatos a jefe directo: personal activo + cuántas personas lo tienen como jefe. */
export async function getSupervisors(ctx: AccessContext) {
  const { data, error } = await supabaseAdmin
    .from("staffs")
    .select("stff_id, stff_name, stff_lastname, stff_link_img, stff_active, stff_supervisor_id, customer_job_positions(cust_jb_pstn_name)")
    .eq("cust_id", ctx.custId)
    .order("stff_lastname")
    .order("stff_name");
  if (error) fail("No se pudieron cargar los jefes directos.", error);

  const rows = data ?? [];
  const subordinates = new Map<number, number>();
  for (const r of rows) {
    if (r.stff_supervisor_id !== null) {
      subordinates.set(r.stff_supervisor_id, (subordinates.get(r.stff_supervisor_id) ?? 0) + 1);
    }
  }

  const candidates = rows.filter((r) => r.stff_active);
  const urls = await createSignedUrls(
    ctx.bucketName,
    candidates.map((r) => imgPath(r.stff_link_img)).filter((p): p is string => p !== null),
  );

  return {
    items: candidates.map((r) => ({
      id: r.stff_id,
      name: r.stff_name,
      lastname: r.stff_lastname,
      img_url: urls.get(imgPath(r.stff_link_img) ?? "") ?? null,
      job_position: one(r.customer_job_positions)?.cust_jb_pstn_name ?? null,
      subordinates: subordinates.get(r.stff_id) ?? 0,
    })),
  };
}

/** Organigrama: personal activo del customer con su jefe directo, cargo y foto. */
export async function getOrgChart(ctx: AccessContext) {
  const { data, error } = await supabaseAdmin
    .from("staffs")
    .select("stff_id, stff_name, stff_lastname, stff_link_img, stff_supervisor_id, customer_job_positions(cust_jb_pstn_name)")
    .eq("cust_id", ctx.custId)
    .eq("stff_active", true)
    .order("stff_lastname")
    .order("stff_name")
    .order("stff_id");
  if (error) fail("No se pudo cargar el organigrama.", error);

  const rows = data ?? [];
  const urls = await createSignedUrls(
    ctx.bucketName,
    rows.map((r) => imgPath(r.stff_link_img)).filter((p): p is string => p !== null),
  );

  return {
    items: rows.map((r) => ({
      id: r.stff_id,
      supervisor_id: r.stff_supervisor_id,
      name: r.stff_name,
      lastname: r.stff_lastname,
      img_url: urls.get(imgPath(r.stff_link_img) ?? "") ?? null,
      job_position: one(r.customer_job_positions)?.cust_jb_pstn_name ?? null,
    })),
  };
}

/* ───────────────────────── Detalle (para "Editar" / volver a contratar) ───────────────────────── */

const hhmm = (v: string | null) => (v ? v.slice(0, 5) : null);

/** Misma forma que recibe POST /staffs, más la foto. Lee el contrato más reciente. */
export async function getStaffDetail(ctx: AccessContext, id: number) {
  const { data: s, error } = await supabaseAdmin
    .from("staffs")
    .select("*")
    .eq("stff_id", id)
    .eq("cust_id", ctx.custId)
    .maybeSingle();
  if (error) fail("No se pudo cargar al personal.", error);
  if (!s) throw new AppError(404, "El personal no existe.", "NOT_FOUND");

  const { data: c, error: cErr } = await supabaseAdmin
    .from("staff_contracts")
    .select("*")
    .eq("stff_id", id)
    .order("stff_cntrt_id", { ascending: false })
    .limit(1)
    .maybeSingle();
  if (cErr) fail("No se pudo cargar el contrato.", cErr);
  if (!c) throw new AppError(404, "Este personal no tiene contrato registrado.", "NO_CONTRACT");

  const hist = await supabaseAdmin
    .from("staff_schedule_history")
    .select("stff_schdl_id")
    .eq("stff_cntrt_id", c.stff_cntrt_id)
    .is("schdl_hstry_end", null)
    .maybeSingle();
  if (hist.error) fail("No se pudo cargar el horario del contrato.", hist.error);
  if (!hist.data) throw new AppError(404, "El contrato no tiene horario registrado.", "NO_SCHEDULE");

  const [rfr, nwd] = await Promise.all([
    sch!.stff_rfrshmnth_id
      ? supabaseAdmin.from("staff_refreshments").select("*").eq("stff_rfrshmnth_id", sch!.stff_rfrshmnth_id).maybeSingle()
      : Promise.resolve({ data: null, error: null }),
    sch!.stff_nn_wrkng_day_id
      ? supabaseAdmin.from("staff_non_working_days").select("*").eq("stff_nn_wrkng_day_id", sch!.stff_nn_wrkng_day_id).maybeSingle()
      : Promise.resolve({ data: null, error: null }),
  ]);
  if (rfr.error || nwd.error) fail("No se pudo cargar el refrigerio o los días no laborables.", rfr.error ?? nwd.error);

  const r = rfr.data;
  const n = nwd.data;
  const urls = await createSignedUrls(ctx.bucketName, [imgPath(s.stff_link_img)].filter((p): p is string => p !== null));

  return {
    name: s.stff_name,
    lastname: s.stff_lastname,
    dni: s.stff_dni,
    phone: s.stff_phone,
    jobPositionId: s.cust_jb_pstn_id,
    roleId: s.cust_role_id,
    supervisorId: s.stff_supervisor_id,
    withAccess: s.stff_access_system,
    password: null, // la clave nunca viaja de vuelta

    schedule: {
      type: sch!.stff_schdl_type,
      start: hhmm(sch!.stff_schdl_start),
      end: hhmm(sch!.stff_schdl_end),
      toleranceMinutes: sch!.stff_schdl_start_tolerance,
      requiredMinutes: sch!.stff_schdl_required_minutes,
    },
    refreshment: r
      ? { type: r.stff_rfrshmnth_type, start: hhmm(r.stff_rfrshmnth_start), end: hhmm(r.stff_rfrshmnth_end), minutes: r.stff_rfrshmnth_minutes }
      : { type: "free", start: null, end: null, minutes: null },
    nonWorkingDays: !n
      ? null
      : n.stff_nn_wrkng_day_type === "fixed"
        ? {
            type: "fixed",
            days: [
              n.stff_nn_wrkng_day_monday, n.stff_nn_wrkng_day_tuesday, n.stff_nn_wrkng_day_wednesday,
              n.stff_nn_wrkng_day_thursday, n.stff_nn_wrkng_day_friday, n.stff_nn_wrkng_day_saturday,
              n.stff_nn_wrkng_day_sunday,
            ].map((d) => d === true),
          }
        : { type: "flexible", numberDays: n.stff_nn_wrkng_day_number_days },

    salary: { type: "Monthly", amount: Number(c.cntrt_salary_amount) }, // el tipo de pago aún no se guarda
    contract: { startDate: c.cntrt_start_date, endDate: c.cntrt_end_date },
    discount: null, // los montos de descuento aún no se guardan
    discountFlags: {
      absence: c.cntrt_discount_absence,
      delay: c.cntrt_discount_delay,
      refreshmentDelay: c.cntrt_discount_refreshment_delay,
    },
    img_url: urls.get(imgPath(s.stff_link_img) ?? "") ?? null,
  };
}

/* ───────────────────────── Foto ───────────────────────── */

export async function uploadStaffPhoto(ctx: AccessContext, id: number, file: File) {
  if (!IMAGE_TYPES.includes(file.type)) throw bad("Formato no permitido. Usa JPG, PNG, WEBP o GIF.", "INVALID_FILE");
  if (file.size > MAX_IMAGE_BYTES) throw bad("La imagen no puede pesar más de 5 MB.", "IMAGE_TOO_LARGE");

  const { data: s, error } = await supabaseAdmin
    .from("staffs")
    .select("stff_link_img")
    .eq("stff_id", id)
    .eq("cust_id", ctx.custId)
    .maybeSingle();
  if (error) fail("No se pudo consultar al personal.", error);
  if (!s) throw new AppError(404, "El personal no existe.", "NOT_FOUND");

  let body: Uint8Array;
  try {
    body = await convertImageToWebp(new Uint8Array(await file.arrayBuffer()));
  } catch (err) {
    console.error("staffs.uploadPhoto(convert):", err);
    throw bad("No se pudo procesar la imagen. Prueba con otro archivo.", "INVALID_FILE");
  }

  for (let attempt = 0; attempt < 5; attempt++) {
    const name = `${random11Digits()}.webp`;
    const { error: upErr } = await supabaseAdmin.storage
      .from(ctx.bucketName)
      .upload(`${STAFF_IMG_FOLDER}/${name}`, body, { contentType: "image/webp", upsert: false });

    if (upErr) {
      const exists = String((upErr as { statusCode?: string | number }).statusCode) === "409" || /already exists|duplicate/i.test(upErr.message ?? "");
      if (exists) continue;
      fail("No se pudo subir la foto.", upErr);
    }

    const { error: dbErr } = await supabaseAdmin
      .from("staffs")
      .update({ stff_link_img: name })
      .eq("stff_id", id)
      .eq("cust_id", ctx.custId);
    if (dbErr) {
      await supabaseAdmin.storage.from(ctx.bucketName).remove([`${STAFF_IMG_FOLDER}/${name}`]);
      fail("No se pudo guardar la foto.", dbErr);
    }

    // La foto anterior ya no se usa: se borra (si falla no importa).
    if (s.stff_link_img) {
      await supabaseAdmin.storage.from(ctx.bucketName).remove([`${STAFF_IMG_FOLDER}/${s.stff_link_img}`]).catch(() => {});
    }
    const urls = await createSignedUrls(ctx.bucketName, [`${STAFF_IMG_FOLDER}/${name}`]);
    return { stff_link_img: name, img_url: urls.get(`${STAFF_IMG_FOLDER}/${name}`) ?? null };
  }
  throw new AppError(500, "No se pudo generar un nombre único para la foto. Intenta de nuevo.");
}