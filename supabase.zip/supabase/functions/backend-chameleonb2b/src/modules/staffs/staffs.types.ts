export interface Staff {
  stff_id: number;
  cust_id: number;
  cust_role_id: number | null;
  cust_jb_pstn_id: number;
  stff_supervisor_id: number | null;
  stff_auth_id: string | null;
  stff_name: string;
  stff_lastname: string;
  stff_dni: string;
  stff_phone: string | null;
  stff_link_img: string | null;
  stff_active: boolean;
  stff_access_system: boolean;
}
