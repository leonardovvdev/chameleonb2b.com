export interface WorkerRole {
  wrker_role_id: number;
  wrker_role_name: string;
  wrker_role_desc: string | null;
  wrker_role_is_active_cust: boolean;
  wrker_role_is_active: boolean;
  wrker_role_created_at: string;
}
