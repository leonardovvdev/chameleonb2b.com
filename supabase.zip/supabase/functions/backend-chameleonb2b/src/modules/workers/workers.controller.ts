export interface Worker {
  wker_id: number;
  wker_name: string;
  wker_lastname: string;
  wker_dni: string | null;
  wker_phone: string;
  wker_phone_sec: string | null;
  wker_auth_id: string | null;
  wker_is_active: boolean;
  wker_creation_date: string;
  wker_updated_date: string;
  wrker_role_id: number;
}
