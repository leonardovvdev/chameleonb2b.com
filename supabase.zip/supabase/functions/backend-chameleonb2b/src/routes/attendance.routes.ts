import {
  absence,
  checkIn,
  getDetail,
  listAttendance,
  listPending,
  listPendingForAbsence,
  removeAttendance,
  updateJustification,
  updateObservation,
  updateTimes,
} from "../modules/attendance/attendance.controller.ts";

/**
 *   GET  /attendance?date=YYYY-MM-DD                          → { items, total_staff }
 *   GET  /attendance/pending?search=&cargoId=&rolId=          → { items } activos sin ingreso hoy
 *   GET  /attendance/pending-absence?search=&cargoId=&rolId=  → { items } activos sin ingreso ni ausencia hoy
 *   POST /attendance                                          → registra el ingreso de hoy  { stffId }
 *   POST /attendance/absence                                  → registra la ausencia de hoy { stffId, description }
 *   GET    /attendance/detail?id=                             → { att_observation, role_name, total_records }
 *   PATCH  /attendance/times?id=          { inicioJornada, inicioReceso, finReceso, finJornada }
 *   PATCH  /attendance/observation?id=    { observation }
 *   PATCH  /attendance/justification?id=  { type: "delay" | "refreshment_delay" | "absence", text }
 *   DELETE /attendance?id=                                    → elimina el registro
 */
export const attendanceRoutes: Record<string, (req: Request) => Promise<Response>> = {
  "GET /": listAttendance,
  "GET /pending": listPending,
  "GET /pending-absence": listPendingForAbsence,
  "POST /": checkIn,
  "POST /absence": absence,
  "GET /detail": getDetail,
  "PATCH /times": updateTimes,
  "PATCH /observation": updateObservation,
  "PATCH /justification": updateJustification,
  "DELETE /": removeAttendance,
};