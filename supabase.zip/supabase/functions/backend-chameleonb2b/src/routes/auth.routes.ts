import {
  getPasswordStatus,
  loginWithCorreoContrasena,
  loginWithGoogle,
  registerWithGoogle,
  setPassword,
} from "../modules/auth/auth.controller.ts";

/**
 * Rutas del módulo auth (el prefijo "/auth" lo resuelve routes/index.ts).
 *
 *   /auth/google/register → crea la cuenta con Google
 *   /auth/google/login    → entra con Google (NO crea nada)
 *   /auth/email/login     → entra con correo y contraseña (NO crea nada)
 *   GET  /auth/password   → ¿la cuenta ya tiene clave?
 *   POST /auth/password   → crea o actualiza la clave
 */
export const authRoutes: Record<string, (req: Request) => Promise<Response>> = {
  "POST /google/register": registerWithGoogle,
  "POST /google/login": loginWithGoogle,
  "POST /email/login": loginWithCorreoContrasena,
  "GET /password": getPasswordStatus,
  "POST /password": setPassword,
};