import {
  loginWithCorreoContrasena,
  loginWithGoogle,
  registerWithGoogle,
} from "../modules/auth/auth.controller.ts";

/**
 * Rutas del módulo auth (el prefijo "/auth" lo resuelve routes/index.ts).
 *
 *   /auth/google/register → crea la cuenta con Google
 *   /auth/google/login    → entra con Google (NO crea nada)
 *   /auth/email/login     → entra con correo y contraseña (NO crea nada)
 */
export const authRoutes: Record<string, (req: Request) => Promise<Response>> = {
  "POST /google/register": registerWithGoogle,
  "POST /google/login": loginWithGoogle,
  "POST /email/login": loginWithCorreoContrasena,
};