import {
  createFolderHandler,
  deleteFileHandler,
  deleteFolderHandler,
  listFilesHandler,
  listFoldersHandler,
  uploadFileHandler,
} from "../modules/buckets/buckets.controller.ts";

/**
 * Prefijo "/storage" (lo resuelve routes/index.ts).
 *
 *   GET    /storage/folders?            → carpetas del bucket + límites
 *   POST   /storage/folders?name=x      → crea una carpeta (máx. 5, sin subcarpetas)
 *   DELETE /storage/folders?name=x      → elimina una carpeta creada por el usuario
 *   GET    /storage/files?folder=x      → archivos de la carpeta (enlaces firmados)
 *   POST   /storage/files               → sube imagen/video (multipart: folder, file)
 *   DELETE /storage/files?folder=x&name=y → elimina un archivo
 */
export const bucketsRoutes: Record<string, (req: Request) => Promise<Response>> = {
  "GET /folders": listFoldersHandler,
  "POST /folders": createFolderHandler,
  "DELETE /folders": deleteFolderHandler,
  "GET /files": listFilesHandler,
  "POST /files": uploadFileHandler,
  "DELETE /files": deleteFileHandler,
};