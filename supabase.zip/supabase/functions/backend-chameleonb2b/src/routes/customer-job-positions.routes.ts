import {
  createCustomerJobPosition,
  deleteCustomerJobPosition,
  listCustomerJobPositions,
  updateCustomerJobPosition,
} from "../modules/customer-job-positions/customer-job-positions.controller.ts";

/**
 * Rutas del módulo customer-job-positions (el prefijo "/customer-job-positions" lo resuelve routes/index.ts).
 *
 *   GET    /customer-job-positions         → lista los cargos del customer
 *   POST   /customer-job-positions         → crea un cargo
 *   PATCH  /customer-job-positions?id=123  → edita un cargo
 *   DELETE /customer-job-positions?id=123  → elimina un cargo
 */
export const customerJobPositionsRoutes: Record<string, (req: Request) => Promise<Response>> = {
  "GET /": listCustomerJobPositions,
  "POST /": createCustomerJobPosition,
  "PATCH /": updateCustomerJobPosition,
  "DELETE /": deleteCustomerJobPosition,
};
