import {
  createCustomerRole,
  deleteCustomerRole,
  listCustomerRoles,
  updateCustomerRole,
} from "../modules/customer-roles/customer-roles.controller.ts";

/**
 * Rutas del módulo customer-roles (el prefijo "/customer-roles" lo resuelve routes/index.ts).
 *
 *   GET    /customer-roles         → lista los roles del customer
 *   POST   /customer-roles         → crea un rol
 *   PATCH  /customer-roles?id=123  → edita un rol
 *   DELETE /customer-roles?id=123  → elimina un rol
 */
export const customerRoleRoutes: Record<string, (req: Request) => Promise<Response>> = {
  "GET /": listCustomerRoles,
  "POST /": createCustomerRole,
  "PATCH /": updateCustomerRole,
  "DELETE /": deleteCustomerRole,
};
