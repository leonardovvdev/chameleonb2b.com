import { getMyCustomer } from "../modules/customers/customers.controller.ts";

/**
 * Rutas del módulo customers (el prefijo "/customers" lo resuelve routes/index.ts).
 *
 *   GET /customers/me → datos del customer de la sesión + enlace firmado de su imagen
 */
export const customersRoutes: Record<string, (req: Request) => Promise<Response>> = {
  "GET /me": getMyCustomer,
};