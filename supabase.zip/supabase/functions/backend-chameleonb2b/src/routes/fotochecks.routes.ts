import { getDefaultFotocheck } from "../modules/fotochecks/fotochecks.controller.ts";

/**
 * Prefijo "/fotochecks" (lo resuelve routes/index.ts).
 *   GET /fotochecks/default → fotocheck predeterminado con enlaces firmados
 */
export const fotochecksRoutes: Record<string, (req: Request) => Promise<Response>> = {
  "GET /default": getDefaultFotocheck,
};