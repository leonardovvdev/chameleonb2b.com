import { getCorsHeaders } from "../shared/cors.ts";
import { AppError, json } from "../shared/http.ts";
import { getMeHandler } from "../modules/customers/customers.controller.ts";
import {
  createJobPositionHandler,
  deleteJobPositionHandler,
  listJobPositionsHandler,
  updateJobPositionHandler,
} from "../modules/customer-job-positions/customer-job-positions.controller.ts";
import {
  createRoleHandler,
  deleteRoleHandler,
  listRolesHandler,
  updateRoleHandler,
} from "../modules/customer-roles/customer-roles.controller.ts";
import { getDefaultFotocheckHandler } from "../modules/fotochecks/fotochecks.controller.ts";
import {
  createStaffHandler,
  listStaffsHandler,
  getOrgChartHandler,
  getStaffDetailHandler,
  getSupervisorsHandler,
  setStaffActiveHandler,
  updateStaffContractHandler,
  updateStaffHandler,
  uploadStaffPhotoHandler,
} from "../modules/staffs/staffs.controller.ts";
import {
  getPasswordStatus,
  loginWithCorreoContrasena,
  loginWithGoogle,
  registerWithGoogle,
  setPassword,
  checkGoogleAccount,
} from "../modules/auth/auth.controller.ts";

import {
  createAdvancementHandler,
  createAttendanceHandler,
  createIncidentHandler,
  deleteAttendanceHandler,
  getAttendanceDetailHandler,
  getAttendanceReportHandler,
  getAttendanceReportRowHandler,
  listAdvancementsHandler,
  listAttendanceHandler,
  listEligibleStaffHandler,
  listIncidentsHandler,
  updateAdvancementHandler,
  updateAttendanceJustificationHandler,
  updateAttendanceObservationHandler,
  updateAttendanceTimesHandler,
  canDeleteHandler,
  deleteIncidentHandler,
  deleteAdvancementHandler,
} from "../modules/attendance/attendance.controller.ts";
import {
  getCurrentContractHandler,
  listStaffContractsHandler,
  updateContractHandler,
  updateContractScheduleHandler,
} from "../modules/staff-contracts/staff-contracts.controller.ts";
import {
  createFolderHandler,
  deleteFileHandler,
  deleteFolderHandler,
  listFilesHandler,
  listFoldersHandler,
  uploadFileHandler,
} from "../modules/buckets/buckets.controller.ts";
import {
  createLogoHandler,
  deleteLogoHandler,
  listLogosHandler,
  updateLogoHandler,
} from "../modules/logos/logos.controller.ts";

type Handler = (req: Request) => Promise<Response>;

const routes: Record<string, Handler> = {
  "POST /auth/email/login": loginWithCorreoContrasena,
  "POST /auth/google/login": loginWithGoogle,
  "POST /auth/google/register": registerWithGoogle,
  "GET /auth/password": getPasswordStatus,
  "PUT /auth/password": setPassword,
  "POST /auth/google/check": checkGoogleAccount,

  "GET /customers/me": getMeHandler,
  "GET /customer-job-positions": listJobPositionsHandler,
  "POST /customer-job-positions": createJobPositionHandler,
  "PATCH /customer-job-positions": updateJobPositionHandler,
  "DELETE /customer-job-positions": deleteJobPositionHandler,
  "GET /customer-roles": listRolesHandler,
  "POST /customer-roles": createRoleHandler,
  "PATCH /customer-roles": updateRoleHandler,
  "DELETE /customer-roles": deleteRoleHandler,
  "GET /fotochecks/default": getDefaultFotocheckHandler,
  "GET /storage/folders": listFoldersHandler,
  "POST /storage/folders": createFolderHandler,
  "DELETE /storage/folders": deleteFolderHandler,
  "GET /storage/files": listFilesHandler,
  "POST /storage/files": uploadFileHandler,
  "DELETE /storage/files": deleteFileHandler,

  "GET /logos": listLogosHandler,
  "POST /logos": createLogoHandler,
  "PATCH /logos": updateLogoHandler,
  "DELETE /logos": deleteLogoHandler,
  
  "GET /staffs": listStaffsHandler,
  "POST /staffs": createStaffHandler,
  "PATCH /staffs": updateStaffHandler,
  "GET /staffs/supervisors": getSupervisorsHandler,
  "GET /staffs/org-chart": getOrgChartHandler,
  "GET /staffs/detail": getStaffDetailHandler,
  "PATCH /staffs/active": setStaffActiveHandler,
  "PUT /staffs/contract": updateStaffContractHandler,
  "POST /staffs/photo": uploadStaffPhotoHandler,

  "GET /attendance": listAttendanceHandler,
  "POST /attendance": createAttendanceHandler,
  "DELETE /attendance": deleteAttendanceHandler,
  "GET /attendance/eligible-staff": listEligibleStaffHandler,

  "GET /attendance/detail": getAttendanceDetailHandler,
  "PATCH /attendance/times": updateAttendanceTimesHandler,
  "PATCH /attendance/observation": updateAttendanceObservationHandler,
  "PATCH /attendance/justification": updateAttendanceJustificationHandler,
  "GET /attendance/incidents": listIncidentsHandler,
  "POST /attendance/incidents": createIncidentHandler,
  "GET /attendance/advancements": listAdvancementsHandler,
  "POST /attendance/advancements": createAdvancementHandler,
  "PATCH /attendance/advancements": updateAdvancementHandler,
  "GET /attendance/report": getAttendanceReportHandler,
  "GET /attendance/report/row": getAttendanceReportRowHandler,
  "GET /attendance/can-delete": canDeleteHandler,
  "DELETE /attendance/incidents": deleteIncidentHandler,
  "DELETE /attendance/advancements": deleteAdvancementHandler,

  "GET /staff-contracts": listStaffContractsHandler,
  "GET /staff-contracts/current": getCurrentContractHandler,
  "PATCH /staff-contracts": updateContractHandler,
  "PATCH /staff-contracts/schedule": updateContractScheduleHandler,

};

function addCors(res: Response, cors: Headers): Response {
  const headers = new Headers(res.headers);
  cors.forEach((value, key) => headers.set(key, value));
  return new Response(res.body, { status: res.status, headers });
}

export async function handleRequest(req: Request): Promise<Response> {
  const cors = getCorsHeaders(req);
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });

  try {
    // En la Edge Function la ruta llega como /backend-chameleonb2b/staffs
    const path =
      new URL(req.url).pathname
        .replace(/^\/(functions\/v1\/)?backend-chameleonb2b/, "")
        .replace(/\/+$/, "") || "/";

    const handler = routes[`${req.method} ${path}`];
    if (!handler) throw new AppError(404, "Ruta no encontrada.", "NOT_FOUND");

    return addCors(await handler(req), cors);
  } catch (err) {
    if (err instanceof AppError) {
      return addCors(json({ error: err.message, code: err.code ?? null }, err.status), cors);
    }
    console.error("Error no controlado:", err);
    return addCors(json({ error: "Ocurrió un error inesperado.", code: null }, 500), cors);
  }
}