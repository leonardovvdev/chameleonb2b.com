import { getCorsHeaders } from "../shared/cors.ts";
import { AppError, json } from "../shared/http.ts";
import { authRoutes } from "./auth.routes.ts";
import { customersRoutes } from "./customers.routes.ts";
import { customerJobPositionsRoutes } from "./customer-job-positions.routes.ts";
import { customerRoleRoutes } from "./customer-roles.routes.ts";
import { attendanceRoutes } from "./attendance.routes.ts";
import { logoRoutes } from "./logo.routes.ts";
import { bucketsRoutes } from "./buckets.routes.ts";
import { fotochecksRoutes } from "./fotochecks.routes.ts";
import { staffDiscountIncidentsRoutes } from "./staff-discount-incidents.routes.ts";
import { staffAdvancementsRoutes } from "./staff-advancements.routes.ts";
// junto a los demás imports:
import { staffRoutes } from "./staff.routes.ts";
type Handler = (req: Request) => Promise<Response>;

/** Prefijo de URL → rutas del módulo. */
const PREFIXES: Record<string, Record<string, Handler>> = {
  "/auth": authRoutes,
  "/customers": customersRoutes,
  "/customer-job-positions": customerJobPositionsRoutes,
  "/customer-roles": customerRoleRoutes,
  "/staffs": staffRoutes,
  "/attendance": attendanceRoutes,
  "/staff-discount-incidents": staffDiscountIncidentsRoutes,
  "/staff-advancements": staffAdvancementsRoutes,
  "/fotochecks": fotochecksRoutes,
  "/logos": logoRoutes,
  "/storage": bucketsRoutes,
};
const FUNCTION_NAME = "/backend-chameleonb2b";

/** Quita el nombre de la función de la ruta: /backend-chameleonb2b/auth/x → /auth/x */
function cleanPath(pathname: string): string {
  const i = pathname.indexOf(FUNCTION_NAME);
  let path = i >= 0 ? pathname.slice(i + FUNCTION_NAME.length) : pathname;
  if (path.length > 1 && path.endsWith("/")) path = path.slice(0, -1);
  return path || "/";
}

async function route(req: Request): Promise<Response> {
  const path = cleanPath(new URL(req.url).pathname);

  for (const [prefix, routes] of Object.entries(PREFIXES)) {
    if (path === prefix || path.startsWith(`${prefix}/`)) {
      const rest = path.slice(prefix.length) || "/";
      const handler = routes[`${req.method} ${rest}`];
      if (handler) return await handler(req);
    }
  }

  throw new AppError(404, "Ruta no encontrada.", "NOT_FOUND");
}

/** Agrega los headers CORS a cualquier respuesta. */
function addCors(req: Request, res: Response): Response {
  const headers = new Headers(res.headers);
  getCorsHeaders(req).forEach((value, key) => headers.set(key, value));
  return new Response(res.body, { status: res.status, headers });
}

export async function handleRequest(req: Request): Promise<Response> {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: getCorsHeaders(req) });
  }

  try {
    return addCors(req, await route(req));
  } catch (err) {
    if (err instanceof AppError) {
      return addCors(req, json({ error: err.message, code: err.code ?? null }, err.status));
    }
    console.error("Error no controlado:", err);
    return addCors(req, json({ error: "Error interno del servidor." }, 500));
  }
}