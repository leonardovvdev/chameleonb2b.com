import {
  createLogoHandler,
  deleteLogoHandler,
  listLogosHandler,
  updateLogoHandler,
} from "../modules/logos/logo.controller.ts";

/**
 * Prefijo "/logos" (lo resuelve routes/index.ts).
 *
 *   GET    /logos          → lista los logos del customer (con enlace firmado)
 *   POST   /logos          → crea un logo (multipart: name, description, file)
 *   PATCH  /logos?id=123   → edita un logo (file opcional: reemplaza la imagen)
 *   DELETE /logos?id=123   → elimina el logo y su imagen
 */
export const logoRoutes: Record<string, (req: Request) => Promise<Response>> = {
  "GET /": listLogosHandler,
  "POST /": createLogoHandler,
  "PATCH /": updateLogoHandler,
  "DELETE /": deleteLogoHandler,
};