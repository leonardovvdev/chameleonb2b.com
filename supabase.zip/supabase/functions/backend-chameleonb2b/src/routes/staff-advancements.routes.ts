import {
  createAdvancementHandler,
  getActorHandler,
  listAdvancementsHandler,
  updateAdvancementHandler,
} from "../modules/staff-advancements/staff-advancements.controller.ts";

/**
 *   GET   /staff-advancements?page=&pageSize=&search=&stffId=&dateFrom=&dateTo=  → { items, count }
 *   GET   /staff-advancements/actor    → { staffId, name }  quién está usando el sistema (staffId null = el dueño)
 *   POST  /staff-advancements          → crea un adelanto  { stffId, amount, date?, description? }
 *   PATCH /staff-advancements?id=123   → edita un adelanto (solo los campos enviados)
 *
 *   date: si no se envía, es hoy (hora de Lima).
 *   Quién entrega: siempre el usuario autenticado (JWT); null = el dueño. No se puede enviar ni editar.
 */
export const staffAdvancementsRoutes: Record<string, (req: Request) => Promise<Response>> = {
  "GET /": listAdvancementsHandler,
  "GET /actor": getActorHandler,
  "POST /": createAdvancementHandler,
  "PATCH /": updateAdvancementHandler,
};