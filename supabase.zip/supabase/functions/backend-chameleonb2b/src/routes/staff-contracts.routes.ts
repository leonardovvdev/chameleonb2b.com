import { listContracts } from "../modules/staff-contracts/staff-contracts.controller.ts";

export const staffContractsRoutes: Record<string, (req: Request) => Promise<Response>> = {
  "GET /": listContracts,
};