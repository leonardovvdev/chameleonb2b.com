import {
  createIncidentHandler,
  listIncidents,
} from "../modules/staff-discount-incidents/staff-discount-incidents.controller.ts";

/**
 *   GET  /staff-discount-incidents?attId=  → { items } incidencias de un registro de asistencia
 *   POST /staff-discount-incidents         → crea una incidencia  { attId, description, amount }
 */
export const staffDiscountIncidentsRoutes: Record<string, (req: Request) => Promise<Response>> = {
  "GET /": listIncidents,
  "POST /": createIncidentHandler,
};