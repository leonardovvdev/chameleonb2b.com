import {
  createStaffHandler,
  getOrgChart,
  getStaffDetailHandler,
  getSupervisors,
  listStaff,
  renewStaffContractHandler,
  setActiveHandler,
  updateStaffHandler,
  uploadPhotoHandler,
} from "../modules/staffs/staff.controller.ts";

/**
 * Rutas del módulo staffs (el prefijo "/staffs" lo resuelve routes/index.ts).
 *
 *   GET   /staffs?page=&pageSize=&search=&cargoId=&rolId=&estado=  → { items, count }
 *   POST  /staffs                  → crea el personal (horario, refrigerio, días no laborables, contrato y sueldo)
 *   PATCH /staffs?id=123           → edita los datos básicos
 *   GET   /staffs/detail?id=123    → todo el personal para editarlo (misma forma que el POST)
 *   PUT   /staffs/contract?id=123  → edita todo, lo ACTIVA y crea un nuevo contrato
 *   PATCH /staffs/active?id=123    → activa / desactiva  { active }
 *   POST  /staffs/photo?id=123     → sube la foto (multipart, campo "file")
 *   GET   /staffs/supervisors      → candidatos a jefe directo
 *   GET   /staffs/org-chart        → personal activo (para armar el organigrama)
 */
export const staffRoutes: Record<string, (req: Request) => Promise<Response>> = {
  "GET /": listStaff,
  "POST /": createStaffHandler,
  "PATCH /": updateStaffHandler,
  "GET /detail": getStaffDetailHandler,
  "PUT /contract": renewStaffContractHandler,
  "PATCH /active": setActiveHandler,
  "POST /photo": uploadPhotoHandler,
  "GET /supervisors": getSupervisors,
  "GET /org-chart": getOrgChart,
};