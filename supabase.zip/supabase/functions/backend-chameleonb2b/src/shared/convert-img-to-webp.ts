import {
  ImageMagick,
  initializeImageMagick,
  MagickFormat,
} from "npm:@imagemagick/magick-wasm@0.0.30";

let engine: Promise<void> | null = null;

/** Carga el motor WASM una sola vez por instancia de la función. */
function initEngine(): Promise<void> {
  engine ??= (async () => {
    const wasmBytes = await Deno.readFile(
      new URL("magick.wasm", import.meta.resolve("npm:@imagemagick/magick-wasm@0.0.30")),
    );
    await initializeImageMagick(wasmBytes);
  })();
  return engine;
}

/** Convierte una imagen (JPG, PNG, GIF o WEBP) a WebP. Lanza error si no se puede leer. */
export async function convertImageToWebp(input: Uint8Array, quality = 85): Promise<Uint8Array> {
  await initEngine();

  return ImageMagick.read(input, (image) => {
    image.quality = quality;
    // slice(): copia los bytes, porque el buffer original pertenece a la memoria del WASM
    return image.write(MagickFormat.WebP, (data) => data.slice());
  });
}