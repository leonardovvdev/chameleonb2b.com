
const ALLOWED_ORIGINS = [
  // Desarrollo local
  "http://localhost:5173",

  // Producción
  "https://chameleonb2b.com",
  "https://www.chameleonb2b.com",
];

export function getCorsHeaders(req: Request): Headers {
  const headers = new Headers();
  const origin = req.headers.get("Origin");

  if (origin && ALLOWED_ORIGINS.includes(origin)) {
    headers.set("Access-Control-Allow-Origin", origin);
    headers.set("Vary", "Origin");
  }

  headers.set(
    "Access-Control-Allow-Headers",
    "authorization, x-client-info, apikey, content-type, x-supabase-api-version",
  );

  headers.set(
    "Access-Control-Allow-Methods",
    "GET, POST, PUT, PATCH, DELETE, OPTIONS",
  );

  headers.set("Access-Control-Max-Age", "86400");

  return headers;
}
