/**
 * Error controlado del backend.
 * `code` es opcional: permite que el frontend distinga casos (ej. CUSTOMER_NOT_FOUND)
 * sin tener que comparar textos de mensajes.
 */
export class AppError extends Error {
  constructor(
    public status: number,
    message: string,
    public code?: string,
  ) {
    super(message);
  }
}

// Los headers CORS los agrega addCors() en routes/index.ts
export const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });