/** Número entero de exactamente 11 dígitos (10_000_000_000 – 99_999_999_999). */
export function random11Digits(): number {
  const buf = new Uint32Array(2);
  crypto.getRandomValues(buf);
  const big = (BigInt(buf[0]) << 32n) | BigInt(buf[1]);
  return Number(big % 90_000_000_000n) + 10_000_000_000;
}